import { Layout } from "@/components/layout";

export default function Profile() {
  return <Layout title="Profil">

  </Layout>
}