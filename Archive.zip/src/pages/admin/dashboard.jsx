import { Layout } from "@/components/layout";

export default function Dashboard() {
  return <Layout>
    
  </Layout>
}