import { responseNotFound } from "@/errors/response-error";
import query from "@/lib/db";

export default async function handler(req, res) {
  if (req.method !== "GET") {
    responseNotFound(res);
    return;
  }

  const results = await query("SELECT * FROM product");
  res.status(200).json({
    data: results
  })
}