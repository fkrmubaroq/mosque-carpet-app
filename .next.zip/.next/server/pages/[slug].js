(() => {
var exports = {};
exports.id = 6219;
exports.ids = [6219,4991];
exports.modules = {

/***/ 3208:
/***/ ((module) => {

// Exports
module.exports = {
	"wrapper-article": "article_wrapper-article__v_yxo",
	"article__title": "article_article__title__nXWil",
	"article__writer-name": "article_article__writer-name__yx4IF"
};


/***/ }),

/***/ 4991:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Vr": () => (/* binding */ getArticleById),
/* harmony export */   "Xc": () => (/* binding */ updateArticle),
/* harmony export */   "fq": () => (/* binding */ getArticle),
/* harmony export */   "jX": () => (/* binding */ deleteArticle),
/* harmony export */   "tu": () => (/* binding */ createArticle),
/* harmony export */   "vX": () => (/* binding */ getArticleBySlug)
/* harmony export */ });
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9254);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(873);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_0__]);
___WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function getArticle(params) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)("article", {
        params
    });
}
function createArticle(payload) {
    const formPayload = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .objectIntoFormData */ .rW)(payload);
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .postMethod */ .lx)("article", formPayload);
}
function updateArticle(id, payload) {
    const formPayload = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .objectIntoFormData */ .rW)(payload);
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .putMethod */ .yu)(`article/${id}`, formPayload);
}
function getArticleById(id) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)(`article/${id}`);
}
function getArticleBySlug(slug) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)(`article/slug/${slug}`);
}
function deleteArticle(id) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .deleteMethod */ .SR)(`article/${id}`);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 332:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Article),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Meta__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5766);
/* harmony import */ var _components_features_article_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3208);
/* harmony import */ var _components_features_article_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_components_features_article_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_features_sections_SectionFooter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(458);
/* harmony import */ var _components_layout_HeaderArticle__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3234);
/* harmony import */ var _lib_api_articles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4991);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2470);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9641);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(873);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var html_react_parser__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2905);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_features_sections_SectionFooter__WEBPACK_IMPORTED_MODULE_2__, _lib_api_articles__WEBPACK_IMPORTED_MODULE_4__, html_react_parser__WEBPACK_IMPORTED_MODULE_10__]);
([_components_features_sections_SectionFooter__WEBPACK_IMPORTED_MODULE_2__, _lib_api_articles__WEBPACK_IMPORTED_MODULE_4__, html_react_parser__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















async function getServerSideProps(context) {
    const { slug  } = context.params;
    const response = await (0,_lib_api_articles__WEBPACK_IMPORTED_MODULE_4__/* .getArticleBySlug */ .vX)(slug);
    const prismaSections = await _lib_prisma__WEBPACK_IMPORTED_MODULE_6__/* .prismaClient.sections.findMany */ .m.sections.findMany({
        orderBy: {
            position: "asc"
        },
        where: {
            active: "Y"
        }
    });
    return {
        props: {
            article: response.data.data || null,
            sections: prismaSections || []
        }
    };
}
function Article({ article , sections  }) {
    const getContentSection = (sectionName)=>{
        const section = sections.find((section)=>section.section_name === sectionName);
        const content = JSON.parse((section === null || section === void 0 ? void 0 : section.content) || "{}");
        return {
            ...section,
            content
        };
    };
    const getDescription = ()=>{
        const content = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_7__/* .strippedStrings */ .nz)((article === null || article === void 0 ? void 0 : article.content) || "");
        return content.substring(0, 60);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Meta__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                customTitle: article === null || article === void 0 ? void 0 : article.title,
                description: getDescription()
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: "min-h-screen",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_HeaderArticle__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                    !article ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Notfound, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PreviewNews, {
                        data: article
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_features_sections_SectionFooter__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                section: getContentSection("section_footer")
            })
        ]
    });
}
function PreviewNews({ data  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(_lib_constant__WEBPACK_IMPORTED_MODULE_5__/* .CONTAINER_LP */ .oc, "tiptap-reader mt-8 mb-32"),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_components_features_article_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["wrapper-article"])),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_components_features_article_module_scss__WEBPACK_IMPORTED_MODULE_14___default().article__title)),
                    children: data === null || data === void 0 ? void 0 : data.title
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex md:flex-row flex-col md:gap-y-0 gap-y-1 justify-between mt-2.5 mb-3",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center gap-x-1.5 ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_12__.FiUser, {
                                    size: 14,
                                    color: "gray"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_components_features_article_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["article__writer-name"])),
                                    children: data === null || data === void 0 ? void 0 : data.writer
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "text-gray-400 text-xs flex gap-x-1 items-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_13__.IoMdTime, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: dayjs__WEBPACK_IMPORTED_MODULE_9___default()(data.created_at).format("DD MMMM YYYY Pukul HH:mm WIB")
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col gap-y-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_11___default()), {
                            className: "object-cover rounded-sm w-full ",
                            alt: (data === null || data === void 0 ? void 0 : data.title) || "-",
                            src: (data === null || data === void 0 ? void 0 : data.thumbnail) ? (0,_lib_utils__WEBPACK_IMPORTED_MODULE_7__/* .mediaPath */ .hf)("articles-thumbnail", data.thumbnail) : _lib_constant__WEBPACK_IMPORTED_MODULE_5__/* .placeholderImage */ .jM,
                            width: 800,
                            height: 500
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: (0,html_react_parser__WEBPACK_IMPORTED_MODULE_10__["default"])((data === null || data === void 0 ? void 0 : data.content) || "")
                        })
                    ]
                })
            ]
        })
    });
}
function Notfound() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex justify-center items-center mt-20 flex-col gap-y-3",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "text-gray-700 tracking-wider font-medium text-2xl",
                children: "Artikel tidak ditemukan"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_11___default()), {
                src: "/img/empty-article.png",
                width: 360,
                height: 320
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "text-gray-400 tracking-wider font-medium text-lg",
                children: [
                    "Yuk Baca artikel lainnya",
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-primary font-semibold cursor-pointer hover:underline",
                        onClick: ()=>{
                            location.href = "/news";
                        },
                        children: "disini"
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3524:
/***/ ((module) => {

"use strict";
module.exports = require("@prisma/client");

/***/ }),

/***/ 9003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6563:
/***/ ((module) => {

"use strict";
module.exports = require("react-contenteditable");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bs");

/***/ }),

/***/ 8625:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ci");

/***/ }),

/***/ 2750:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fi");

/***/ }),

/***/ 1111:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/hi");

/***/ }),

/***/ 4751:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/io");

/***/ }),

/***/ 8510:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/lu");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 49:
/***/ ((module) => {

"use strict";
module.exports = import("@radix-ui/react-label");;

/***/ }),

/***/ 4338:
/***/ ((module) => {

"use strict";
module.exports = import("@radix-ui/react-slot");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 6926:
/***/ ((module) => {

"use strict";
module.exports = import("class-variance-authority");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

"use strict";
module.exports = import("html-react-parser");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5675,5152,1257,9010,3516,7912,5766,2872,3234], () => (__webpack_exec__(332)));
module.exports = __webpack_exports__;

})();