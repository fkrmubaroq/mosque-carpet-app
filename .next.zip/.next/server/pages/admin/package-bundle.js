"use strict";
(() => {
var exports = {};
exports.id = 7241;
exports.ids = [7241];
exports.modules = {

/***/ 5521:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SearchInput)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3516);




function SearchInput({ onChange , placeholder , name , value , className  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative shrink-0",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(___WEBPACK_IMPORTED_MODULE_3__/* .Input */ .I, {
                placeholder: placeholder ? placeholder : "Search",
                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("!h-11", className),
                name: name,
                value: value,
                onChange: onChange
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "absolute right-3 top-3.5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiSearch, {
                    color: "#9ca3af"
                })
            })
        ]
    });
}


/***/ }),

/***/ 9641:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ prismaClient)
/* harmony export */ });
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);

const prismaClient = new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient({
    errorFormat: "pretty",
    log: [
        "info",
        "query",
        "warn",
        "error"
    ]
});


/***/ }),

/***/ 3407:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Index),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_features_products_ModalForm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8472);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9089);
/* harmony import */ var _components_ui_button_ButtonAdd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5690);
/* harmony import */ var _components_ui_button_ButtonDelete__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9034);
/* harmony import */ var _components_ui_button_ButtonEdit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3661);
/* harmony import */ var _components_ui_card__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1739);
/* harmony import */ var _components_ui_form_Checkbox__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5596);
/* harmony import */ var _components_ui_form_input_SearchInput__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5521);
/* harmony import */ var _components_ui_table__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(574);
/* harmony import */ var _lib_hookStore__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6542);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9641);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_features_products_ModalForm__WEBPACK_IMPORTED_MODULE_1__, _components_layout__WEBPACK_IMPORTED_MODULE_2__, _components_ui_button_ButtonAdd__WEBPACK_IMPORTED_MODULE_3__, _components_ui_button_ButtonDelete__WEBPACK_IMPORTED_MODULE_4__, _components_ui_button_ButtonEdit__WEBPACK_IMPORTED_MODULE_5__, _lib_hookStore__WEBPACK_IMPORTED_MODULE_10__]);
([_components_features_products_ModalForm__WEBPACK_IMPORTED_MODULE_1__, _components_layout__WEBPACK_IMPORTED_MODULE_2__, _components_ui_button_ButtonAdd__WEBPACK_IMPORTED_MODULE_3__, _components_ui_button_ButtonDelete__WEBPACK_IMPORTED_MODULE_4__, _components_ui_button_ButtonEdit__WEBPACK_IMPORTED_MODULE_5__, _lib_hookStore__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const initModal = {
    show: false,
    type: "add"
};
const initForm = {
    id: 0,
    name: "",
    description: "",
    price: 0,
    stock: 0,
    category_id: 0
};
function Index({ data  }) {
    const { 0: modal , 1: setModal  } = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)(initModal);
    const { 0: products , 1: setProducts  } = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)(data);
    const [showConfirmation, showToast] = (0,_lib_hookStore__WEBPACK_IMPORTED_MODULE_10__/* .useDialogStore */ .IA)((state)=>[
            state.showConfirmation,
            state.showToast, 
        ]);
    // const { mutate } = useMutation({
    //   mutationFn:(payload) =>
    // })
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            modal.show && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_features_products_ModalForm__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                type: "add",
                show: modal.show,
                data: (modal === null || modal === void 0 ? void 0 : modal.data) ? modal.data : initForm,
                onHide: ()=>setModal(initModal)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout__WEBPACK_IMPORTED_MODULE_2__/* .Layout */ .A, {
                title: "Products",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_card__WEBPACK_IMPORTED_MODULE_6__/* .Card */ .Zb, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_card__WEBPACK_IMPORTED_MODULE_6__/* .CardHeader */ .Ol, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-start justify-between",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input_SearchInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        placeholder: "Search Product"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button_ButtonAdd__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        text: "Product",
                                        onClick: ()=>setModal({
                                                show: true,
                                                type: "add"
                                            })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_card__WEBPACK_IMPORTED_MODULE_6__/* .CardContent */ .aY, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__/* .Thead */ .h, {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__.Th, {
                                                    className: "w-4",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_Checkbox__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__.Th, {
                                                    children: "PRODUCT NAME"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__.Th, {
                                                    children: "CATEGORY"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__.Th, {
                                                    children: "PRICE"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__.Th, {
                                                    children: "STOCK"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__.Th, {
                                                    className: "text-center",
                                                    children: "ACTION"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                        children: products.map((product, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__.Tr, {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__.Td, {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_Checkbox__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__.Td, {
                                                        children: product.name
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__.Td, {
                                                        children: product.category.category_name
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__.Td, {
                                                        children: product.price
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__.Td, {
                                                        children: product.stock
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_table__WEBPACK_IMPORTED_MODULE_9__.Td, {
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "flex justify-center gap-x-1",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button_ButtonEdit__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button_ButtonDelete__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                                    onClick: ()=>showConfirmation("confirm-delete-product", {
                                                                            onConfirm: ()=>{
                                                                                showToast("success-delete-product");
                                                                            }
                                                                        })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }, key))
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
}
const getServerSideProps = async (context)=>{
    const response = await _lib_prisma__WEBPACK_IMPORTED_MODULE_11__/* .prismaClient.product.findMany */ .m.product.findMany({
        include: {
            category: true
        }
    });
    return {
        props: {
            data: response
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 8625:
/***/ ((module) => {

module.exports = require("react-icons/ci");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 1111:
/***/ ((module) => {

module.exports = require("react-icons/hi");

/***/ }),

/***/ 4751:
/***/ ((module) => {

module.exports = require("react-icons/io");

/***/ }),

/***/ 8510:
/***/ ((module) => {

module.exports = require("react-icons/lu");

/***/ }),

/***/ 4041:
/***/ ((module) => {

module.exports = require("react-icons/md");

/***/ }),

/***/ 150:
/***/ ((module) => {

module.exports = require("react-icons/pi");

/***/ }),

/***/ 8098:
/***/ ((module) => {

module.exports = require("react-icons/ri");

/***/ }),

/***/ 5452:
/***/ ((module) => {

module.exports = require("react-icons/rx");

/***/ }),

/***/ 1740:
/***/ ((module) => {

module.exports = require("react-icons/tfi");

/***/ }),

/***/ 382:
/***/ ((module) => {

module.exports = require("react-icons/vsc");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 49:
/***/ ((module) => {

module.exports = import("@radix-ui/react-label");;

/***/ }),

/***/ 4338:
/***/ ((module) => {

module.exports = import("@radix-ui/react-slot");;

/***/ }),

/***/ 9752:
/***/ ((module) => {

module.exports = import("@tanstack/react-query");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6926:
/***/ ((module) => {

module.exports = import("class-variance-authority");;

/***/ }),

/***/ 6912:
/***/ ((module) => {

module.exports = import("zustand");;

/***/ }),

/***/ 5237:
/***/ ((module) => {

module.exports = import("zustand/react/shallow");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5675,5152,1257,9010,3516,7912,9339,6984,5766,9067,9089,1739,1038,574,3008,2066,8554,8472], () => (__webpack_exec__(3407)));
module.exports = __webpack_exports__;

})();