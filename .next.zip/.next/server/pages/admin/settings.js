"use strict";
(() => {
var exports = {};
exports.id = 577;
exports.ids = [577];
exports.modules = {

/***/ 3768:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ContainerInput)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);


const listDirection = {
    row: "flex flex-row gap-x-2 items-center",
    col: "flex flex-col gap-y-2"
};
function ContainerInput({ children , className , direction ="col"  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()(className, listDirection[direction]),
        children: children
    });
}


/***/ }),

/***/ 7851:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ insertSetting)
/* harmony export */ });
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9254);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_0__]);
___WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

function insertSetting(payload) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .postMethod */ .lx)("setting", payload);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9641:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ prismaClient)
/* harmony export */ });
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);

const prismaClient = new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient({
    errorFormat: "pretty",
    log: [
        "info",
        "query",
        "warn",
        "error"
    ]
});


/***/ }),

/***/ 1163:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Settings),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9089);
/* harmony import */ var _components_ui_Spinner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3508);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1257);
/* harmony import */ var _components_ui_card__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1739);
/* harmony import */ var _components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3768);
/* harmony import */ var _components_ui_form_input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3516);
/* harmony import */ var _components_ui_switch_toggle__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1788);
/* harmony import */ var _lib_api_setting__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7851);
/* harmony import */ var _lib_hookStore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6542);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9641);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(49);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9752);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout__WEBPACK_IMPORTED_MODULE_1__, _components_ui_button__WEBPACK_IMPORTED_MODULE_3__, _lib_api_setting__WEBPACK_IMPORTED_MODULE_8__, _lib_hookStore__WEBPACK_IMPORTED_MODULE_9__, _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_11__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_12__]);
([_components_layout__WEBPACK_IMPORTED_MODULE_1__, _components_ui_button__WEBPACK_IMPORTED_MODULE_3__, _lib_api_setting__WEBPACK_IMPORTED_MODULE_8__, _lib_hookStore__WEBPACK_IMPORTED_MODULE_9__, _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_11__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















async function getServerSideProps() {
    const response = await _lib_prisma__WEBPACK_IMPORTED_MODULE_10__/* .prismaClient.setting.findFirst */ .m.setting.findFirst();
    return {
        props: {
            setting: response || {}
        }
    };
}
function Settings({ setting  }) {
    const { 0: formSetting , 1: setFormSetting  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)(setting);
    const showToast = (0,_lib_hookStore__WEBPACK_IMPORTED_MODULE_9__/* .useDialogStore */ .IA)((state)=>state.showToast);
    const { mutate: mutateInsertSetting , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_12__.useMutation)({
        mutationFn: _lib_api_setting__WEBPACK_IMPORTED_MODULE_8__/* .insertSetting */ .G,
        onSuccess: ()=>showToast("success-update-setting"),
        onError: ()=>showToast("error-update-setting")
    });
    const onSaveSetting = ()=>{
        mutateInsertSetting(formSetting);
    };
    if (!Object.keys(setting).length) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout__WEBPACK_IMPORTED_MODULE_1__/* .Layout */ .A, {
            title: "Pengaturan"
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout__WEBPACK_IMPORTED_MODULE_1__/* .Layout */ .A, {
        title: "Pengaturan",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex gap-x-5",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "fixed left-1/2 top-4 z-[99999]",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .z, {
                        disabled: isLoading,
                        className: "!rounded-full",
                        size: "lg",
                        onClick: ()=>onSaveSetting(),
                        children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_Spinner__WEBPACK_IMPORTED_MODULE_2__/* .SpinnerIcon */ .L, {
                            width: "w-4",
                            height: "h-4"
                        }) : "Simpan"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex w-full flex-col gap-y-4",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_card__WEBPACK_IMPORTED_MODULE_4__/* .Card */ .Zb, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_card__WEBPACK_IMPORTED_MODULE_4__/* .CardContent */ .aY, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_card__WEBPACK_IMPORTED_MODULE_4__/* .CardHeader */ .Ol, {
                                    className: "pl-0 font-semibold pb-5",
                                    children: "Kontak"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "rounded-lg bg-gray-100 p-5",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        direction: "row",
                                        className: "w-full gap-x-5",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_11__.Label, {
                                                className: "uppercase",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_14__.FaWhatsapp, {
                                                    size: 26
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_6__/* .Input */ .I, {
                                                name: "whatsapp",
                                                placeholder: "Nomor Whatsapp",
                                                className: "!h-11",
                                                value: (formSetting === null || formSetting === void 0 ? void 0 : formSetting.no_wa) || "",
                                                onChange: (e)=>setFormSetting((state)=>({
                                                            ...state,
                                                            no_wa: e.target.value
                                                        }))
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_card__WEBPACK_IMPORTED_MODULE_4__/* .CardHeader */ .Ol, {
                                    className: "!pl-0 font-semibold",
                                    children: "Maintenance"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_switch_toggle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    checked: (formSetting === null || formSetting === void 0 ? void 0 : formSetting.is_maintenance) === "Y",
                                    text: (formSetting === null || formSetting === void 0 ? void 0 : formSetting.is_maintenance) === "Y" ? "Aktif" : "Tidak Aktif",
                                    onChange: (checked)=>{
                                        setFormSetting((state)=>({
                                                ...state,
                                                is_maintenance: checked ? "Y" : "N"
                                            }));
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_card__WEBPACK_IMPORTED_MODULE_4__/* .CardHeader */ .Ol, {
                                    className: "!pl-0 font-semibold",
                                    children: "Tampilkan Harga Produk"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_switch_toggle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    checked: (formSetting === null || formSetting === void 0 ? void 0 : formSetting.show_price) === "Y",
                                    text: (formSetting === null || formSetting === void 0 ? void 0 : formSetting.show_price) === "Y" ? "Aktif" : "Tidak Aktif",
                                    onChange: (checked)=>setFormSetting((state)=>({
                                                ...state,
                                                show_price: checked ? "Y" : "N"
                                            }))
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {})
                            ]
                        })
                    })
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 8625:
/***/ ((module) => {

module.exports = require("react-icons/ci");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 4751:
/***/ ((module) => {

module.exports = require("react-icons/io");

/***/ }),

/***/ 8510:
/***/ ((module) => {

module.exports = require("react-icons/lu");

/***/ }),

/***/ 4041:
/***/ ((module) => {

module.exports = require("react-icons/md");

/***/ }),

/***/ 150:
/***/ ((module) => {

module.exports = require("react-icons/pi");

/***/ }),

/***/ 8098:
/***/ ((module) => {

module.exports = require("react-icons/ri");

/***/ }),

/***/ 5452:
/***/ ((module) => {

module.exports = require("react-icons/rx");

/***/ }),

/***/ 1740:
/***/ ((module) => {

module.exports = require("react-icons/tfi");

/***/ }),

/***/ 382:
/***/ ((module) => {

module.exports = require("react-icons/vsc");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 49:
/***/ ((module) => {

module.exports = import("@radix-ui/react-label");;

/***/ }),

/***/ 4338:
/***/ ((module) => {

module.exports = import("@radix-ui/react-slot");;

/***/ }),

/***/ 9752:
/***/ ((module) => {

module.exports = import("@tanstack/react-query");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6926:
/***/ ((module) => {

module.exports = import("class-variance-authority");;

/***/ }),

/***/ 6912:
/***/ ((module) => {

module.exports = import("zustand");;

/***/ }),

/***/ 5237:
/***/ ((module) => {

module.exports = import("zustand/react/shallow");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5675,1257,9010,3516,9339,6984,5766,9089,1739], () => (__webpack_exec__(1163)));
module.exports = __webpack_exports__;

})();