(() => {
var exports = {};
exports.id = 1683;
exports.ids = [1683,4991];
exports.modules = {

/***/ 3208:
/***/ ((module) => {

// Exports
module.exports = {
	"wrapper-article": "article_wrapper-article__v_yxo",
	"article__title": "article_article__title__nXWil",
	"article__writer-name": "article_article__writer-name__yx4IF"
};


/***/ }),

/***/ 946:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ModalThumbnail)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1257);
/* harmony import */ var _components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3768);
/* harmony import */ var _components_ui_form_UploadFile__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5815);
/* harmony import */ var _components_ui_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7912);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(49);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__, _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__]);
([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__, _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function ModalThumbnail({ show , onHide , onSave  }) {
    const { 0: thumbnail , 1: setThumbnail  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_modal__WEBPACK_IMPORTED_MODULE_4__/* .Modal */ .u_, {
        show: show,
        onHide: onHide,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_modal__WEBPACK_IMPORTED_MODULE_4__/* .ModalHeader */ .xB, {
                onHide: onHide,
                children: "Ganti Thumbnail"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_modal__WEBPACK_IMPORTED_MODULE_4__/* .ModalBody */ .fe, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        className: "mb-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__.Label, {
                                children: "Thumbnail"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_UploadFile__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                maxFileSizeMb: 1.5,
                                onChange: (file, next)=>{
                                    next && next(file);
                                    setThumbnail(file[0]);
                                },
                                placeholder: "Thumbnail harus bertipe PNG, JPG, WEBP, GIF (Ukuran Maksimal 1.5Mb)",
                                accept: [
                                    "image/jpeg",
                                    "image/jpg",
                                    "image/png",
                                    "image/webp",
                                    "image/gif", 
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_1__/* .Button */ .z, {
                        disabled: !thumbnail,
                        className: "w-full",
                        size: "lg",
                        onClick: ()=>{
                            if (!thumbnail) return;
                            onSave(thumbnail);
                        },
                        children: "Ganti"
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7660:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ButtonBack)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1257);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_3__]);
___WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function ButtonBack({ onClick , className , text  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(___WEBPACK_IMPORTED_MODULE_3__/* .Button */ .z, {
        variant: "ghost",
        onClick: onClick,
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("flex cursor-pointer items-center gap-x-2 hover:bg-transparent", className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_2__.IoChevronBackOutline, {
                size: 20
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "text-gray-600",
                children: text ? text : "Kembali"
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7182:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9339);
/* harmony import */ var _tiptap_extension_blockquote__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7688);
/* harmony import */ var _tiptap_extension_dropcursor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8975);
/* harmony import */ var _tiptap_extension_heading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2678);
/* harmony import */ var _tiptap_extension_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4136);
/* harmony import */ var _tiptap_extension_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(140);
/* harmony import */ var _tiptap_extension_paragraph__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3766);
/* harmony import */ var _tiptap_extension_text_align__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7641);
/* harmony import */ var _tiptap_extension_underline__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7828);
/* harmony import */ var _tiptap_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3348);
/* harmony import */ var _tiptap_starter_kit__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8910);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8625);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_icons_ci__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react_icons_fa6__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8514);
/* harmony import */ var react_icons_fa6__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa6__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var react_icons_go__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(5856);
/* harmony import */ var react_icons_go__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_icons_go__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(5452);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(react_icons_rx__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var tiptap_extension_resize_image__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(7969);
/* harmony import */ var _Modal_ModalImage__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(9047);
/* harmony import */ var _Modal_ModalLink__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(9314);
/* harmony import */ var _ui_Heading__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(3198);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tiptap_extension_blockquote__WEBPACK_IMPORTED_MODULE_2__, _tiptap_extension_dropcursor__WEBPACK_IMPORTED_MODULE_3__, _tiptap_extension_heading__WEBPACK_IMPORTED_MODULE_4__, _tiptap_extension_image__WEBPACK_IMPORTED_MODULE_5__, _tiptap_extension_link__WEBPACK_IMPORTED_MODULE_6__, _tiptap_extension_paragraph__WEBPACK_IMPORTED_MODULE_7__, _tiptap_extension_text_align__WEBPACK_IMPORTED_MODULE_8__, _tiptap_extension_underline__WEBPACK_IMPORTED_MODULE_9__, _tiptap_react__WEBPACK_IMPORTED_MODULE_10__, _tiptap_starter_kit__WEBPACK_IMPORTED_MODULE_11__, tiptap_extension_resize_image__WEBPACK_IMPORTED_MODULE_21__, _Modal_ModalImage__WEBPACK_IMPORTED_MODULE_22__, _Modal_ModalLink__WEBPACK_IMPORTED_MODULE_23__]);
([_tiptap_extension_blockquote__WEBPACK_IMPORTED_MODULE_2__, _tiptap_extension_dropcursor__WEBPACK_IMPORTED_MODULE_3__, _tiptap_extension_heading__WEBPACK_IMPORTED_MODULE_4__, _tiptap_extension_image__WEBPACK_IMPORTED_MODULE_5__, _tiptap_extension_link__WEBPACK_IMPORTED_MODULE_6__, _tiptap_extension_paragraph__WEBPACK_IMPORTED_MODULE_7__, _tiptap_extension_text_align__WEBPACK_IMPORTED_MODULE_8__, _tiptap_extension_underline__WEBPACK_IMPORTED_MODULE_9__, _tiptap_react__WEBPACK_IMPORTED_MODULE_10__, _tiptap_starter_kit__WEBPACK_IMPORTED_MODULE_11__, tiptap_extension_resize_image__WEBPACK_IMPORTED_MODULE_21__, _Modal_ModalImage__WEBPACK_IMPORTED_MODULE_22__, _Modal_ModalLink__WEBPACK_IMPORTED_MODULE_23__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

























const initModal = Object.freeze({
    type: "",
    show: false
});
const initFormImage = Object.freeze({
    src: ""
});
const initFormLink = Object.freeze({
    link: "",
    newTab: ""
});
const Editor = ({ onChange , value , className  })=>{
    const wrapperRef = (0,react__WEBPACK_IMPORTED_MODULE_13__.useRef)();
    const editorRef = (0,react__WEBPACK_IMPORTED_MODULE_13__.useRef)(false);
    const { 0: focus , 1: setFocus  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)(false);
    const { 0: modal , 1: setModal  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)(initModal);
    const editor = (0,_tiptap_react__WEBPACK_IMPORTED_MODULE_10__.useEditor)({
        editorProps: {
            attributes: {
                class: "tiptap-editor"
            }
        },
        extensions: [
            _tiptap_starter_kit__WEBPACK_IMPORTED_MODULE_11__["default"].configure({
                paragraph: false
            }),
            _tiptap_extension_paragraph__WEBPACK_IMPORTED_MODULE_7__["default"],
            _tiptap_extension_underline__WEBPACK_IMPORTED_MODULE_9__["default"],
            _tiptap_extension_image__WEBPACK_IMPORTED_MODULE_5__["default"],
            _tiptap_extension_dropcursor__WEBPACK_IMPORTED_MODULE_3__["default"],
            tiptap_extension_resize_image__WEBPACK_IMPORTED_MODULE_21__["default"],
            _tiptap_extension_blockquote__WEBPACK_IMPORTED_MODULE_2__["default"],
            _tiptap_extension_heading__WEBPACK_IMPORTED_MODULE_4__["default"].configure({
                levels: [
                    1,
                    2,
                    3
                ]
            }),
            _tiptap_extension_text_align__WEBPACK_IMPORTED_MODULE_8__["default"].configure({
                types: [
                    "heading",
                    "paragraph"
                ]
            }),
            _tiptap_extension_link__WEBPACK_IMPORTED_MODULE_6__["default"]
        ],
        content: value,
        editable: true,
        injectCSS: false
    });
    (0,_lib_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useOnClickOutside */ .t$)(wrapperRef, ()=>{
        if (!wrapperRef.current) return;
        setFocus(false);
    });
    const onApplyImage = (form)=>{
        editor.chain().focus().setImage({
            src: form.src
        }).updateAttributes("image", {
            width: form.width,
            height: form.height
        }).run();
        setModal(initModal);
    };
    const onApplyLink = (form)=>{
        const link = {
            href: form.link
        };
        if (form.newTab) {
            link.target = "_blank";
        }
        editor.chain().focus().toggleLink(link).run();
        setModal(initModal);
    };
    // when ballon menu item clicked
    const onClickMenu = (menu, data)=>{
        switch(menu.name){
            case "bold":
                editor.chain().focus().toggleBold().run();
                break;
            case "italic":
                editor.chain().focus().toggleItalic().run();
                break;
            case "underline":
                editor.chain().focus().toggleUnderline().run();
                ``;
                break;
            case "image":
                setModal({
                    show: true,
                    type: "image"
                });
                break;
            case "heading":
                if (+data.id >= 1) {
                    editor.chain().focus().toggleHeading({
                        level: +data.id
                    }).run();
                    return;
                }
                editor.chain().focus().clearNodes().run();
                break;
            case "blockquote":
                editor.chain().focus().toggleBlockquote().run();
                break;
            case "strikethrough":
                editor.chain().focus().toggleStrike().run();
                break;
            case "text-center":
            case "text-left":
            case "text-right":
            case "text-justify":
                const align = {
                    "text-center": "center",
                    "text-left": "left",
                    "text-right": "right",
                    "text-justify": "justify"
                };
                editor.chain().focus().setTextAlign(align[menu.name]).run();
                break;
            case "link":
                setModal({
                    show: true,
                    type: "link",
                    data: initFormLink
                });
                break;
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_13__.useEffect)(()=>{
        if (editorRef.current || !editor) return;
        editorRef.current = true;
        editor.on("update", ({ editor  })=>{
            onChange(editor.getHTML().toString());
        });
    }, [
        editor
    ]);
    if (!editor) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            modal.show && modal.type === "image" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Modal_ModalImage__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                data: (modal === null || modal === void 0 ? void 0 : modal.data) || initFormImage,
                show: modal.show,
                title: "Upload Gambar Melalui URL",
                onHide: ()=>setModal(initModal),
                onApply: onApplyImage
            }),
            modal.show && modal.type === "link" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Modal_ModalLink__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {
                data: modal === null || modal === void 0 ? void 0 : modal.data,
                show: modal.show,
                title: "Link URL",
                onHide: ()=>setModal(initModal),
                onApply: onApplyLink
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_12___default()("relative", className),
                ref: wrapperRef,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BallonMenus, {
                        editor: editor,
                        setModal: setModal,
                        onClickMenu: onClickMenu,
                        show: focus
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tiptap_react__WEBPACK_IMPORTED_MODULE_10__.EditorContent, {
                        editor: editor,
                        onFocus: ()=>setFocus(true),
                        onChange: onChange
                    })
                ]
            })
        ]
    });
};
const menus = [
    {
        text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
        name: "heading",
        title: "Headings"
    },
    {
        text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_18__.FiBold, {}),
        name: "bold",
        title: "Bold"
    },
    {
        text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_18__.FiItalic, {}),
        name: "italic",
        title: "Italic"
    },
    {
        text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_14__.BsTypeUnderline, {}),
        name: "underline",
        title: "Underline"
    },
    {
        text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ci__WEBPACK_IMPORTED_MODULE_15__.CiImageOn, {}),
        name: "image",
        title: "URL Image"
    },
    {
        text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_go__WEBPACK_IMPORTED_MODULE_19__.GoQuote, {}),
        name: "blockquote",
        title: "Blockquote"
    },
    {
        text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_go__WEBPACK_IMPORTED_MODULE_19__.GoStrikethrough, {}),
        name: "strikethrough",
        title: "Strikethrough"
    },
    {
        text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_go__WEBPACK_IMPORTED_MODULE_19__.GoLink, {}),
        name: "link",
        title: "Link"
    },
    {
        text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa6__WEBPACK_IMPORTED_MODULE_17__.FaAlignJustify, {}),
        name: "text-alignment",
        sub: [
            {
                text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa6__WEBPACK_IMPORTED_MODULE_17__.FaAlignJustify, {}),
                name: "text-justify",
                title: "Justify"
            },
            {
                text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_16__.FaAlignLeft, {}),
                name: "text-left",
                title: "Left"
            },
            {
                text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_16__.FaAlignRight, {}),
                name: "text-right",
                title: "Right"
            },
            {
                text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa6__WEBPACK_IMPORTED_MODULE_17__.FaAlignCenter, {}),
                name: "text-center",
                title: "Center"
            }, 
        ]
    }, 
];
function BallonMenus({ editor , show , setModal , onClickMenu  }) {
    const getHeadingValue = ()=>{
        for(let i = 1; i <= 3; i++){
            if (editor.isActive("heading", {
                level: i
            })) return i;
        }
        return 0;
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_12___default()(" p-2 bg-white rounded-md shadow-md flex gap-x-2 transition-all duration-200", {
            "top-20 opacity-0 -z-10 absolute": !show,
            "top-20 z-[9999999] sticky": show
        }),
        children: menus.map((menu, key)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MenuItem, {
                isActiveUnderline: editor.isActive("underline"),
                isActiveItalic: editor.isActive("italic"),
                isActiveBold: editor.isActive("bold"),
                isActiveBlockQuote: editor.isActive("blockquote"),
                isActiveStrikeThrough: editor.isActive("strike"),
                isActiveLink: editor.isActive("link"),
                headingValue: getHeadingValue(),
                menu: menu,
                onClick: onClickMenu,
                editor: editor
            }, key))
    });
}
function MenuItem({ editor , menu , headingValue , onClick , isActiveLink , isActiveBold , isActiveItalic , isActiveUnderline , isActiveBlockQuote , isActiveStrikeThrough  }) {
    const { 0: dropdown , 1: setDropdown  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)(false);
    if (menu.name === "heading") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_Heading__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
            value: headingValue,
            onClickOption: (selected)=>onClick(menu, selected)
        });
    }
    const isActive = menu.name === "bold" && isActiveBold || menu.name === "italic" && isActiveItalic || menu.name === "underline" && isActiveUnderline || menu.name === "blockquote" && isActiveBlockQuote || menu.name === "strikethrough" && isActiveStrikeThrough || menu.name === "link" && isActiveLink;
    const getActiveTextAlignment = ()=>{
        const align = {
            left: "text-left",
            right: "text-right",
            center: "text-center",
            justify: "text-justify"
        };
        for(const prop in align){
            if (editor.isActive({
                textAlign: prop
            })) return align[prop];
        }
    };
    const isContainDropdown = !!(menu === null || menu === void 0 ? void 0 : menu.sub);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_12___default()({
            "flex items-justify relative": menu === null || menu === void 0 ? void 0 : menu.sub
        }),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                title: menu.title,
                className: classnames__WEBPACK_IMPORTED_MODULE_12___default()("p-1.5 hover:bg-primary  hover:text-white cursor-pointer", {
                    "bg-primary text-white": isActive,
                    "rounded-md": !isContainDropdown,
                    "rounded-l-md": isContainDropdown
                }),
                onClick: ()=>onClick(menu),
                children: (menu === null || menu === void 0 ? void 0 : menu.sub) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: menu.name === "text-alignment" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ActiveMenuTextAlignment, {
                        isActive: getActiveTextAlignment(),
                        menus: menu.sub
                    })
                }) : menu.text
            }),
            (menu === null || menu === void 0 ? void 0 : menu.sub) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                onClick: ()=>setDropdown((o)=>!o),
                className: classnames__WEBPACK_IMPORTED_MODULE_12___default()("cursor-pointer border-l hover:bg-primary h-full hover:text-white flex items-center rounded-r-md", {
                    "bg-primary text-white": dropdown
                }),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_rx__WEBPACK_IMPORTED_MODULE_20__.RxCaretDown, {})
            }),
            dropdown && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DropdownMenu, {
                menus: menu.sub,
                onClickMenu: onClick,
                isActive: getActiveTextAlignment()
            })
        ]
    });
}
function DropdownMenu({ menus , onClickMenu , isActive  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_12___default()(" flex flex-col gap-y-1  absolute top-8 -left-0 bg-white shadow-md rounded-b-md"),
        children: menus.map((menu, key)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                onClick: ()=>onClickMenu(menu),
                className: classnames__WEBPACK_IMPORTED_MODULE_12___default()("p-2 first:rounded-t-md last:rounded-b-md hover:bg-primary hover:text-white cursor-pointer", {
                    "bg-primary text-white": menu.name === isActive
                }),
                title: menu.title,
                children: menu.text
            }, key))
    });
}
function ActiveMenuTextAlignment({ isActive , menus  }) {
    const activeMenu = (0,react__WEBPACK_IMPORTED_MODULE_13__.useMemo)(()=>menus.find((menu)=>menu.name === isActive), []);
    return activeMenu.text;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Editor);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9047:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ModalImage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(49);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1257);
/* harmony import */ var _container_ContainerInput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3768);
/* harmony import */ var _form_input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3516);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7912);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_1__, _button__WEBPACK_IMPORTED_MODULE_3__]);
([_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_1__, _button__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function ModalImage({ data , title , show , onHide , onApply  }) {
    const { 0: form , 1: setForm  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(data);
    const onChange = (e)=>setForm((form)=>({
                ...form,
                [e.target.name]: e.target.value
            }));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_modal__WEBPACK_IMPORTED_MODULE_6__/* .Modal */ .u_, {
        show: show,
        onHide: onHide,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modal__WEBPACK_IMPORTED_MODULE_6__/* .ModalHeader */ .xB, {
                onHide: onHide,
                children: title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_modal__WEBPACK_IMPORTED_MODULE_6__/* .ModalBody */ .fe, {
                className: "flex flex-col gap-y-3",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_container_ContainerInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_1__.Label, {
                                className: "text-xs",
                                children: "Gambar URL"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_form_input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, {
                                placeholder: "Masukan URL",
                                name: "src",
                                value: form.src,
                                onChange: onChange
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_button__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .z, {
                        className: "w-full mt-3",
                        disabled: !form.src,
                        onClick: ()=>onApply(form),
                        children: "Terapkan"
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9314:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ModalLink)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(49);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1257);
/* harmony import */ var _container_ContainerInput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3768);
/* harmony import */ var _form_Checkbox__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5596);
/* harmony import */ var _form_input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3516);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7912);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_1__, _button__WEBPACK_IMPORTED_MODULE_3__]);
([_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_1__, _button__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








function ModalLink({ data , title , show , onHide , onApply  }) {
    const { 0: form , 1: setForm  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(data);
    const onChange = (e)=>setForm((form)=>({
                ...form,
                [e.target.name]: e.target.value
            }));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_modal__WEBPACK_IMPORTED_MODULE_7__/* .Modal */ .u_, {
        verticallyCentered: true,
        className: "w-[450px]",
        show: show,
        onHide: onHide,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modal__WEBPACK_IMPORTED_MODULE_7__/* .ModalHeader */ .xB, {
                onHide: onHide,
                children: title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_modal__WEBPACK_IMPORTED_MODULE_7__/* .ModalBody */ .fe, {
                className: "flex flex-col gap-y-3",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_container_ContainerInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_1__.Label, {
                                className: "text-xs",
                                children: "Link"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_form_input__WEBPACK_IMPORTED_MODULE_6__/* .Input */ .I, {
                                placeholder: "Masukan Link URL",
                                name: "link",
                                value: form.link,
                                onChange: onChange
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_form_Checkbox__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-gray-500 text-xs",
                            children: "Buka Tab baru"
                        }),
                        checked: form.newTab,
                        onChange: ()=>setForm((form)=>({
                                    ...form,
                                    newTab: !form.newTab
                                }))
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_button__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .z, {
                        className: "w-full mt-3",
                        disabled: !form.link,
                        onClick: ()=>onApply(form),
                        children: "Terapkan"
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3198:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Heading)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(873);
/* harmony import */ var _form_Select__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2066);



const headings = {
    0: "Normal",
    1: "Heading 1",
    2: "Heading 2",
    3: "Heading 3"
};
function Heading({ value , onClickOption  }) {
    const getHeading = (heading, content)=>{
        if (heading === "0") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: content
        });
        if (heading === "1") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
            children: content
        });
        if (heading === "2") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
            children: content
        });
        if (heading === "3") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
            children: content
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_form_Select__WEBPACK_IMPORTED_MODULE_2__/* .Selection */ .Y1, {
        placeholder: "Normal",
        enableSearch: false,
        className: "w-[150px] !h-[30px] !pt-1.5 !pl-2.5 !text-xs",
        classNameToggle: "!-top-1",
        options: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_1__/* .convertObjToDataSelection */ .uN)(headings) || [],
        onClickOption: onClickOption,
        customItemSelection: (item)=>getHeading(item.id, item.text),
        value: (headings === null || headings === void 0 ? void 0 : headings[value]) || ""
    });
}


/***/ }),

/***/ 4991:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Vr": () => (/* binding */ getArticleById),
/* harmony export */   "Xc": () => (/* binding */ updateArticle),
/* harmony export */   "fq": () => (/* binding */ getArticle),
/* harmony export */   "jX": () => (/* binding */ deleteArticle),
/* harmony export */   "tu": () => (/* binding */ createArticle),
/* harmony export */   "vX": () => (/* binding */ getArticleBySlug)
/* harmony export */ });
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9254);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(873);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_0__]);
___WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function getArticle(params) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)("article", {
        params
    });
}
function createArticle(payload) {
    const formPayload = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .objectIntoFormData */ .rW)(payload);
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .postMethod */ .lx)("article", formPayload);
}
function updateArticle(id, payload) {
    const formPayload = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .objectIntoFormData */ .rW)(payload);
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .putMethod */ .yu)(`article/${id}`, formPayload);
}
function getArticleById(id) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)(`article/${id}`);
}
function getArticleBySlug(slug) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)(`article/slug/${slug}`);
}
function deleteArticle(id) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .deleteMethod */ .SR)(`article/${id}`);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8915:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Edit),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_features_article_module_scss__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(3208);
/* harmony import */ var _components_features_article_module_scss__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_components_features_article_module_scss__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _components_features_article_ModalThumbnail__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(946);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9089);
/* harmony import */ var _components_ui_Spinner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3508);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1257);
/* harmony import */ var _components_ui_button_ButtonBack__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7660);
/* harmony import */ var _components_ui_editor_Editor__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7182);
/* harmony import */ var _lib_api_articles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4991);
/* harmony import */ var _lib_hookStore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6542);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(873);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9752);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6563);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_contenteditable__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8625);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_icons_ci__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_19__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_features_article_ModalThumbnail__WEBPACK_IMPORTED_MODULE_1__, _components_layout__WEBPACK_IMPORTED_MODULE_2__, _components_ui_button__WEBPACK_IMPORTED_MODULE_4__, _components_ui_button_ButtonBack__WEBPACK_IMPORTED_MODULE_5__, _components_ui_editor_Editor__WEBPACK_IMPORTED_MODULE_6__, _lib_api_articles__WEBPACK_IMPORTED_MODULE_7__, _lib_hookStore__WEBPACK_IMPORTED_MODULE_8__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_10__]);
([_components_features_article_ModalThumbnail__WEBPACK_IMPORTED_MODULE_1__, _components_layout__WEBPACK_IMPORTED_MODULE_2__, _components_ui_button__WEBPACK_IMPORTED_MODULE_4__, _components_ui_button_ButtonBack__WEBPACK_IMPORTED_MODULE_5__, _components_ui_editor_Editor__WEBPACK_IMPORTED_MODULE_6__, _lib_api_articles__WEBPACK_IMPORTED_MODULE_7__, _lib_hookStore__WEBPACK_IMPORTED_MODULE_8__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





















const initModal = Object.freeze({
    type: "",
    show: false
});
async function getServerSideProps(context) {
    var ref;
    const id = context.params.id;
    const response = await (0,_lib_api_articles__WEBPACK_IMPORTED_MODULE_7__/* .getArticleById */ .Vr)(+id);
    if (!((ref = response.data) === null || ref === void 0 ? void 0 : ref.data)) return {
        notFound: true
    };
    return {
        props: {
            data: response.data.data || {}
        }
    };
}
function Edit({ data  }) {
    var ref;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_14__.useRouter)();
    const id = (ref = router.query) === null || ref === void 0 ? void 0 : ref.id;
    const { 0: article , 1: setArticle  } = (0,react__WEBPACK_IMPORTED_MODULE_15__.useState)(data);
    const { 0: modal , 1: setModal  } = (0,react__WEBPACK_IMPORTED_MODULE_15__.useState)(initModal);
    const { 0: tempThumbnail , 1: setTempThumbnail  } = (0,react__WEBPACK_IMPORTED_MODULE_15__.useState)("");
    const showToast = (0,_lib_hookStore__WEBPACK_IMPORTED_MODULE_8__/* .useDialogStore */ .IA)((state)=>state.showToast);
    const { mutate: mutateUpdateArticle , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_10__.useMutation)({
        mutationFn: (payload)=>(0,_lib_api_articles__WEBPACK_IMPORTED_MODULE_7__/* .updateArticle */ .Xc)(+id, payload),
        onSuccess: ()=>{
            showToast("success-update-article");
            next_router__WEBPACK_IMPORTED_MODULE_14___default().push("/admin/articles");
        },
        onError: ()=>showToast("error-update-article")
    });
    const onClickThumbnail = (thumbnail)=>{
        setModal({
            show: true,
            type: "thumbnail",
            data: thumbnail
        });
    };
    const onSaveThumbnail = (file)=>{
        setModal(initModal);
        setTempThumbnail(file);
    };
    const onUpdateContent = (name, value)=>{
        setArticle((article)=>({
                ...article,
                [name]: value
            }));
    };
    const onSave = ()=>{
        const { created_at , id , slug , updated_at , viewers_id , thumbnail , ...payload } = article;
        if (tempThumbnail) {
            payload.thumbnail = tempThumbnail;
        }
        mutateUpdateArticle(payload);
    };
    const getThumbnail = (thumbnail)=>{
        return URL.createObjectURL(thumbnail);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_layout__WEBPACK_IMPORTED_MODULE_2__/* .Layout */ .A, {
        title: "Ubah Artikel",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ButtonAction, {
                article: article,
                isLoading: isLoading,
                onSave: onSave
            }),
            modal.show && modal.type === "thumbnail" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_features_article_ModalThumbnail__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                show: true,
                onHide: ()=>setModal(initModal),
                onSave: onSaveThumbnail
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button_ButtonBack__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                onClick: ()=>next_router__WEBPACK_IMPORTED_MODULE_14___default().push("/admin/articles")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_components_features_article_module_scss__WEBPACK_IMPORTED_MODULE_20___default()["wrapper-article"]),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_16___default()), {
                        tagName: "div",
                        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_components_features_article_module_scss__WEBPACK_IMPORTED_MODULE_20___default().article__title), "hover:border-primary border-2 pl-1.5 pr-3 border-transparent"),
                        html: article.title,
                        onChange: (e)=>onUpdateContent("title", e.target.value)
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex justify-between mt-2.5 mb-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center gap-x-1.5 ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_18__.FiUser, {
                                        size: 14,
                                        color: "gray"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_16___default()), {
                                        tagName: "span",
                                        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_components_features_article_module_scss__WEBPACK_IMPORTED_MODULE_20___default()["article__writer-name"]), "hover:border-primary border-2 pl-1.5 pr-3 border-transparent"),
                                        html: article.writer,
                                        onChange: (e)=>onUpdateContent("writer", e.target.value)
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "text-gray-400 text-xs flex gap-x-1 items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_19__.IoMdTime, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: dayjs__WEBPACK_IMPORTED_MODULE_12___default()(article.created_at).format("DD MMMM YYYY Pukul HH:mm WIB")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col gap-y-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "relative group hover:border-primary border-4 border-transparent cursor-pointer hover:border-4 hover:rounded-sm",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_13___default()), {
                                        className: "object-cover rounded-sm ",
                                        alt: article.title || "-",
                                        src: tempThumbnail ? getThumbnail(tempThumbnail) : (0,_lib_utils__WEBPACK_IMPORTED_MODULE_9__/* .mediaPath */ .hf)("articles-thumbnail", article.thumbnail),
                                        width: 800,
                                        height: 500
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "hidden group-hover:block absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_4__/* .Button */ .z, {
                                            className: "flex gap-x-2",
                                            onClick: ()=>onClickThumbnail(article.thumbnail),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ci__WEBPACK_IMPORTED_MODULE_17__.CiImageOn, {
                                                    size: 20
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "text-sm",
                                                    children: "Ganti Thumbnail"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_editor_Editor__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                value: data.content,
                                onChange: (content)=>onUpdateContent("content", content)
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
function ButtonAction({ article , isLoading , onSave  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex gap-x-2 fixed top-5 left-1/2 z-[99999]",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_4__/* .Button */ .z, {
                onClick: ()=>window.open(`/${article.slug}`),
                variant: "ghost",
                className: "border border-gray-600 gap-x-2 flex items-center justify-center !rounded-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_19__.IoIosGlobe, {
                        size: 20
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Lihat Artikel"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_4__/* .Button */ .z, {
                disabled: isLoading,
                className: "!rounded-full",
                size: "lg",
                onClick: ()=>onSave(),
                children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_Spinner__WEBPACK_IMPORTED_MODULE_3__/* .SpinnerIcon */ .L, {
                    width: "w-4",
                    height: "h-4"
                }) : "Simpan"
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6563:
/***/ ((module) => {

"use strict";
module.exports = require("react-contenteditable");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bs");

/***/ }),

/***/ 8625:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ci");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 8514:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa6");

/***/ }),

/***/ 2750:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fi");

/***/ }),

/***/ 5856:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/go");

/***/ }),

/***/ 4751:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/io");

/***/ }),

/***/ 9989:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/io5");

/***/ }),

/***/ 8510:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/lu");

/***/ }),

/***/ 4041:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/md");

/***/ }),

/***/ 150:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/pi");

/***/ }),

/***/ 8098:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ri");

/***/ }),

/***/ 5452:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/rx");

/***/ }),

/***/ 1740:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/tfi");

/***/ }),

/***/ 382:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/vsc");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 49:
/***/ ((module) => {

"use strict";
module.exports = import("@radix-ui/react-label");;

/***/ }),

/***/ 4338:
/***/ ((module) => {

"use strict";
module.exports = import("@radix-ui/react-slot");;

/***/ }),

/***/ 9752:
/***/ ((module) => {

"use strict";
module.exports = import("@tanstack/react-query");;

/***/ }),

/***/ 7688:
/***/ ((module) => {

"use strict";
module.exports = import("@tiptap/extension-blockquote");;

/***/ }),

/***/ 8975:
/***/ ((module) => {

"use strict";
module.exports = import("@tiptap/extension-dropcursor");;

/***/ }),

/***/ 2678:
/***/ ((module) => {

"use strict";
module.exports = import("@tiptap/extension-heading");;

/***/ }),

/***/ 4136:
/***/ ((module) => {

"use strict";
module.exports = import("@tiptap/extension-image");;

/***/ }),

/***/ 140:
/***/ ((module) => {

"use strict";
module.exports = import("@tiptap/extension-link");;

/***/ }),

/***/ 3766:
/***/ ((module) => {

"use strict";
module.exports = import("@tiptap/extension-paragraph");;

/***/ }),

/***/ 7641:
/***/ ((module) => {

"use strict";
module.exports = import("@tiptap/extension-text-align");;

/***/ }),

/***/ 7828:
/***/ ((module) => {

"use strict";
module.exports = import("@tiptap/extension-underline");;

/***/ }),

/***/ 3348:
/***/ ((module) => {

"use strict";
module.exports = import("@tiptap/react");;

/***/ }),

/***/ 8910:
/***/ ((module) => {

"use strict";
module.exports = import("@tiptap/starter-kit");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 6926:
/***/ ((module) => {

"use strict";
module.exports = import("class-variance-authority");;

/***/ }),

/***/ 7969:
/***/ ((module) => {

"use strict";
module.exports = import("tiptap-extension-resize-image");;

/***/ }),

/***/ 6912:
/***/ ((module) => {

"use strict";
module.exports = import("zustand");;

/***/ }),

/***/ 5237:
/***/ ((module) => {

"use strict";
module.exports = import("zustand/react/shallow");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5675,5152,1257,9010,3516,7912,9339,6984,5766,9089,1739,1038,2066], () => (__webpack_exec__(8915)));
module.exports = __webpack_exports__;

})();