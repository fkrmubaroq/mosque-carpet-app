"use strict";
(() => {
var exports = {};
exports.id = 6401;
exports.ids = [6401];
exports.modules = {

/***/ 7660:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ButtonBack)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1257);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_3__]);
___WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function ButtonBack({ onClick , className , text  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(___WEBPACK_IMPORTED_MODULE_3__/* .Button */ .z, {
        variant: "ghost",
        onClick: onClick,
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("flex cursor-pointer items-center gap-x-2 hover:bg-transparent", className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_2__.IoChevronBackOutline, {
                size: 20
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "text-gray-600",
                children: text ? text : "Kembali"
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9482:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ButtonWhatsapp)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1257);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_2__]);
___WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function ButtonWhatsapp({ phone  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "fixed bottom-6 right-4 z-50 shadow-sm ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(___WEBPACK_IMPORTED_MODULE_2__/* .Button */ .z, {
            className: "flex !rounded-full !h-16 w-16 items-center justify-center !bg-[#25d366]",
            onClick: ()=>phone && window.open(`https://wa.me/${phone}`),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_1__.AiOutlineWhatsApp, {
                size: 30
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9743:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BD": () => (/* binding */ insertCategory),
/* harmony export */   "fj": () => (/* binding */ getCategoryBySlug),
/* harmony export */   "n3": () => (/* binding */ getCategory),
/* harmony export */   "uu": () => (/* binding */ deleteCategory),
/* harmony export */   "yr": () => (/* binding */ updateCategory)
/* harmony export */ });
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9254);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(873);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_0__]);
___WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function getCategory(params) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)("category", {
        params
    });
}
function insertCategory(payload) {
    const formPayload = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .objectIntoFormData */ .rW)(payload);
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .postMethod */ .lx)("category", formPayload);
}
function updateCategory(payload) {
    const formPayload = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .objectIntoFormData */ .rW)(payload);
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .putMethod */ .yu)("category", formPayload);
}
function deleteCategory(id) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .deleteMethod */ .SR)(`category/${id}`);
}
function getCategoryBySlug(slug) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)(`category/slug/${slug}`);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9599:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$A": () => (/* binding */ getProductByName),
/* harmony export */   "G4": () => (/* binding */ updateToggleStatus),
/* harmony export */   "Ir": () => (/* binding */ deleteProduct),
/* harmony export */   "dN": () => (/* binding */ insertProduct),
/* harmony export */   "de": () => (/* binding */ getAllProduct),
/* harmony export */   "nM": () => (/* binding */ updateProduct),
/* harmony export */   "uP": () => (/* binding */ getProductByCategory)
/* harmony export */ });
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9254);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(873);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_0__]);
___WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function insertProduct(payload) {
    const formPayload = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .objectIntoFormData */ .rW)(payload);
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .postMethod */ .lx)("product", formPayload);
}
function updateProduct(payload) {
    const formPayload = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .objectIntoFormData */ .rW)(payload);
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .putMethod */ .yu)("product", formPayload);
}
function getAllProduct(params) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)("product", {
        params
    });
}
function getProductByCategory(categoryName) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)(`product/category/${categoryName}`);
}
function getProductByName(name) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)(`product/name/${name}`);
}
function deleteProduct(productId) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .deleteMethod */ .SR)(`product/${productId}`);
}
function updateToggleStatus(productId) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .patchMethod */ .K7)(`product/${productId}/update-status`);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 789:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ProductByName),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_features_sections_SectionFooter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(458);
/* harmony import */ var _components_layout_Header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(617);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1257);
/* harmony import */ var _components_ui_button_ButtonBack__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7660);
/* harmony import */ var _components_ui_button_ButtonWa__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9482);
/* harmony import */ var _lib_api_category__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9743);
/* harmony import */ var _lib_api_product__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9599);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2470);
/* harmony import */ var _lib_hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9339);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9641);
/* harmony import */ var _lib_queryKeys__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9067);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(873);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9752);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var swiper_modules__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2184);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(3015);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_features_sections_SectionFooter__WEBPACK_IMPORTED_MODULE_1__, _components_layout_Header__WEBPACK_IMPORTED_MODULE_2__, _components_ui_button__WEBPACK_IMPORTED_MODULE_3__, _components_ui_button_ButtonBack__WEBPACK_IMPORTED_MODULE_4__, _components_ui_button_ButtonWa__WEBPACK_IMPORTED_MODULE_5__, _lib_api_category__WEBPACK_IMPORTED_MODULE_6__, _lib_api_product__WEBPACK_IMPORTED_MODULE_7__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_13__, swiper_modules__WEBPACK_IMPORTED_MODULE_18__, swiper_react__WEBPACK_IMPORTED_MODULE_19__]);
([_components_features_sections_SectionFooter__WEBPACK_IMPORTED_MODULE_1__, _components_layout_Header__WEBPACK_IMPORTED_MODULE_2__, _components_ui_button__WEBPACK_IMPORTED_MODULE_3__, _components_ui_button_ButtonBack__WEBPACK_IMPORTED_MODULE_4__, _components_ui_button_ButtonWa__WEBPACK_IMPORTED_MODULE_5__, _lib_api_category__WEBPACK_IMPORTED_MODULE_6__, _lib_api_product__WEBPACK_IMPORTED_MODULE_7__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_13__, swiper_modules__WEBPACK_IMPORTED_MODULE_18__, swiper_react__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






















async function getServerSideProps() {
    const prismaSections = await _lib_prisma__WEBPACK_IMPORTED_MODULE_10__/* .prismaClient.sections.findMany */ .m.sections.findMany({
        orderBy: {
            position: "asc"
        },
        where: {
            active: "Y"
        }
    });
    const prismaSetting = await _lib_prisma__WEBPACK_IMPORTED_MODULE_10__/* .prismaClient.setting.findFirst */ .m.setting.findFirst();
    return {
        props: {
            sections: prismaSections || [],
            setting: prismaSetting || {}
        }
    };
}
function ProductByName({ sections , setting  }) {
    var ref;
    const mobile = (0,_lib_hooks__WEBPACK_IMPORTED_MODULE_9__/* .useMobile */ .XA)();
    const getContentSection = (sectionName)=>{
        const section = sections.find((section)=>section.section_name === sectionName);
        const content = JSON.parse((section === null || section === void 0 ? void 0 : section.content) || "{}");
        return {
            ...section,
            content
        };
    };
    const content = (ref = getContentSection("section_hero")) === null || ref === void 0 ? void 0 : ref.content;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_Header__WEBPACK_IMPORTED_MODULE_2__/* .Header */ .h, {
                noTransparent: true,
                fixedHeader: true,
                mobile: mobile,
                content: content,
                menus: (content === null || content === void 0 ? void 0 : content.menus) || []
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_14___default()("pt-20 lg:pt-32", _lib_constant__WEBPACK_IMPORTED_MODULE_8__/* .CONTAINER_LP */ .oc),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SectionDetailProduct, {
                    mobile: mobile,
                    setting: setting
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_features_sections_SectionFooter__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                section: getContentSection("section_footer")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button_ButtonWa__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                phone: ""
            })
        ]
    });
}
function SectionDetailProduct({ mobile , setting  }) {
    var ref, ref1;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_16__.useRouter)();
    const slug = (ref = router.query) === null || ref === void 0 ? void 0 : ref.name;
    const { data , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_13__.useQuery)({
        queryKey: _lib_queryKeys__WEBPACK_IMPORTED_MODULE_11__/* .productsQuery.detailProduct */ .jE.detailProduct(slug),
        queryFn: async ()=>{
            var ref;
            const response = await (0,_lib_api_product__WEBPACK_IMPORTED_MODULE_7__/* .getProductByName */ .$A)(slug);
            return ((ref = response.data) === null || ref === void 0 ? void 0 : ref.data) || [];
        }
    });
    const { data: categories  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_13__.useQuery)({
        queryKey: _lib_queryKeys__WEBPACK_IMPORTED_MODULE_11__/* .productsQuery.similarCategory */ .jE.similarCategory(slug),
        queryFn: async ()=>{
            var ref;
            const response = await (0,_lib_api_category__WEBPACK_IMPORTED_MODULE_6__/* .getCategoryBySlug */ .fj)(slug);
            return ((ref = response.data) === null || ref === void 0 ? void 0 : ref.data) || [];
        }
    });
    const getSlidePerPreviewByScreen = ()=>{
        if (mobile === null || mobile === void 0 ? void 0 : mobile.mobileSm) return 1;
        if (mobile === null || mobile === void 0 ? void 0 : mobile.mobileMd) return 2;
        return 4;
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button_ButtonBack__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                className: "mb-3 pl-0 hover:bg-transparent",
                onClick: ()=>window.history.back(-1),
                text: "Kembali"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col lg:flex-row gap-x-10 mb-32",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ProductImage, {
                        data: data
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ProductInfo, {
                        data: data,
                        setting: setting
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: "Jenis Serupa"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_19__.Swiper, {
                        slidesPerView: getSlidePerPreviewByScreen(),
                        spaceBetween: 20,
                        navigation: true,
                        loop: true,
                        modules: [
                            swiper_modules__WEBPACK_IMPORTED_MODULE_18__.Navigation
                        ],
                        className: "swipper-category",
                        children: categories === null || categories === void 0 ? void 0 : (ref1 = categories.data) === null || ref1 === void 0 ? void 0 : ref1.map((item, key)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_19__.SwiperSlide, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PreviewData, {
                                    data: item
                                })
                            }, key))
                    })
                ]
            })
        ]
    });
}
function ProductImage({ data  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "shrink-0 lg:block flex justify-center",
        children: (data === null || data === void 0 ? void 0 : data.image) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
            className: "aspect-auto",
            src: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_12__/* .mediaPath */ .hf)("products", data.image),
            width: 600,
            height: 500,
            alt: ""
        })
    });
}
function ProductInfo({ data , setting  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col justify-between w-full",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col gap-y-2 border-b pb-5 mb-5",
                        children: [
                            (data === null || data === void 0 ? void 0 : data.category_name) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-gray-500 uppercase text-lg tracking-wider",
                                children: data.category_name
                            }),
                            (data === null || data === void 0 ? void 0 : data.name) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-semibold text-slate-800 text-xl tracking-wide",
                                children: data.name
                            }),
                            (data === null || data === void 0 ? void 0 : data.price) && (setting === null || setting === void 0 ? void 0 : setting.no_wa) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "text-primary text-2xl font-semibold tracking-wide",
                                children: [
                                    "Rp ",
                                    (0,_lib_utils__WEBPACK_IMPORTED_MODULE_12__/* .formatNumberToPrice */ .xt)(data.price)
                                ]
                            })
                        ]
                    }),
                    (data === null || data === void 0 ? void 0 : data.description) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col gap-y-3 mb-5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "text-xl tracking-wide text-gray-600 font-semibold",
                                children: "Deskripsi"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-gray-500 tracking-wide text-justify",
                                children: data.description
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "lg:mt-0 mt-4 mb-10",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .z, {
                    className: "w-full !p-6 !rounded-none flex gap-x-2 uppercase",
                    onClick: ()=>window.open(`https://wa.me/${setting.no_wa}`),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_17__.FaWhatsapp, {
                            size: 20
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: "Pesan melalui Whatsapp"
                        })
                    ]
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6563:
/***/ ((module) => {

module.exports = require("react-contenteditable");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 8625:
/***/ ((module) => {

module.exports = require("react-icons/ci");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 1111:
/***/ ((module) => {

module.exports = require("react-icons/hi");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 8510:
/***/ ((module) => {

module.exports = require("react-icons/lu");

/***/ }),

/***/ 5452:
/***/ ((module) => {

module.exports = require("react-icons/rx");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 49:
/***/ ((module) => {

module.exports = import("@radix-ui/react-label");;

/***/ }),

/***/ 4338:
/***/ ((module) => {

module.exports = import("@radix-ui/react-slot");;

/***/ }),

/***/ 9752:
/***/ ((module) => {

module.exports = import("@tanstack/react-query");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6926:
/***/ ((module) => {

module.exports = import("class-variance-authority");;

/***/ }),

/***/ 2184:
/***/ ((module) => {

module.exports = import("swiper/modules");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5675,5152,1257,9010,3516,7912,9339,9067,2872,617], () => (__webpack_exec__(789)));
module.exports = __webpack_exports__;

})();