"use strict";
(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405];
exports.modules = {

/***/ 9482:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ButtonWhatsapp)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1257);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_2__]);
___WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function ButtonWhatsapp({ phone  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "fixed bottom-6 right-4 z-50 shadow-sm ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(___WEBPACK_IMPORTED_MODULE_2__/* .Button */ .z, {
            className: "flex !rounded-full !h-16 w-16 items-center justify-center !bg-[#25d366]",
            onClick: ()=>phone && window.open(`https://wa.me/${phone}`),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_1__.AiOutlineWhatsApp, {
                size: 30
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4325:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_features_sections_Fragment_SectionTitle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5613);
/* harmony import */ var _components_features_sections_SectionAboutUs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9432);
/* harmony import */ var _components_features_sections_SectionArticles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1872);
/* harmony import */ var _components_features_sections_SectionContactUs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9827);
/* harmony import */ var _components_features_sections_SectionFooter__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(458);
/* harmony import */ var _components_features_sections_SectionHero__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5817);
/* harmony import */ var _components_features_sections_SectionMapAddress__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7781);
/* harmony import */ var _components_features_sections_SectionOurProducts__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2143);
/* harmony import */ var _components_features_sections_SectionVisionMision__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5385);
/* harmony import */ var _components_features_sections_SectionWhyChooseUs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9780);
/* harmony import */ var _components_ui_button_ButtonWa__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9482);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2470);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9641);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(873);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_features_sections_SectionAboutUs__WEBPACK_IMPORTED_MODULE_5__, _components_features_sections_SectionArticles__WEBPACK_IMPORTED_MODULE_6__, _components_features_sections_SectionContactUs__WEBPACK_IMPORTED_MODULE_7__, _components_features_sections_SectionFooter__WEBPACK_IMPORTED_MODULE_8__, _components_features_sections_SectionHero__WEBPACK_IMPORTED_MODULE_9__, _components_features_sections_SectionMapAddress__WEBPACK_IMPORTED_MODULE_10__, _components_features_sections_SectionOurProducts__WEBPACK_IMPORTED_MODULE_11__, _components_features_sections_SectionWhyChooseUs__WEBPACK_IMPORTED_MODULE_13__, _components_ui_button_ButtonWa__WEBPACK_IMPORTED_MODULE_14__]);
([_components_features_sections_SectionAboutUs__WEBPACK_IMPORTED_MODULE_5__, _components_features_sections_SectionArticles__WEBPACK_IMPORTED_MODULE_6__, _components_features_sections_SectionContactUs__WEBPACK_IMPORTED_MODULE_7__, _components_features_sections_SectionFooter__WEBPACK_IMPORTED_MODULE_8__, _components_features_sections_SectionHero__WEBPACK_IMPORTED_MODULE_9__, _components_features_sections_SectionMapAddress__WEBPACK_IMPORTED_MODULE_10__, _components_features_sections_SectionOurProducts__WEBPACK_IMPORTED_MODULE_11__, _components_features_sections_SectionWhyChooseUs__WEBPACK_IMPORTED_MODULE_13__, _components_ui_button_ButtonWa__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




// import required modules














async function getServerSideProps() {
    const prismaSections = await _lib_prisma__WEBPACK_IMPORTED_MODULE_16__/* .prismaClient.sections.findMany */ .m.sections.findMany({
        orderBy: {
            position: "asc"
        },
        where: {
            active: "Y"
        }
    });
    const prismaSetting = await _lib_prisma__WEBPACK_IMPORTED_MODULE_16__/* .prismaClient.setting.findFirst */ .m.setting.findFirst();
    return {
        props: {
            sections: prismaSections || [],
            setting: prismaSetting || {}
        }
    };
}
function Home({ sections , setting  }) {
    const { 0: mobileMd , 1: setMobileMdWidth  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { 0: mobileSm , 1: setMobileSm  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const mobile = {
        mobileMd,
        mobileSm
    };
    const getContentSection = (sectionName)=>{
        const section = sections.find((section)=>section.section_name === sectionName);
        const content = JSON.parse((section === null || section === void 0 ? void 0 : section.content) || "{}");
        return {
            ...section,
            content
        };
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        const checkScreenWidth = ()=>{
            const width = window.innerWidth;
            const mobileMdWidth = width <= 968;
            const mobileSmWidth = width <= 640;
            if (mobileSmWidth) {
                setMobileSm(true);
                setMobileMdWidth(false);
                return;
            }
            setMobileSm(false);
            setMobileMdWidth(mobileMdWidth);
        };
        const debounceCheckScreenWidth = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_17__/* .debounce */ .Ds)(checkScreenWidth);
        debounceCheckScreenWidth();
        window.addEventListener("resize", debounceCheckScreenWidth);
        return ()=>window.removeEventListener("resize", debounceCheckScreenWidth);
    }, [
        mobile
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
        className: "min-h-screen",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_features_sections_SectionHero__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                mobile: mobile,
                section: getContentSection("section_hero")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()(_lib_constant__WEBPACK_IMPORTED_MODULE_15__/* .CONTAINER_LP */ .oc, "px-4"),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_features_sections_SectionAboutUs__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        section: getContentSection("section_about_us")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_features_sections_SectionVisionMision__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        section: getContentSection("section_vision_mision")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_features_sections_SectionWhyChooseUs__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                        section: getContentSection("section_why_choose_us")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_features_sections_SectionContactUs__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        setting: setting,
                        mobile: mobile,
                        section: getContentSection("section_contact_us")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_features_sections_SectionArticles__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        mobile: mobile
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_features_sections_SectionOurProducts__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        mobile: mobile
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_features_sections_SectionMapAddress__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        section: getContentSection("section_map_address"),
                        mobile: mobile
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_features_sections_SectionFooter__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                setting: setting,
                section: getContentSection("section_footer")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button_ButtonWa__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                phone: setting === null || setting === void 0 ? void 0 : setting.no_wa
            })
        ]
    });
}
const partners = (/* unused pure expression or super */ null && ([
    "partner-1.webp",
    "partner-2.webp",
    "partner-3.webp",
    "partner-4.webp", 
]));
function SectionOurPartner() {
    return /*#__PURE__*/ _jsxs("section", {
        className: "lg:mb-[100px]",
        children: [
            /*#__PURE__*/ _jsx(SectionTitle, {
                context: "BRAND",
                title: /*#__PURE__*/ _jsxs(_Fragment, {
                    children: [
                        "Our Brand ",
                        /*#__PURE__*/ _jsx("span", {
                            className: "text-green-700",
                            children: "PARTNERS"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "flex gap-x-3 justify-around",
                children: partners.map((fileName, key)=>/*#__PURE__*/ _jsx(Image, {
                        src: `/img/partners/${fileName}`,
                        width: "240",
                        height: "100",
                        alt: "",
                        className: "object-contain"
                    }, key))
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6563:
/***/ ((module) => {

module.exports = require("react-contenteditable");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 8625:
/***/ ((module) => {

module.exports = require("react-icons/ci");

/***/ }),

/***/ 8514:
/***/ ((module) => {

module.exports = require("react-icons/fa6");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 1111:
/***/ ((module) => {

module.exports = require("react-icons/hi");

/***/ }),

/***/ 8510:
/***/ ((module) => {

module.exports = require("react-icons/lu");

/***/ }),

/***/ 5452:
/***/ ((module) => {

module.exports = require("react-icons/rx");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 49:
/***/ ((module) => {

module.exports = import("@radix-ui/react-label");;

/***/ }),

/***/ 4338:
/***/ ((module) => {

module.exports = import("@radix-ui/react-slot");;

/***/ }),

/***/ 9752:
/***/ ((module) => {

module.exports = import("@tanstack/react-query");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6926:
/***/ ((module) => {

module.exports = import("class-variance-authority");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 2184:
/***/ ((module) => {

module.exports = import("swiper/modules");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5675,5152,676,1664,1257,9010,3516,7912,9067,2872,617,3008,4991,1848], () => (__webpack_exec__(4325)));
module.exports = __webpack_exports__;

})();