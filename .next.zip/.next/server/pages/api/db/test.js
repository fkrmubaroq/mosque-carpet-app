"use strict";
(() => {
var exports = {};
exports.id = 731;
exports.ids = [731];
exports.modules = {

/***/ 711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IL": () => (/* binding */ responseErrorMessage),
/* harmony export */   "VL": () => (/* binding */ ResponseError),
/* harmony export */   "Wk": () => (/* binding */ responseNotFound)
/* harmony export */ });
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(895);

class ResponseError extends Error {
    status;
    code;
    constructor(status, { message , code  }){
        super(message);
        this.status = status;
        this.code = code;
    }
}
function responseErrorMessage(e, res) {
    if (e instanceof ResponseError) {
        res.status(e.status).json({
            code: e.code || 1,
            message: e.message
        });
        return;
    }
    res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_0__/* .STATUS_MESSAGE_ENUM.InternalServerError */ .E.InternalServerError).json({
        message: e.message
    });
}
function responseNotFound(res) {
    // res.status(STATUS)
    res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_0__/* .STATUS_MESSAGE_ENUM.NotFound */ .E.NotFound).json({
        message: "not found"
    });
}



/***/ }),

/***/ 895:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ STATUS_MESSAGE_ENUM)
/* harmony export */ });
const STATUS_MESSAGE_ENUM = {
    Ok: 200,
    BadRequest: 400,
    Unauthorized: 401,
    NotFound: 404,
    InternalServerError: 500,
    BadGateway: 502
};


/***/ }),

/***/ 5430:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./src/errors/response-error.js
var response_error = __webpack_require__(711);
;// CONCATENATED MODULE: external "serverless-mysql"
const external_serverless_mysql_namespaceObject = require("serverless-mysql");
var external_serverless_mysql_default = /*#__PURE__*/__webpack_require__.n(external_serverless_mysql_namespaceObject);
;// CONCATENATED MODULE: ./src/lib/db.js

const db = external_serverless_mysql_default()({
    config: {
        host: process.env.MYSQL_HOST,
        port: process.env.MYSQL_PORT,
        database: process.env.MYSQL_DATABASE,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD
    }
});
async function query(query, values) {
    try {
        const results = await db.query(query, values);
        await db.end();
        return results;
    } catch (error) {
        return {
            error
        };
    }
}

;// CONCATENATED MODULE: ./src/pages/api/db/test.js


async function handler(req, res) {
    if (req.method !== "GET") {
        (0,response_error/* responseNotFound */.Wk)(res);
        return;
    }
    const results = await query("SELECT * FROM product");
    res.status(200).json({
        data: results
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5430));
module.exports = __webpack_exports__;

})();