"use strict";
(() => {
var exports = {};
exports.id = 7578;
exports.ids = [7578];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 8506:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 2236:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./src/errors/response-error.js
var response_error = __webpack_require__(711);
// EXTERNAL MODULE: ./src/lib/enum.js
var lib_enum = __webpack_require__(895);
// EXTERNAL MODULE: ./src/lib/prisma.js
var prisma = __webpack_require__(4476);
// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(8506);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
;// CONCATENATED MODULE: ./src/validation/setting-validation.js

const insertSettingValidation = external_joi_default().object({
    id: external_joi_default().number().required(),
    no_wa: external_joi_default().string().max(20).required(),
    link_address: external_joi_default().string().optional(),
    is_maintenance: external_joi_default().string().max(1).required(),
    show_price: external_joi_default().string().max(1).required()
});


// EXTERNAL MODULE: ./src/validation/validation.js
var validation = __webpack_require__(9169);
;// CONCATENATED MODULE: ./src/pages/api/setting.js





function handler(req, res) {
    switch(req.method){
        case "POST":
            post(req, res);
            break;
        case "GET":
            get(req, res);
            break;
        default:
            (0,response_error/* responseNotFound */.Wk)(res);
            break;
    }
}
async function post(req, res) {
    try {
        const { id , ...validateRequest } = (0,validation/* validation */.U)(insertSettingValidation, req.body);
        const data = await prisma/* prismaClient.setting.update */.m.setting.update({
            data: validateRequest,
            where: {
                id
            }
        });
        res.status(lib_enum/* STATUS_MESSAGE_ENUM.Ok */.E.Ok).json({
            data
        });
    } catch (e) {
        (0,response_error/* responseErrorMessage */.IL)(e, res);
    }
}
async function get(req, res) {
    try {
        const data = await prisma/* prismaClient.setting.findFirst */.m.setting.findFirst();
        res.status(lib_enum/* STATUS_MESSAGE_ENUM.Ok */.E.Ok).json({
            data
        });
    } catch (e) {
        (0,response_error/* responseErrorMessage */.IL)(e, res);
    }
}


/***/ }),

/***/ 9169:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ validation)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(895);


function validation(schema, data) {
    const validate = schema.validate(data, {
        abortEarly: false,
        allowUnknown: false
    });
    if (validate.error) {
        throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_1__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, {
            code: 1,
            message: validate.error.message
        });
    }
    return validate.value;
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209], () => (__webpack_exec__(2236)));
module.exports = __webpack_exports__;

})();