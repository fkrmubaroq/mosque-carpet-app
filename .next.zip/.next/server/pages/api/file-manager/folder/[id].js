"use strict";
(() => {
var exports = {};
exports.id = 4737;
exports.ids = [4737];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 2246:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2472);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(895);
/* harmony import */ var _lib_message__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(187);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4476);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_5__);






async function handler(req, res) {
    try {
        const { id  } = req.query;
        if (req.method !== "DELETE") {
            (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseNotFound */ .Wk)(res);
            return;
        }
        if (!id) {
            throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, _lib_message__WEBPACK_IMPORTED_MODULE_3__/* .ERROR_MESSAGE.ProductIdIsNull */ .c9.ProductIdIsNull);
        }
        const deleteFolder = await _lib_prisma__WEBPACK_IMPORTED_MODULE_4__/* .prismaClient.fileManager["delete"] */ .m.fileManager["delete"]({
            where: {
                id: +id
            },
            select: {
                id: true,
                path: true,
                name: true,
                level: true
            }
        });
        if (!deleteFolder) {
            throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, _lib_message__WEBPACK_IMPORTED_MODULE_3__/* .ERROR_MESSAGE.FailedToDeleteFolder */ .c9.FailedToDeleteFolder);
        }
        const fileId = deleteFolder.id;
        const findByPath = await _lib_prisma__WEBPACK_IMPORTED_MODULE_4__/* .prismaClient.fileManager.findMany */ .m.fileManager.findMany({
            where: {
                path: {
                    startsWith: `${deleteFolder.path}${deleteFolder.name}/`
                }
            }
        });
        const folderName = deleteFolder.name;
        const path = deleteFolder.path;
        const src = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_UPLOAD */ .TO}${path}${folderName}`;
        deleteFolderAsync(src, {
            recursive: true,
            force: true
        });
        const listIds = findByPath.map((item)=>item.id);
        await _lib_prisma__WEBPACK_IMPORTED_MODULE_4__/* .prismaClient.fileManager.deleteMany */ .m.fileManager.deleteMany({
            where: {
                id: {
                    in: listIds
                }
            }
        });
        res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.Ok */ .E.Ok).json({
            message: "OK"
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}
function deleteFolderAsync(srcPath, options) {
    if (!fs__WEBPACK_IMPORTED_MODULE_5___default().existsSync(srcPath)) return false;
    fs__WEBPACK_IMPORTED_MODULE_5___default().rmdirSync(srcPath, options);
    return true;
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209,2472,187], () => (__webpack_exec__(2246)));
module.exports = __webpack_exports__;

})();