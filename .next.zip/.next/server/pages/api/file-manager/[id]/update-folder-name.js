"use strict";
(() => {
var exports = {};
exports.id = 6845;
exports.ids = [6845];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 8506:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 7754:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2472);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(895);
/* harmony import */ var _lib_message__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(187);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4476);
/* harmony import */ var _validation_file_validation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2440);
/* harmony import */ var _validation_validation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9169);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_7__);








async function handler(req, res) {
    try {
        if (req.method !== "PUT") {
            (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseNotFound */ .Wk)(res);
            return;
        }
        const { id  } = req.query;
        if (!id) {
            throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, _lib_message__WEBPACK_IMPORTED_MODULE_3__/* .ERROR_MESSAGE.FolderIsNotFound */ .c9.FolderIsNotFound);
        }
        const payload = (0,_validation_validation__WEBPACK_IMPORTED_MODULE_6__/* .validation */ .U)(_validation_file_validation__WEBPACK_IMPORTED_MODULE_5__/* .updateFolderNameValidation */ .jF, req.body);
        const findBySrc = await _lib_prisma__WEBPACK_IMPORTED_MODULE_4__/* .prismaClient.fileManager.count */ .m.fileManager.count({
            where: {
                path: payload.path,
                name: payload.name
            }
        });
        if (findBySrc) {
            throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, _lib_message__WEBPACK_IMPORTED_MODULE_3__/* .ERROR_MESSAGE.FolderAlreadyExists */ .c9.FolderAlreadyExists);
        }
        const findById = await _lib_prisma__WEBPACK_IMPORTED_MODULE_4__/* .prismaClient.fileManager.findFirst */ .m.fileManager.findFirst({
            where: {
                id: +id,
                path: payload.path
            }
        });
        // if folder not found
        if (!findById) {
            throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.BadGateway */ .E.BadGateway, _lib_message__WEBPACK_IMPORTED_MODULE_3__/* .ERROR_MESSAGE.FolderIsNotFound */ .c9.FolderIsNotFound);
        }
        const updateFolderName = await _lib_prisma__WEBPACK_IMPORTED_MODULE_4__/* .prismaClient.fileManager.update */ .m.fileManager.update({
            data: {
                name: payload.name
            },
            where: {
                id: +id
            }
        });
        if (!updateFolderName) {
            throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, _lib_message__WEBPACK_IMPORTED_MODULE_3__/* .ERROR_MESSAGE.FailedToUpdateFolderName */ .c9.FailedToUpdateFolderName);
        }
        const updatePath = await bulkUpdatePathStartWith({
            payload,
            row: findById
        });
        if (!updatePath) {
            res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.Ok */ .E.Ok).json({
                message: "OK"
            });
            return;
        }
        await bulkUpdate(updatePath);
        const oldPath = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_UPLOAD */ .TO}${findById.path}${findById.name}`;
        const newPath = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_UPLOAD */ .TO}${findById.path}${payload.name}`;
        renameFolder(oldPath, newPath);
        res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.Ok */ .E.Ok).json({
            message: "OK"
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}
async function bulkUpdatePathStartWith({ payload , row ,  }) {
    const findPathContainsOldFolder = await _lib_prisma__WEBPACK_IMPORTED_MODULE_4__/* .prismaClient.fileManager.findMany */ .m.fileManager.findMany({
        where: {
            path: {
                startsWith: `${row.path}${row.name}/`
            }
        }
    });
    if (!findPathContainsOldFolder) return;
    const level = row.level;
    const updateMany = [];
    findPathContainsOldFolder.forEach((file)=>{
        const splitPath = file.path.split("/").slice(1, -1);
        splitPath[level] = payload.name;
        updateMany.push({
            id: file.id,
            path: `/${splitPath.join("/")}/`
        });
    });
    return updateMany;
}
function renameFolder(oldPath, newPath) {
    try {
        fs__WEBPACK_IMPORTED_MODULE_7___default().renameSync(oldPath, newPath);
    } catch (e) {
        throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, _lib_message__WEBPACK_IMPORTED_MODULE_3__/* .ERROR_MESSAGE.FailedToUpdateFolderName */ .c9.FailedToUpdateFolderName);
    }
}
async function bulkUpdate(rows) {
    try {
        for(let i = 0; i < rows.length; i++){
            await _lib_prisma__WEBPACK_IMPORTED_MODULE_4__/* .prismaClient.fileManager.update */ .m.fileManager.update({
                data: {
                    path: rows[i].path
                },
                where: {
                    id: rows[i].id
                }
            });
        }
    } catch (e) {
        throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.InternalServerError */ .E.InternalServerError, _lib_message__WEBPACK_IMPORTED_MODULE_3__/* .ERROR_MESSAGE.FailedToUpdateFolderName */ .c9.FailedToUpdateFolderName);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209,2472,187,1987], () => (__webpack_exec__(7754)));
module.exports = __webpack_exports__;

})();