"use strict";
(() => {
var exports = {};
exports.id = 8706;
exports.ids = [8706];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 165:
/***/ ((module) => {

module.exports = require("multiparty");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 3316:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2472);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(895);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4476);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(866);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var multiparty__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(165);
/* harmony import */ var multiparty__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(multiparty__WEBPACK_IMPORTED_MODULE_6__);







function renameFileDuplicated(fileName, text) {
    const splitFileName = fileName.split(".");
    splitFileName.splice(splitFileName.length - 1, 0, text);
    return splitFileName.join(".");
}
async function insertFileToServerAndDatabase(data) {
    const { files , path  } = data;
    return new Promise(async (resolve)=>{
        const pathDir = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_UPLOAD */ .TO}${data.path}`;
        for(const key in files){
            const file = files[key];
            let srcFile = `${pathDir}${file.originalFilename}`;
            const contentData = await fs__WEBPACK_IMPORTED_MODULE_5___default().promises.readFile(file.path);
            fs__WEBPACK_IMPORTED_MODULE_5___default().access(srcFile, async (err)=>{
                // when file is not exists, create file and then move into files/upload/
                if (err) {
                    await insertFileInfoToDatabase({
                        name: file.originalFilename,
                        path
                    });
                    await fs__WEBPACK_IMPORTED_MODULE_5___default().promises.writeFile(srcFile, contentData);
                    resolve(true);
                    return;
                }
                // when file is exists, rename file 'copy(n+1)'
                const fileName = renameFileDuplicated(file.originalFilename, "copy");
                srcFile = `${pathDir}${fileName}`;
                fs__WEBPACK_IMPORTED_MODULE_5___default().access(srcFile, async (err)=>{
                    if (err) {
                        await insertFileInfoToDatabase({
                            name: fileName,
                            path
                        });
                        await fs__WEBPACK_IMPORTED_MODULE_5___default().promises.writeFile(srcFile, contentData);
                        resolve(true);
                        return;
                    }
                    const count = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.fileManager.count */ .m.fileManager.count({
                        where: {
                            path,
                            name: {
                                startsWith: fileName
                            }
                        }
                    });
                    const renamefileName = renameFileDuplicated(fileName, `${count + 2}`);
                    srcFile = `${pathDir}${renamefileName}`;
                    await insertFileInfoToDatabase({
                        name: renamefileName,
                        path
                    });
                    await fs__WEBPACK_IMPORTED_MODULE_5___default().promises.writeFile(srcFile, contentData);
                    resolve(true);
                });
            });
        }
    });
}
async function insertFileInfoToDatabase({ name , path  }) {
    const levelBySlash = path.split("/").length - 2;
    await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.fileManager.create */ .m.fileManager.create({
        data: {
            type: "FILE",
            name,
            level: path === "/" ? 0 : levelBySlash,
            path: path
        }
    });
}
async function handler(req, res) {
    try {
        if (req.method !== "POST") {
            (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseNotFound */ .Wk)(res);
            return;
        }
        const multipartyForm = new (multiparty__WEBPACK_IMPORTED_MODULE_6___default().Form)();
        const data = await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .incomingRequest */ .QE)(multipartyForm, req);
        await insertFileToServerAndDatabase(data);
        res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.Ok */ .E.Ok).json({
            data: "ok"
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}
const config = {
    api: {
        bodyParser: false
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209,2472,866], () => (__webpack_exec__(3316)));
module.exports = __webpack_exports__;

})();