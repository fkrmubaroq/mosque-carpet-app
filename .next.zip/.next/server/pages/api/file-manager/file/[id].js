"use strict";
(() => {
var exports = {};
exports.id = 839;
exports.ids = [839];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 6997:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2472);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(895);
/* harmony import */ var _lib_message__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(187);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4476);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(866);






async function handler(req, res) {
    try {
        const { id  } = req.query;
        if (req.method !== "DELETE") {
            (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseNotFound */ .Wk)(res);
            return;
        }
        if (!id) {
            throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, _lib_message__WEBPACK_IMPORTED_MODULE_3__/* .ERROR_MESSAGE.ProductIdIsNull */ .c9.ProductIdIsNull);
        }
        const deleteFile = await _lib_prisma__WEBPACK_IMPORTED_MODULE_4__/* .prismaClient.fileManager["delete"] */ .m.fileManager["delete"]({
            where: {
                id: +id
            },
            select: {
                id: true,
                path: true,
                name: true,
                level: true
            }
        });
        if (!deleteFile) {
            throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, _lib_message__WEBPACK_IMPORTED_MODULE_3__/* .ERROR_MESSAGE.FailedToDeleteFile */ .c9.FailedToDeleteFile);
        }
        const path = deleteFile.path;
        const src = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_UPLOAD */ .TO}${path}${deleteFile.name}`;
        await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_5__/* .unlinkFile */ .y3)(src);
        res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.Ok */ .E.Ok).json({
            message: "OK"
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209,2472,187,866], () => (__webpack_exec__(6997)));
module.exports = __webpack_exports__;

})();