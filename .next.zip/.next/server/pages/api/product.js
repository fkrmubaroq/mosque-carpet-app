"use strict";
(() => {
var exports = {};
exports.id = 2759;
exports.ids = [2759];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 8506:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 165:
/***/ ((module) => {

module.exports = require("multiparty");

/***/ }),

/***/ 6555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 3538:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2472);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(895);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4476);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(866);
/* harmony import */ var _validation_product_validation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1353);
/* harmony import */ var _validation_validation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9169);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var multiparty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(165);
/* harmony import */ var multiparty__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(multiparty__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6555);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_9__]);
uuid__WEBPACK_IMPORTED_MODULE_9__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










function handler(req, res) {
    if (req.method === "POST") {
        return post(req, res);
    }
    if (req.method === "GET") {
        return get(req, res);
    }
    if (req.method === "PUT") {
        return put(req, res);
    }
    (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseNotFound */ .Wk)(res);
}
async function put(req, res) {
    try {
        const multipartyForm = new (multiparty__WEBPACK_IMPORTED_MODULE_8___default().Form)();
        const { files , ...body } = await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .incomingRequest */ .QE)(multipartyForm, req);
        const request = {
            ...body
        };
        if (Object.keys(files).length) {
            request.image = files.image;
        }
        const { id , ...validateRequest } = (0,_validation_validation__WEBPACK_IMPORTED_MODULE_6__/* .validation */ .U)(_validation_product_validation__WEBPACK_IMPORTED_MODULE_5__/* .updateProductValidation */ .Vs, request);
        const updateData = {
            ...validateRequest
        };
        if (Object.keys(files).length) {
            var ref;
            const fileName = `${(0,uuid__WEBPACK_IMPORTED_MODULE_9__.v4)().toString()}_${files === null || files === void 0 ? void 0 : (ref = files.image) === null || ref === void 0 ? void 0 : ref.originalFilename}`;
            updateData.image = fileName;
            const prevImage = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.product.findFirst */ .m.product.findFirst({
                where: {
                    id
                }
            });
            // when prev image is available, then unlink file and 
            if (prevImage) {
                const destinationFileUnlink = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_PRODUCTS */ .lh}/${prevImage.image}`;
                await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .unlinkFile */ .y3)(destinationFileUnlink);
            }
            const destinationCreateFile = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_PRODUCTS */ .lh}/${fileName}`;
            await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .createFile */ .cn)(files.image.path, destinationCreateFile);
        }
        await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.product.update */ .m.product.update({
            data: updateData,
            where: {
                id
            }
        });
        res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.Ok */ .E.Ok).json({
            data: "OK"
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}
async function post(req, res) {
    try {
        var ref;
        const multipartyForm = new (multiparty__WEBPACK_IMPORTED_MODULE_8___default().Form)();
        const { files , ...body } = await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .incomingRequest */ .QE)(multipartyForm, req);
        const request = {
            ...body
        };
        if (Object.keys(files).length) {
            request.image = files.image;
        }
        const validateRequest = (0,_validation_validation__WEBPACK_IMPORTED_MODULE_6__/* .validation */ .U)(_validation_product_validation__WEBPACK_IMPORTED_MODULE_5__/* .insertProductValidation */ .vz, request);
        const insertData = {
            ...validateRequest
        };
        const fileName = `${(0,uuid__WEBPACK_IMPORTED_MODULE_9__.v4)().toString()}_${files === null || files === void 0 ? void 0 : (ref = files.image) === null || ref === void 0 ? void 0 : ref.originalFilename}`;
        if (Object.keys(files).length) {
            insertData.image = fileName;
        }
        const insertProduct = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.product.create */ .m.product.create({
            data: insertData
        });
        if (Object.keys(files).length) {
            const contentData = await fs__WEBPACK_IMPORTED_MODULE_7___default().promises.readFile(files.image.path);
            const destination = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_PRODUCTS */ .lh}/${fileName}`;
            await fs__WEBPACK_IMPORTED_MODULE_7___default().promises.writeFile(destination, contentData);
        }
        res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.Ok */ .E.Ok).json({
            data: insertProduct
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}
async function get(req, res) {
    try {
        const query = req.query;
        let filters = {};
        const page = (query === null || query === void 0 ? void 0 : query.page) ? +query.page : 1;
        const skip = (page - 1) * _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .OFFSET */ .ew;
        if (query === null || query === void 0 ? void 0 : query.name) {
            filters = {
                where: {
                    name: {
                        contains: query.name
                    }
                }
            };
        }
        const response = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.product.findMany */ .m.product.findMany({
            ...filters,
            include: {
                category: {
                    select: {
                        category_name: true
                    }
                }
            },
            orderBy: {
                id: "desc"
            },
            skip,
            take: _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .OFFSET */ .ew
        });
        const paginationInfo = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.product.count */ .m.product.count({
            ...filters
        });
        const totalPage = Math.ceil(paginationInfo / _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .OFFSET */ .ew);
        const data = response.map(({ category , ...rest })=>{
            return {
                ...rest,
                category_name: category === null || category === void 0 ? void 0 : category.category_name
            };
        });
        res.status(200).json({
            data,
            paging: {
                page,
                total_page: totalPage,
                total_items: paginationInfo
            }
        });
    } catch (e) {
        res.status(400).json({
            message: e.message
        });
    }
}
const config = {
    api: {
        bodyParser: false
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209,2472,866,9981], () => (__webpack_exec__(3538)));
module.exports = __webpack_exports__;

})();