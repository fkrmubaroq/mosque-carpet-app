"use strict";
(() => {
var exports = {};
exports.id = 4725;
exports.ids = [4725];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1785:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4476);


function handler(req, res) {
    if (req.method !== "GET") {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseNotFound */ .Wk)(res);
        return;
    }
    getCategoryBySlug(req, res);
}
async function getCategoryBySlug(req, res) {
    try {
        const { slug  } = req.query;
        const removeSlug = slug.split("-");
        const id = removeSlug[(removeSlug === null || removeSlug === void 0 ? void 0 : removeSlug.length) - 1];
        const data = await _lib_prisma__WEBPACK_IMPORTED_MODULE_1__/* .prismaClient.product.findMany */ .m.product.findMany({
            where: {
                id: +id
            }
        });
        res.status(200).json({
            data
        });
    } catch (e) {
        res.status(400).json({
            message: e.message
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209], () => (__webpack_exec__(1785)));
module.exports = __webpack_exports__;

})();