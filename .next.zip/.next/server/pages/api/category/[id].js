"use strict";
(() => {
var exports = {};
exports.id = 3329;
exports.ids = [3329];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 9373:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(895);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4476);



function handler(req, res) {
    deleteRow(req, res);
}
async function deleteRow(req, res) {
    try {
        const { id  } = req.query;
        if (!id) {
            throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_1__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, _lib_enum__WEBPACK_IMPORTED_MODULE_1__.ERROR_MESSAGE.ProductIdIsNull);
        }
        await _lib_prisma__WEBPACK_IMPORTED_MODULE_2__/* .prismaClient.category["delete"] */ .m.category["delete"]({
            where: {
                id: +id
            }
        });
        res.status(200).json({
            message: "ok"
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209], () => (__webpack_exec__(9373)));
module.exports = __webpack_exports__;

})();