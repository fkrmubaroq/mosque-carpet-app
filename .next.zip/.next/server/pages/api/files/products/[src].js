"use strict";
(() => {
var exports = {};
exports.id = 6941;
exports.ids = [6941];
exports.modules = {

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IL": () => (/* binding */ responseErrorMessage),
/* harmony export */   "VL": () => (/* binding */ ResponseError),
/* harmony export */   "Wk": () => (/* binding */ responseNotFound)
/* harmony export */ });
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(895);

class ResponseError extends Error {
    status;
    code;
    constructor(status, { message , code  }){
        super(message);
        this.status = status;
        this.code = code;
    }
}
function responseErrorMessage(e, res) {
    if (e instanceof ResponseError) {
        res.status(e.status).json({
            code: e.code || 1,
            message: e.message
        });
        return;
    }
    res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_0__/* .STATUS_MESSAGE_ENUM.InternalServerError */ .E.InternalServerError).json({
        message: e.message
    });
}
function responseNotFound(res) {
    // res.status(STATUS)
    res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_0__/* .STATUS_MESSAGE_ENUM.NotFound */ .E.NotFound).json({
        message: "not found"
    });
}



/***/ }),

/***/ 895:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ STATUS_MESSAGE_ENUM)
/* harmony export */ });
const STATUS_MESSAGE_ENUM = {
    Ok: 200,
    BadRequest: 400,
    Unauthorized: 401,
    NotFound: 404,
    InternalServerError: 500,
    BadGateway: 502
};


/***/ }),

/***/ 2018:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2472);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_2__);



function handler(req, res) {
    const { src  } = req.query;
    if (req.method !== "GET" || !src) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseNotFound */ .Wk)(res);
        return;
    }
    const pathFile = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_PRODUCTS */ .lh}/${src}`;
    const img = fs__WEBPACK_IMPORTED_MODULE_2___default().readFileSync(pathFile);
    res.writeHead(200, {
        "ContentType": "*"
    });
    res.end(img, "binary");
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2472], () => (__webpack_exec__(2018)));
module.exports = __webpack_exports__;

})();