"use strict";
(() => {
var exports = {};
exports.id = 6074;
exports.ids = [6074];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 9888:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4476);


function handler(req, res) {
    if (req.method === "GET") {
        return get(req, res);
    }
    (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseNotFound */ .Wk)(res);
}
async function get(req, res) {
    try {
        const { slug  } = req.query;
        const removeCategoryNameSlug = slug.split("-").join(" ");
        const findCategoryBySlug = await _lib_prisma__WEBPACK_IMPORTED_MODULE_1__/* .prismaClient.category.findFirst */ .m.category.findFirst({
            where: {
                category_name: {
                    startsWith: removeCategoryNameSlug
                }
            }
        });
        if (!findCategoryBySlug) {
            res.status(200).json({
                data: []
            });
            return;
        }
        const response = await _lib_prisma__WEBPACK_IMPORTED_MODULE_1__/* .prismaClient.product.findMany */ .m.product.findMany({
            where: {
                category_id: findCategoryBySlug.id,
                active: "Y"
            },
            include: {
                category: {
                    select: {
                        category_name: true
                    }
                }
            },
            orderBy: {
                id: "desc"
            }
        });
        const data = response.map(({ category , ...rest })=>{
            return {
                ...rest,
                category_name: category === null || category === void 0 ? void 0 : category.category_name
            };
        });
        res.status(200).json({
            data
        });
    } catch (e) {
        res.status(400).json({
            message: e.message
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209], () => (__webpack_exec__(9888)));
module.exports = __webpack_exports__;

})();