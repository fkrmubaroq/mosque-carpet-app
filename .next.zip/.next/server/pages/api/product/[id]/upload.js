"use strict";
(() => {
var exports = {};
exports.id = 1835;
exports.ids = [1835];
exports.modules = {

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 165:
/***/ ((module) => {

module.exports = require("multiparty");

/***/ }),

/***/ 6555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IL": () => (/* binding */ responseErrorMessage),
/* harmony export */   "VL": () => (/* binding */ ResponseError),
/* harmony export */   "Wk": () => (/* binding */ responseNotFound)
/* harmony export */ });
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(895);

class ResponseError extends Error {
    status;
    code;
    constructor(status, { message , code  }){
        super(message);
        this.status = status;
        this.code = code;
    }
}
function responseErrorMessage(e, res) {
    if (e instanceof ResponseError) {
        res.status(e.status).json({
            code: e.code || 1,
            message: e.message
        });
        return;
    }
    res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_0__/* .STATUS_MESSAGE_ENUM.InternalServerError */ .E.InternalServerError).json({
        message: e.message
    });
}
function responseNotFound(res) {
    // res.status(STATUS)
    res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_0__/* .STATUS_MESSAGE_ENUM.NotFound */ .E.NotFound).json({
        message: "not found"
    });
}



/***/ }),

/***/ 895:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ STATUS_MESSAGE_ENUM)
/* harmony export */ });
const STATUS_MESSAGE_ENUM = {
    Ok: 200,
    BadRequest: 400,
    Unauthorized: 401,
    NotFound: 404,
    InternalServerError: 500,
    BadGateway: 502
};


/***/ }),

/***/ 8981:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2472);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(866);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var multiparty__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(165);
/* harmony import */ var multiparty__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(multiparty__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6555);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_5__]);
uuid__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






async function handler(req, res) {
    try {
        if (req.method !== "POST") {
            (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseNotFound */ .Wk)(res);
            return;
        }
        const multipartyForm = new (multiparty__WEBPACK_IMPORTED_MODULE_4___default().Form)();
        const data = await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__/* .incomingRequest */ .QE)(multipartyForm, req);
        const { files , path  } = data;
        for(const key in files){
            const file = files[key];
            const fileName = `${(0,uuid__WEBPACK_IMPORTED_MODULE_5__.v4)().toString()}_${file.originalFilename}`;
            const srcFile = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_PRODUCTS */ .lh}/${fileName}`;
            const contentData = await fs__WEBPACK_IMPORTED_MODULE_3___default().promises.readFile(file.path);
            const levelBySlash = path.split("/").length - 2;
            // await prismaClient.product.create({
            //   data: {
            //     name: 
            //     level: path === "/" ? 0 : levelBySlash,
            //     path:path
            //   },  
            // })
            await fs__WEBPACK_IMPORTED_MODULE_3___default().promises.writeFile(srcFile, contentData);
        }
    } catch (e) {}
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2472,866], () => (__webpack_exec__(8981)));
module.exports = __webpack_exports__;

})();