"use strict";
(() => {
var exports = {};
exports.id = 8291;
exports.ids = [8291];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 8506:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 1793:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(895);
/* harmony import */ var _lib_message__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(187);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4476);
/* harmony import */ var _validation_product_validation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1353);
/* harmony import */ var _validation_validation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9169);






async function handler(req, res) {
    try {
        if (req.method !== "PATCH") {
            (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseNotFound */ .Wk)(res);
            return;
        }
        const { id  } = req.query;
        const productId = (0,_validation_validation__WEBPACK_IMPORTED_MODULE_5__/* .validation */ .U)(_validation_product_validation__WEBPACK_IMPORTED_MODULE_4__/* .updateStatusValidation */ .NO, id);
        const findProduct = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.product.findUnique */ .m.product.findUnique({
            where: {
                id: productId
            },
            select: {
                id: true,
                active: true
            }
        });
        if (!findProduct) {
            throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_1__/* .STATUS_MESSAGE_ENUM.BadGateway */ .E.BadGateway, _lib_message__WEBPACK_IMPORTED_MODULE_2__/* .ERROR_MESSAGE.ProductIdIsNull */ .c9.ProductIdIsNull);
        }
        const data = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.product.update */ .m.product.update({
            data: {
                active: findProduct.active === "Y" ? "N" : "Y"
            },
            where: {
                id: productId
            },
            select: {
                id: true,
                active: true
            }
        });
        res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_1__/* .STATUS_MESSAGE_ENUM.Ok */ .E.Ok).json({
            data
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209,187,9981], () => (__webpack_exec__(1793)));
module.exports = __webpack_exports__;

})();