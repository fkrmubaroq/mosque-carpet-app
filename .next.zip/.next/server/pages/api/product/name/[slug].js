"use strict";
(() => {
var exports = {};
exports.id = 8848;
exports.ids = [8848];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 6125:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4476);


function handler(req, res) {
    if (req.method === "GET") {
        return get(req, res);
    }
    (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseNotFound */ .Wk)(res);
}
async function get(req, res) {
    try {
        const { slug  } = req.query;
        const removeSlugProductName = slug.split("-");
        const id = removeSlugProductName[(removeSlugProductName === null || removeSlugProductName === void 0 ? void 0 : removeSlugProductName.length) - 1];
        const response = await _lib_prisma__WEBPACK_IMPORTED_MODULE_1__/* .prismaClient.product.findMany */ .m.product.findMany({
            where: {
                id: +id
            },
            include: {
                category: {
                    select: {
                        category_name: true
                    }
                }
            },
            orderBy: {
                id: "desc"
            }
        });
        const data = response.map(({ category , ...rest })=>{
            return {
                ...rest,
                category_name: category === null || category === void 0 ? void 0 : category.category_name
            };
        });
        res.status(200).json({
            data: (data === null || data === void 0 ? void 0 : data[0]) || []
        });
    } catch (e) {
        res.status(400).json({
            message: e.message
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209], () => (__webpack_exec__(6125)));
module.exports = __webpack_exports__;

})();