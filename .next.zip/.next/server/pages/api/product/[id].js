"use strict";
(() => {
var exports = {};
exports.id = 3021;
exports.ids = [3021];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 6674:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2472);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(895);
/* harmony import */ var _lib_message__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(187);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4476);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(866);






function handler(req, res) {
    if (req.method === "DELETE") {
        deleteProduct(req, res);
    }
}
async function deleteProduct(req, res) {
    try {
        const { id  } = req.query;
        if (!id) {
            throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, _lib_message__WEBPACK_IMPORTED_MODULE_3__/* .ERROR_MESSAGE.ProductIdIsNull */ .c9.ProductIdIsNull);
        }
        const prevImage = await _lib_prisma__WEBPACK_IMPORTED_MODULE_4__/* .prismaClient.product.findFirst */ .m.product.findFirst({
            where: {
                id: +id
            }
        });
        if (prevImage) {
            const destinationFileUnlink = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_PRODUCTS */ .lh}/${prevImage.image}`;
            await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_5__/* .unlinkFile */ .y3)(destinationFileUnlink);
        }
        const deleteProduct = await _lib_prisma__WEBPACK_IMPORTED_MODULE_4__/* .prismaClient.product["delete"] */ .m.product["delete"]({
            where: {
                id: +id
            }
        });
        res.status(200).json({
            message: "ok"
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209,2472,187,866], () => (__webpack_exec__(6674)));
module.exports = __webpack_exports__;

})();