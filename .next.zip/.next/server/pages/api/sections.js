"use strict";
(() => {
var exports = {};
exports.id = 3792;
exports.ids = [3792];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 8506:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 6808:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./src/errors/response-error.js
var response_error = __webpack_require__(711);
// EXTERNAL MODULE: ./src/lib/enum.js
var lib_enum = __webpack_require__(895);
// EXTERNAL MODULE: ./src/lib/message.js
var message = __webpack_require__(187);
// EXTERNAL MODULE: ./src/lib/prisma.js
var prisma = __webpack_require__(4476);
// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(8506);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
;// CONCATENATED MODULE: ./src/validation/section-validation.js

const updateSectionValidation = external_joi_default().object({
    id: external_joi_default().number().required(),
    section_name: external_joi_default().string().required(),
    content: external_joi_default().string().required(),
    position: external_joi_default().number().required(),
    active: external_joi_default().string().optional()
});


// EXTERNAL MODULE: ./src/validation/validation.js
var validation = __webpack_require__(9169);
;// CONCATENATED MODULE: ./src/pages/api/sections/index.js






function handler(req, res) {
    switch(req.method){
        case "PUT":
            put(req, res);
            break;
    }
}
async function put(req, res) {
    try {
        var ref;
        const sections = (ref = req.body) === null || ref === void 0 ? void 0 : ref.sections;
        if (!(sections === null || sections === void 0 ? void 0 : sections.length)) {
            throw new response_error/* ResponseError */.VL(lib_enum/* STATUS_MESSAGE_ENUM.BadRequest */.E.BadRequest, message/* ERROR_MESSAGE.SectionIsNull */.c9.SectionIsNull);
        }
        for(let i = 0; i < sections.length; i++){
            const { id , ...requestValidate } = (0,validation/* validation */.U)(updateSectionValidation, sections[i]);
            await prisma/* prismaClient.sections.update */.m.sections.update({
                data: requestValidate,
                where: {
                    id
                }
            });
        }
        res.status(lib_enum/* STATUS_MESSAGE_ENUM.Ok */.E.Ok).json({
            message: "ok"
        });
    } catch (e) {
        (0,response_error/* responseErrorMessage */.IL)(e, res);
    }
}


/***/ }),

/***/ 9169:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ validation)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(895);


function validation(schema, data) {
    const validate = schema.validate(data, {
        abortEarly: false,
        allowUnknown: false
    });
    if (validate.error) {
        throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_1__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, {
            code: 1,
            message: validate.error.message
        });
    }
    return validate.value;
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209,187], () => (__webpack_exec__(6808)));
module.exports = __webpack_exports__;

})();