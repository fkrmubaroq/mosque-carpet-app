"use strict";
(() => {
var exports = {};
exports.id = 4994;
exports.ids = [4994];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 8506:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 7541:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./src/errors/response-error.js
var response_error = __webpack_require__(711);
// EXTERNAL MODULE: ./src/lib/constant.js
var constant = __webpack_require__(2472);
// EXTERNAL MODULE: ./src/lib/enum.js
var lib_enum = __webpack_require__(895);
;// CONCATENATED MODULE: external "jsonwebtoken"
const external_jsonwebtoken_namespaceObject = require("jsonwebtoken");
var external_jsonwebtoken_default = /*#__PURE__*/__webpack_require__.n(external_jsonwebtoken_namespaceObject);
;// CONCATENATED MODULE: ./src/lib/jwt.js



const secret = process.env.JWT_SECRET_KEY || "";
function decodeJwt(token) {
    if (!token) {
        throw new ResponseError(401, "Unauthorized");
    }
    return jwt.verify(token, secret);
}
function encodeJwt(payload) {
    return new Promise((resolve)=>{
        external_jsonwebtoken_default().sign(payload, secret, {
            expiresIn: constant/* EXPIRED_DAYS */.Pi
        }, (err, token)=>{
            if (err) {
                resolve(err);
                return;
            }
            ;
            resolve(token);
        });
    });
}

// EXTERNAL MODULE: ./src/lib/message.js
var message = __webpack_require__(187);
// EXTERNAL MODULE: ./src/lib/prisma.js
var prisma = __webpack_require__(4476);
// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(8506);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
;// CONCATENATED MODULE: ./src/validation/user-validation.js

const loginUserValidation = external_joi_default().object({
    username: external_joi_default().string().max(100).required(),
    password: external_joi_default().string().max(100).required()
});


// EXTERNAL MODULE: ./src/validation/validation.js
var validation = __webpack_require__(9169);
;// CONCATENATED MODULE: external "bcrypt"
const external_bcrypt_namespaceObject = require("bcrypt");
var external_bcrypt_default = /*#__PURE__*/__webpack_require__.n(external_bcrypt_namespaceObject);
;// CONCATENATED MODULE: external "cookie"
const external_cookie_namespaceObject = require("cookie");
;// CONCATENATED MODULE: ./src/pages/api/login.js










async function handler(req, res) {
    try {
        if (req.method !== "POST") {
            return;
        }
        const validateRequest = (0,validation/* validation */.U)(loginUserValidation, req.body);
        const username = validateRequest.username;
        const user = await prisma/* prismaClient.user.findUnique */.m.user.findUnique({
            where: {
                username
            },
            select: {
                username: true,
                password: true,
                name: true
            }
        });
        if (!user) {
            throw new response_error/* ResponseError */.VL(lib_enum/* STATUS_MESSAGE_ENUM.Unauthorized */.E.Unauthorized, message/* ERROR_MESSAGE.UsernameOrPasswordWrong */.c9.UsernameOrPasswordWrong);
        }
        const isPasswordValid = await external_bcrypt_default().compare(validateRequest.password, user.password);
        if (!isPasswordValid) {
            throw new response_error/* ResponseError */.VL(lib_enum/* STATUS_MESSAGE_ENUM.Unauthorized */.E.Unauthorized, message/* ERROR_MESSAGE.UsernameOrPasswordWrong */.c9.UsernameOrPasswordWrong);
        }
        const token = await encodeJwt({
            user: user.username
        });
        setTokenToHeaderCookie(token, res);
        res.status(200).json({
            data: {
                username: user.username,
                name: user.name
            }
        });
    } catch (e) {
        (0,response_error/* responseErrorMessage */.IL)(e, res);
    }
}
function setTokenToHeaderCookie(token, res) {
    const serialized = (0,external_cookie_namespaceObject.serialize)("token", token, {
        httpOnly: true,
        secure: true,
        sameSite: "strict",
        path: "/",
        maxAge: constant/* EXPIRED_DAYS */.Pi
    });
    res.setHeader("Set-Cookie", serialized);
}


/***/ }),

/***/ 9169:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ validation)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(895);


function validation(schema, data) {
    const validate = schema.validate(data, {
        abortEarly: false,
        allowUnknown: false
    });
    if (validate.error) {
        throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_1__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, {
            code: 1,
            message: validate.error.message
        });
    }
    return validate.value;
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209,2472,187], () => (__webpack_exec__(7541)));
module.exports = __webpack_exports__;

})();