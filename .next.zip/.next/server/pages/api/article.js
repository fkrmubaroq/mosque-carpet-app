"use strict";
(() => {
var exports = {};
exports.id = 6232;
exports.ids = [6232];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 8506:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 165:
/***/ ((module) => {

module.exports = require("multiparty");

/***/ }),

/***/ 6555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 8405:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2472);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(895);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4476);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(866);
/* harmony import */ var _validation_article_validation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4400);
/* harmony import */ var _validation_validation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9169);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var multiparty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(165);
/* harmony import */ var multiparty__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(multiparty__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6555);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_9__]);
uuid__WEBPACK_IMPORTED_MODULE_9__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










function handler(req, res) {
    switch(req.method){
        case "GET":
            get(req, res);
            break;
        case "POST":
            post(req, res);
            break;
        default:
            (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseNotFound */ .Wk)(res);
            break;
    }
}
async function get(req, res) {
    try {
        const query = req.query;
        const q = query === null || query === void 0 ? void 0 : query.q;
        const page = (query === null || query === void 0 ? void 0 : query.page) ? +query.page : 1;
        const skip = (page - 1) * _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .OFFSET */ .ew;
        let filters = {};
        if (q) {
            filters = {
                where: {
                    OR: [
                        {
                            title: {
                                contains: q
                            }
                        },
                        {
                            writer: {
                                contains: q
                            }
                        }
                    ]
                }
            };
        }
        const data = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.article.findMany */ .m.article.findMany({
            include: {
                viewers: {
                    select: {
                        total: true
                    }
                }
            },
            ...filters,
            skip,
            take: +(query === null || query === void 0 ? void 0 : query.limit) || _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .OFFSET */ .ew,
            orderBy: {
                id: "desc"
            }
        });
        const paginationInfo = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.article.count */ .m.article.count({
            ...filters
        });
        const totalPage = Math.ceil(paginationInfo / _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .OFFSET */ .ew);
        const parsedData = data.map(({ viewers , ...item })=>{
            return {
                ...item,
                total_viewers: (viewers === null || viewers === void 0 ? void 0 : viewers.total) || null
            };
        });
        res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.Ok */ .E.Ok).json({
            data: parsedData,
            paging: {
                page,
                total_page: totalPage,
                total_items: paginationInfo
            }
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}
async function post(req, res) {
    try {
        var ref;
        const multipartyForm = new (multiparty__WEBPACK_IMPORTED_MODULE_8___default().Form)();
        const { files , ...body } = await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .incomingRequest */ .QE)(multipartyForm, req);
        const request = {
            ...body
        };
        if (Object.keys(files).length) {
            request.thumbnail = files.thumbnail;
        }
        const validateRequest = (0,_validation_validation__WEBPACK_IMPORTED_MODULE_6__/* .validation */ .U)(_validation_article_validation__WEBPACK_IMPORTED_MODULE_5__/* .insertArticleValidation */ .R, request);
        const insertData = {
            ...validateRequest
        };
        const fileName = `${(0,uuid__WEBPACK_IMPORTED_MODULE_9__.v4)().toString()}_${files === null || files === void 0 ? void 0 : (ref = files.thumbnail) === null || ref === void 0 ? void 0 : ref.originalFilename}`;
        if (Object.keys(files).length) {
            insertData.thumbnail = fileName;
        }
        const slug = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .slugString */ .Jg)(insertData.title);
        insertData.slug = slug;
        const data = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.article.create */ .m.article.create({
            data: insertData
        });
        if (Object.keys(files).length) {
            const contentData = await fs__WEBPACK_IMPORTED_MODULE_7___default().promises.readFile(files.thumbnail.path);
            const destination = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_THUMBNAIL */ .PI}/${fileName}`;
            await fs__WEBPACK_IMPORTED_MODULE_7___default().promises.writeFile(destination, contentData);
        }
        res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.Ok */ .E.Ok).json({
            data
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}
const config = {
    api: {
        bodyParser: false
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209,2472,866,4936], () => (__webpack_exec__(8405)));
module.exports = __webpack_exports__;

})();