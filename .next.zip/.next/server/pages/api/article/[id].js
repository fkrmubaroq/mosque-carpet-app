"use strict";
(() => {
var exports = {};
exports.id = 2971;
exports.ids = [2971];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 8506:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 165:
/***/ ((module) => {

module.exports = require("multiparty");

/***/ }),

/***/ 6555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 6937:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2472);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(895);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4476);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(866);
/* harmony import */ var _validation_article_validation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4400);
/* harmony import */ var _validation_validation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9169);
/* harmony import */ var multiparty__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(165);
/* harmony import */ var multiparty__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(multiparty__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6555);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_8__]);
uuid__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









function handler(req, res) {
    switch(req.method){
        case "GET":
            getArticleById(req, res);
            break;
        case "PUT":
            updateArticle(req, res);
            break;
        case "DELETE":
            deleteArticle(req, res);
            break;
        default:
            (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseNotFound */ .Wk)(res);
            break;
    }
}
async function deleteArticle(req, res) {
    try {
        const { id  } = req.query;
        const prevThumbnail = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.article.findFirst */ .m.article.findFirst({
            where: {
                id: +id
            }
        });
        if (prevThumbnail === null || prevThumbnail === void 0 ? void 0 : prevThumbnail.thumbnail) {
            const destinationFileUnlink = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_THUMBNAIL */ .PI}/${prevThumbnail.thumbnail}`;
            await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .unlinkFile */ .y3)(destinationFileUnlink);
        }
        await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.article["delete"] */ .m.article["delete"]({
            where: {
                id: +id
            }
        });
        res.status(200).json({
            message: "ok"
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}
async function getArticleById(req, res) {
    try {
        const { id  } = req.query;
        const data = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.article.findFirst */ .m.article.findFirst({
            where: {
                id: +id
            }
        });
        res.status(200).json({
            data
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}
async function updateArticle(req, res) {
    try {
        const multipartyForm = new (multiparty__WEBPACK_IMPORTED_MODULE_7___default().Form)();
        const { files , ...body } = await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .incomingRequest */ .QE)(multipartyForm, req);
        const { ...validateRequest } = (0,_validation_validation__WEBPACK_IMPORTED_MODULE_6__/* .validation */ .U)(_validation_article_validation__WEBPACK_IMPORTED_MODULE_5__/* .updateArticleValidation */ .z, body);
        const { id  } = req.query;
        const updateData = {
            ...validateRequest
        };
        if (Object.keys(files).length) {
            var ref;
            const fileName = `${(0,uuid__WEBPACK_IMPORTED_MODULE_8__.v4)().toString()}_${files === null || files === void 0 ? void 0 : (ref = files.thumbnail) === null || ref === void 0 ? void 0 : ref.originalFilename}`;
            updateData.thumbnail = fileName;
            const prevImage = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.article.findFirst */ .m.article.findFirst({
                where: {
                    id: +id
                }
            });
            // when prev image is available, then unlink file and 
            if (prevImage) {
                const destinationFileUnlink = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_THUMBNAIL */ .PI}/${prevImage.thumbnail}`;
                await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .unlinkFile */ .y3)(destinationFileUnlink);
            }
            const destinationCreateFile = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_THUMBNAIL */ .PI}/${fileName}`;
            await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .createFile */ .cn)(files.thumbnail.path, destinationCreateFile);
        }
        const slug = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .slugString */ .Jg)(updateData.title);
        updateData.slug = slug;
        const data = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.article.update */ .m.article.update({
            data: updateData,
            where: {
                id: +id
            }
        });
        res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.Ok */ .E.Ok).json({
            data
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}
const config = {
    api: {
        bodyParser: false
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209,2472,866,4936], () => (__webpack_exec__(6937)));
module.exports = __webpack_exports__;

})();