"use strict";
(() => {
var exports = {};
exports.id = 988;
exports.ids = [988];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 8506:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 165:
/***/ ((module) => {

module.exports = require("multiparty");

/***/ }),

/***/ 6555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 3890:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2472);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(895);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4476);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(866);
/* harmony import */ var _validation_category_validation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1275);
/* harmony import */ var _validation_validation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9169);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var multiparty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(165);
/* harmony import */ var multiparty__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(multiparty__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6555);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_9__]);
uuid__WEBPACK_IMPORTED_MODULE_9__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










function handler(req, res) {
    switch(req.method){
        case "GET":
            get(req, res);
            break;
        case "POST":
            post(req, res);
            break;
        case "PUT":
            put(req, res);
            break;
        default:
            responseNotFound(res);
            break;
    }
}
async function get(req, res) {
    try {
        const query = req.query;
        let filters = {};
        const page = (query === null || query === void 0 ? void 0 : query.page) ? +query.page : 1;
        const skip = (page - 1) * _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .OFFSET */ .ew;
        if (query === null || query === void 0 ? void 0 : query.name) {
            filters = {
                where: {
                    category_name: {
                        contains: query.name
                    }
                }
            };
        }
        const data = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.category.findMany */ .m.category.findMany({
            ...filters,
            orderBy: {
                id: "desc"
            },
            skip,
            take: +(query === null || query === void 0 ? void 0 : query.limit) || _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .OFFSET */ .ew
        });
        const paginationInfo = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.category.count */ .m.category.count({
            ...filters
        });
        const totalPage = Math.ceil(paginationInfo / _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .OFFSET */ .ew);
        res.status(200).json({
            data,
            paging: {
                page,
                total_page: totalPage,
                total_items: paginationInfo
            }
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}
async function post(req, res) {
    try {
        var ref;
        const multipartyForm = new (multiparty__WEBPACK_IMPORTED_MODULE_8___default().Form)();
        const { files , ...body } = await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .incomingRequest */ .QE)(multipartyForm, req);
        const request = {
            ...body
        };
        if (Object.keys(files).length) {
            request.image = files.image;
        }
        const validateRequest = (0,_validation_validation__WEBPACK_IMPORTED_MODULE_6__/* .validation */ .U)(_validation_category_validation__WEBPACK_IMPORTED_MODULE_5__/* .insertCategoryValidation */ .w, request);
        const insertData = {
            ...validateRequest
        };
        const fileName = `${(0,uuid__WEBPACK_IMPORTED_MODULE_9__.v4)().toString()}_${files === null || files === void 0 ? void 0 : (ref = files.image) === null || ref === void 0 ? void 0 : ref.originalFilename}`;
        if (Object.keys(files).length) {
            insertData.image = fileName;
        }
        const data = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.category.create */ .m.category.create({
            data: insertData
        });
        if (Object.keys(files).length) {
            const contentData = await fs__WEBPACK_IMPORTED_MODULE_7___default().promises.readFile(files.image.path);
            const destination = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_CATEGORY */ .k}/${fileName}`;
            await fs__WEBPACK_IMPORTED_MODULE_7___default().promises.writeFile(destination, contentData);
        }
        res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.Ok */ .E.Ok).json({
            data
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}
async function put(req, res) {
    try {
        const multipartyForm = new (multiparty__WEBPACK_IMPORTED_MODULE_8___default().Form)();
        const { files , ...body } = await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .incomingRequest */ .QE)(multipartyForm, req);
        const { id , ...validateRequest } = (0,_validation_validation__WEBPACK_IMPORTED_MODULE_6__/* .validation */ .U)(_validation_category_validation__WEBPACK_IMPORTED_MODULE_5__/* .updateCategoryValidation */ .z, body);
        const updateData = {
            ...validateRequest
        };
        if (Object.keys(files).length) {
            var ref;
            const fileName = `${(0,uuid__WEBPACK_IMPORTED_MODULE_9__.v4)().toString()}_${files === null || files === void 0 ? void 0 : (ref = files.image) === null || ref === void 0 ? void 0 : ref.originalFilename}`;
            updateData.image = fileName;
            const prevImage = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.category.findFirst */ .m.category.findFirst({
                where: {
                    id
                }
            });
            // when prev image is available, then unlink file and 
            if (prevImage) {
                const destinationFileUnlink = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_CATEGORY */ .k}/${prevImage.image}`;
                await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .unlinkFile */ .y3)(destinationFileUnlink);
            }
            const destinationCreateFile = `${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .DIR_FILE_CATEGORY */ .k}/${fileName}`;
            await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .createFile */ .cn)(files.image.path, destinationCreateFile);
        }
        const data = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* .prismaClient.category.update */ .m.category.update({
            data: updateData,
            where: {
                id: +id
            }
        });
        res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_2__/* .STATUS_MESSAGE_ENUM.Ok */ .E.Ok).json({
            data
        });
    } catch (e) {
        (0,_errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .responseErrorMessage */ .IL)(e, res);
    }
}
const config = {
    api: {
        bodyParser: false
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1275:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": () => (/* binding */ insertCategoryValidation),
/* harmony export */   "z": () => (/* binding */ updateCategoryValidation)
/* harmony export */ });
/* harmony import */ var joi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8506);
/* harmony import */ var joi__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(joi__WEBPACK_IMPORTED_MODULE_0__);

const insertCategoryValidation = joi__WEBPACK_IMPORTED_MODULE_0___default().object({
    category_name: joi__WEBPACK_IMPORTED_MODULE_0___default().string().max(100).required(),
    image: joi__WEBPACK_IMPORTED_MODULE_0___default().object().optional()
});
const updateCategoryValidation = joi__WEBPACK_IMPORTED_MODULE_0___default().object({
    id: joi__WEBPACK_IMPORTED_MODULE_0___default().number().required(),
    category_name: joi__WEBPACK_IMPORTED_MODULE_0___default().string().max(100).default(""),
    image: joi__WEBPACK_IMPORTED_MODULE_0___default().object().optional()
});



/***/ }),

/***/ 9169:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ validation)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(895);


function validation(schema, data) {
    const validate = schema.validate(data, {
        abortEarly: false,
        allowUnknown: false
    });
    if (validate.error) {
        throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_1__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, {
            code: 1,
            message: validate.error.message
        });
    }
    return validate.value;
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2209,2472,866], () => (__webpack_exec__(3890)));
module.exports = __webpack_exports__;

})();