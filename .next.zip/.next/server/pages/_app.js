"use strict";
(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 6495:
/***/ ((__unused_webpack_module, exports) => {

var __webpack_unused_export__;

__webpack_unused_export__ = ({
    value: true
});
exports.Z = _extends;
function _extends() {
    return extends_.apply(this, arguments);
}
function extends_() {
    extends_ = Object.assign || function(target) {
        for(var i = 1; i < arguments.length; i++){
            var source = arguments[i];
            for(var key in source){
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key];
                }
            }
        }
        return target;
    };
    return extends_.apply(this, arguments);
}


/***/ }),

/***/ 2648:
/***/ ((__unused_webpack_module, exports) => {

var __webpack_unused_export__;

__webpack_unused_export__ = ({
    value: true
});
exports.Z = _interopRequireDefault;
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}


/***/ }),

/***/ 8255:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ Toast)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_5__);






const Portal = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "../components/ui/toast/index.jsx -> " + "@/components/ui/portal"
        ]
    },
    ssr: false
});
const listVariant = {
    default: "bg-slate-900 text-gray-500",
    danger: "bg-red-700 text-white"
};
function Toast({ children , show , onHide , duration =3000 , variant ="default" ,  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Portal, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("fixed left-1/2 z-50 mb-4 flex w-full max-w-xs -translate-x-1/2  items-center overflow-hidden rounded-lg p-4  shadow transition-all duration-300 ease-in-out", {
                "bottom-5 ": show,
                "bottom-[-200px]": !show
            }, listVariant[variant]),
            role: "alert",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "inline-flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg",
                    children: [
                        variant === "default" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiCheck, {
                            color: "white",
                            size: 25
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_5__.IoMdCloseCircle, {
                            size: 25
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "sr-only",
                            children: "Check icon"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("ml-3 text-sm font-normal ", {
                        "text-gray-300": variant === "default"
                    }),
                    children: children
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    type: "button",
                    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("-mx-1.5 -my-1.5 ml-auto inline-flex h-8 w-8 items-center justify-center rounded-lg p-1.5  hover:text-white focus:ring-2  focus:ring-gray-300 ", {
                        "text-gray-400 hover:bg-gray-800": variant === "default",
                        "text-white hover:text-gray-200": variant === "danger"
                    }),
                    "data-dismiss-target": "#toast-success",
                    "aria-label": "Close",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__.AiOutlineClose, {})
                }),
                show && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    style: {
                        animationDuration: `${duration / 1000}s`
                    },
                    onAnimationEnd: ()=>{
                        onHide && onHide();
                    },
                    className: "animation-move absolute bottom-[0.2px] left-0 h-[3px] bg-transparent"
                })
            ]
        })
    });
}


/***/ }),

/***/ 5236:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y5": () => (/* binding */ CONFIRMATION_MESSAGE),
/* harmony export */   "cH": () => (/* binding */ TOAST_MESSAGE)
/* harmony export */ });
/* unused harmony export ERROR_MESSAGE */
const TOAST_MESSAGE = {
    // product 
    "success-insert-product": "Produk telah ditambahkan",
    "success-delete-product": "Produk telah dihapus",
    "success-update-product": "Produk berhasil diubah",
    "error-insert-product": "Produk Gagal ditambahkan",
    "error-delete-product": "Produk gagal dihapus",
    "error-update-product": "Produk gagal diubah",
    // file manager
    "error-create-folder": "Gagal membuat folder",
    "error-update-folder": "Gagal mengubah folder",
    "error-update-file": "Gagal mengubah file",
    "error-upload-file": "Gagal upload file",
    "error-delete-file": "Gagal menghapus file",
    "error-download-file": "File gagal didownload",
    "success-delete-folder": "Folder telah dihapus",
    "success-delete-file": "File telah dihapus",
    "success-upload-file": "File telah diupload",
    "custom-message": "custom-message",
    // category 
    "success-insert-category": "Kategori telah ditambahkan",
    "success-update-category": "Kategori berhasil diubah",
    "success-delete-category": "Kategori telah dihapus",
    "error-insert-category": "Kategori gagal ditambahkan",
    "error-update-category": "Kategori gagal diubah",
    "error-delete-category": "Kategori gagal dihapus",
    // setting 
    "success-update-setting": "Pengaturan telah di terapkan",
    "error-update-setting": "Pengaturan gagal diterapkan",
    // sections
    "success-update-section": "Landing page telah disimpan",
    "error-update-section": "Landing page gagal disimpan",
    // articles
    "success-create-article": "Artikel telah disimpan",
    "error-create-article": "Artikel gagal disimpan",
    "success-update-article": "Artikel telah diubah",
    "error-update-article": "Artikel gagal diubah",
    "success-delete-article": "Artikel telah dihapus",
    "error-delete-article": "Artikel gagal dihapus",
    // login
    "error-wrong-password": "Username atau password salah"
};
const CONFIRMATION_MESSAGE = {
    // product 
    "confirm-delete-product": "Apakah anda yakin ingin menghapus produk ini ?",
    // category
    "confirm-delete-category": "Apakah anda yakin ingin menghapus kategori ini ?",
    // logout
    "logout": "Apakah anda yakin keluar dari halaman admin ?",
    "costum-message": "custom-message"
};
const ERROR_MESSAGE = {
    // feature products 1000 - 1099
    UsernameOrPasswordWrong: {
        code: 1000,
        message: "Username atau password salah"
    },
    ProductIdIsNull: {
        code: 1001,
        message: "Id tidak ditemukan"
    },
    // feature file manager 1100 - 1199
    FolderAlreadyExists: {
        code: 1100,
        message: "Nama Folder telah digunakan"
    },
    FolderIsNotFound: {
        code: 1101,
        message: "Folder tidak ditemukan"
    },
    FileIsNotFound: {
        code: 1102,
        message: "File Tidak ditemukan"
    },
    FailedToUpdateFolderName: {
        code: 1103,
        message: "Folder gagal di ubah"
    },
    FailedToDeleteFolder: {
        code: 1104,
        message: "Folder gagal di hapus"
    },
    FailedToUploadFile: {
        code: 1105,
        message: "File gagal diupload"
    },
    FileAlreadyExists: {
        code: 1106,
        message: "Nama File telah digunakan"
    },
    FailedToUpdateFileName: {
        code: 1107,
        message: "File gagal di ubah"
    },
    ExtensionFileIsUnknown: {
        code: 1108,
        message: "Extension file tidak diketahui"
    },
    FailedToDeleteFile: {
        code: 1109,
        message: "File gagal di hapus"
    },
    // feature sections 1200 - 1299
    SectionIsNull: {
        code: 1200,
        message: "Section tidak boleh kosong"
    }
};



/***/ }),

/***/ 7149:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_modal_Confirmation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2054);
/* harmony import */ var _components_ui_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8255);
/* harmony import */ var _lib_hookStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6542);
/* harmony import */ var _lib_message__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5236);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9752);
/* harmony import */ var _tanstack_react_query_devtools__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9063);
/* harmony import */ var zustand_react_shallow__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5237);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_modal_Confirmation__WEBPACK_IMPORTED_MODULE_1__, _lib_hookStore__WEBPACK_IMPORTED_MODULE_3__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_5__, _tanstack_react_query_devtools__WEBPACK_IMPORTED_MODULE_6__, zustand_react_shallow__WEBPACK_IMPORTED_MODULE_7__]);
([_components_ui_modal_Confirmation__WEBPACK_IMPORTED_MODULE_1__, _lib_hookStore__WEBPACK_IMPORTED_MODULE_3__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_5__, _tanstack_react_query_devtools__WEBPACK_IMPORTED_MODULE_6__, zustand_react_shallow__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const queryClient = new _tanstack_react_query__WEBPACK_IMPORTED_MODULE_5__.QueryClient({
    defaultOptions: {
        queries: {
            refetchOnWindowFocus: false
        }
    }
});
function App({ Component , pageProps  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_tanstack_react_query__WEBPACK_IMPORTED_MODULE_5__.QueryClientProvider, {
        client: queryClient,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                ...pageProps
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tanstack_react_query_devtools__WEBPACK_IMPORTED_MODULE_6__.ReactQueryDevtools, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ToastMessage, {})
        ]
    });
}
function ToastMessage() {
    const [customMessage, customVariantToast, toast, hideToast, confirmation, hideConfirmation, confirmMessage, confirmationIsLoading, ] = (0,_lib_hookStore__WEBPACK_IMPORTED_MODULE_3__/* .useDialogStore */ .IA)((0,zustand_react_shallow__WEBPACK_IMPORTED_MODULE_7__.useShallow)((state)=>[
            state.customMessage,
            state.customVariantToast,
            state.toast,
            state.hideToast,
            state.confirmation,
            state.hideConfirmation,
            state.confirmMessage,
            state.confirmationIsLoading, 
        ]));
    const getVariant = ()=>{
        if (!customVariantToast) {
            return (toast === null || toast === void 0 ? void 0 : toast.startsWith("error-")) ? "danger" : "default";
        }
        return customVariantToast;
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_toast__WEBPACK_IMPORTED_MODULE_2__/* .Toast */ .F, {
                onHide: hideToast,
                show: !!toast,
                variant: getVariant(),
                children: [
                    !!toast && toast !== "custom-message" && _lib_message__WEBPACK_IMPORTED_MODULE_4__/* .TOAST_MESSAGE */ .cH[toast],
                    !!toast && toast === "custom-message" && customMessage
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_modal_Confirmation__WEBPACK_IMPORTED_MODULE_1__/* .Confirmation */ .T, {
                show: !!confirmation,
                onHide: hideConfirmation,
                onConfirm: confirmMessage,
                isLoading: confirmationIsLoading,
                children: [
                    !!confirmation && confirmation !== "costum-message" && _lib_message__WEBPACK_IMPORTED_MODULE_4__/* .CONFIRMATION_MESSAGE */ .Y5[confirmation],
                    !!confirmation && confirmation === "costum-message" && customMessage
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 4751:
/***/ ((module) => {

module.exports = require("react-icons/io");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4338:
/***/ ((module) => {

module.exports = import("@radix-ui/react-slot");;

/***/ }),

/***/ 9752:
/***/ ((module) => {

module.exports = import("@tanstack/react-query");;

/***/ }),

/***/ 9063:
/***/ ((module) => {

module.exports = import("@tanstack/react-query-devtools");;

/***/ }),

/***/ 6926:
/***/ ((module) => {

module.exports = import("class-variance-authority");;

/***/ }),

/***/ 6912:
/***/ ((module) => {

module.exports = import("zustand");;

/***/ }),

/***/ 5237:
/***/ ((module) => {

module.exports = import("zustand/react/shallow");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5152,1257,7912,6984,2054], () => (__webpack_exec__(7149)));
module.exports = __webpack_exports__;

})();