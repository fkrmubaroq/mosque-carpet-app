"use strict";
exports.id = 2209;
exports.ids = [2209];
exports.modules = {

/***/ 711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IL": () => (/* binding */ responseErrorMessage),
/* harmony export */   "VL": () => (/* binding */ ResponseError),
/* harmony export */   "Wk": () => (/* binding */ responseNotFound)
/* harmony export */ });
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(895);

class ResponseError extends Error {
    status;
    code;
    constructor(status, { message , code  }){
        super(message);
        this.status = status;
        this.code = code;
    }
}
function responseErrorMessage(e, res) {
    if (e instanceof ResponseError) {
        res.status(e.status).json({
            code: e.code || 1,
            message: e.message
        });
        return;
    }
    res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_0__/* .STATUS_MESSAGE_ENUM.InternalServerError */ .E.InternalServerError).json({
        message: e.message
    });
}
function responseNotFound(res) {
    // res.status(STATUS)
    res.status(_lib_enum__WEBPACK_IMPORTED_MODULE_0__/* .STATUS_MESSAGE_ENUM.NotFound */ .E.NotFound).json({
        message: "not found"
    });
}



/***/ }),

/***/ 895:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ STATUS_MESSAGE_ENUM)
/* harmony export */ });
const STATUS_MESSAGE_ENUM = {
    Ok: 200,
    BadRequest: 400,
    Unauthorized: 401,
    NotFound: 404,
    InternalServerError: 500,
    BadGateway: 502
};


/***/ }),

/***/ 4476:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ prismaClient)
/* harmony export */ });
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);

const prismaClient = new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient({
    errorFormat: "pretty",
    log: [
        "info",
        "query",
        "warn",
        "error"
    ]
});


/***/ })

};
;