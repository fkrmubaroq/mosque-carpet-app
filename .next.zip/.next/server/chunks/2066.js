exports.id = 2066;
exports.ids = [2066];
exports.modules = {

/***/ 2291:
/***/ ((module) => {

// Exports
module.exports = {
	"checkbox": "Checkbox_checkbox__ysWKT",
	"checkbox__input": "Checkbox_checkbox__input__3P_WU",
	"checkbox__label": "Checkbox_checkbox__label__w7_PS",
	"checkbox__icon": "Checkbox_checkbox__icon__1obMu"
};


/***/ }),

/***/ 5596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Checkbox)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Checkbox_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2291);
/* harmony import */ var _Checkbox_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Checkbox_module_scss__WEBPACK_IMPORTED_MODULE_4__);





const defaultColorChecked = {
    checked: "white",
    uncheck: "#4b5563"
};
const sizeList = {
    md: "w-5 h-5",
    lg: "w-6 h-6"
};
function Checkbox({ checked , onChange , text , className , size ="md"  }) {
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const checkedWithoutOnChangeRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(checked || false);
    const setCheckedMark = (el, status)=>{
        var ref;
        if (status) {
            var ref1;
            el.classList.add("border-primary", "!bg-primary");
            (ref1 = el.querySelector("svg")) === null || ref1 === void 0 ? void 0 : ref1.setAttribute("style", `color:${defaultColorChecked.checked}`);
            return;
        }
        (ref = el.querySelector("svg")) === null || ref === void 0 ? void 0 : ref.setAttribute("style", `color:${defaultColorChecked.uncheck}`);
        el.classList.remove("!bg-primary", "border-primary");
    };
    const handleChange = (e)=>{
        // cheked when without onChange
        if (!onChange && inputRef.current) {
            const checkedRef = !checkedWithoutOnChangeRef.current;
            inputRef.current.checked = checkedRef;
            checkedWithoutOnChangeRef.current = checkedRef;
            const labelEl = inputRef.current.nextElementSibling;
            if (!labelEl) return;
            const checkedMarkEl = labelEl.querySelector("div");
            if (!checkedMarkEl) return;
            setCheckedMark(checkedMarkEl, checkedRef);
            return;
        }
        e.stopPropagation();
        if (!inputRef.current) return;
        inputRef.current.click();
        onChange && onChange();
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
        className: (_Checkbox_module_scss__WEBPACK_IMPORTED_MODULE_4___default().checkbox),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                ref: inputRef,
                type: "checkbox",
                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("hidden", (_Checkbox_module_scss__WEBPACK_IMPORTED_MODULE_4___default().checkbox__input)),
                checked: checked,
                onChange: ()=>{}
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("relative flex cursor-pointer items-center gap-x-2", {
                    [(_Checkbox_module_scss__WEBPACK_IMPORTED_MODULE_4___default().checkbox__label)]: !onChange
                }),
                onClick: handleChange,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("relative block shrink-0 cursor-pointer rounded border border-gray-300 bg-gray-100", {
                            "border-primary !bg-primary": checked
                        }, className, sizeList[size]),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("flex items-center justify-center", (_Checkbox_module_scss__WEBPACK_IMPORTED_MODULE_4___default().checkbox__icon), {
                                "opacity-0": !checked
                            }),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_3__.BsCheckLg, {
                                size: 17,
                                color: checked ? defaultColorChecked.checked : defaultColorChecked.uncheck
                            })
                        })
                    }),
                    text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-sm",
                        children: text
                    }) : ""
                ]
            })
        ]
    });
}


/***/ }),

/***/ 2066:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y1": () => (/* binding */ Selection)
/* harmony export */ });
/* unused harmony exports SelectionList, ToggleOpen */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_pi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(150);
/* harmony import */ var react_icons_pi__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_pi__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Spinner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3508);
/* harmony import */ var _lib_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9339);
/* harmony import */ var _Checkbox__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5596);
/* harmony import */ var _input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3516);










// Selection [main]
const Selection = ({ value , values , placeholder , invalid , required =false , valid , enableSearch =true , options , onClickOption , onReset , name , variant ="no-background" , onFetchDataFromFilter , onListOpened , isLoading , className , customItemSelection , title , children , onClick , readOnly , classNameToggle  })=>{
    const { 0: opened , 1: setOpened  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: keyword , 1: setKeyword  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    (0,_lib_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useOnClickOutside */ .t$)(inputRef, ()=>{
        if (!opened) return;
        setOpened(false);
        setKeyword("");
        onFetchDataFromFilter && onFetchDataFromFilter("");
    });
    const handleClick = (item)=>{
        if (!onClickOption) return;
        onClickOption(item);
        setOpened(false);
        setKeyword("");
    };
    const filterData = options && options.filter((item)=>onFetchDataFromFilter || isLoading ? options : item.text.toLocaleLowerCase().includes(keyword.toLocaleLowerCase()));
    const handleChangeKeyword = (e)=>{
        onFetchDataFromFilter && onFetchDataFromFilter(e.target.value);
        setKeyword(e.target.value);
    };
    const handleToggle = ()=>{
        if (readOnly) return;
        onClick && onClick();
        onListOpened && onListOpened();
        setOpened((o)=>!o);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("relative"),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "relative flex flex-col",
            ref: inputRef,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    name: name,
                    required: required,
                    value: value === null || value === void 0 ? void 0 : value.toString(),
                    onChange: ()=>"",
                    onClick: handleToggle,
                    className: "text-input hidden"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    title: title,
                    onClick: handleToggle,
                    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("selection", "py-2 pl-4 pr-16", "text-sm outline-none", "border border-gray-300", "cursor-pointer rounded-md", "overflow-hidden text-ellipsis whitespace-nowrap break-all", className, {
                        "text-gray-400": placeholder && !value || readOnly,
                        "text-gray-800": value,
                        "bg-gray-50": !readOnly,
                        "bg-gray-200": readOnly
                    }),
                    children: !value ? readOnly && "-" || placeholder || "" : value
                }),
                onReset && value && !readOnly && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ResetButton, {
                    onReset: onReset,
                    variant: variant
                }),
                children ? children : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        !readOnly && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ToggleOpen, {
                            opened: opened,
                            onClick: handleToggle,
                            variant: variant,
                            className: classNameToggle
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SelectionList, {
                            value: value,
                            isLoading: isLoading,
                            enableSearch: enableSearch,
                            show: opened,
                            data: filterData || [],
                            onClick: handleClick,
                            onChangeKeyword: handleChangeKeyword,
                            selectedValues: values,
                            customItemSelection: customItemSelection
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "invalid-feedback",
                    children: invalid
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "valid-feedback",
                    children: valid
                })
            ]
        })
    });
};
// Reset Button
const listVariantButton = {
    "no-background": "right-38px",
    default: "right-[3.125rem] bg-slate-900 w-18px h-18px"
};
const listColorSvg = {
    "no-background": "#6B7280",
    default: "white"
};
const ResetButton = ({ onReset , variant ="default" ,  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("h-4 w-4 rounded-full", "absolute top-3", "flex cursor-pointer items-center justify-center", listVariantButton[variant]),
        onClick: ()=>onReset(),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__.AiOutlineClose, {
            color: listColorSvg[variant],
            width: "7.5",
            height: "7.5"
        })
    });
};
// Selection List
const SelectionList = ({ show , data , onClick , enableSearch , onChangeKeyword , multiple , selectedValues , isLoading , onSelectAll , onReset , customItemSelection , value ,  })=>{
    const allIsSelected = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return (selectedValues === null || selectedValues === void 0 ? void 0 : selectedValues.length) === data.length;
    }, [
        data.length,
        selectedValues === null || selectedValues === void 0 ? void 0 : selectedValues.length
    ]);
    const isSelected = (item)=>{
        return multiple && (selectedValues === null || selectedValues === void 0 ? void 0 : selectedValues.some((selected)=>selected.id === item.id));
    };
    if (!show) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "absolute inset-x-0 top-10 z-50 rounded-md bg-white pb-2 pt-2 drop-shadow-md",
        children: [
            enableSearch && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative mb-2.5 px-2.5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_input__WEBPACK_IMPORTED_MODULE_9__/* .Input */ .I, {
                        className: "!h-[37px] !border-gray-300",
                        placeholder: "Cari Pilihan",
                        onChange: onChangeKeyword
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "absolute right-5 top-2.5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiSearch, {
                            width: "15",
                            height: "15",
                            color: "#6b7280"
                        })
                    })
                ]
            }),
            multiple && onSelectAll && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "px- mx-4 my-4 flex justify-between text-xs",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex items-center gap-x-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Checkbox__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            checked: allIsSelected,
                            onChange: ()=>{
                                onSelectAll(!allIsSelected);
                            },
                            text: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-xs",
                                children: "Pilih semua"
                            })
                        })
                    }),
                    onReset && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "cursor-pointer font-medium",
                        onClick: onReset,
                        children: "Reset"
                    })
                ]
            }),
            isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex items-center justify-center gap-x-2",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Spinner__WEBPACK_IMPORTED_MODULE_6__/* .SpinnerIcon */ .L, {
                    width: "w-5",
                    height: "h-5"
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: data.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "max-h-[400px] overflow-y-auto",
                    children: data.map((item, key)=>{
                        /*#__PURE__*/ return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("group flex cursor-pointer list-none gap-x-3 px-4 text-xs text-slate-600 hover:bg-gray-100", {
                                "bg-gray-100": item.text === value
                            }),
                            onClick: ()=>onClick(item),
                            children: [
                                multiple && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Checkbox__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    className: "mt-3.5",
                                    checked: isSelected(item) || false,
                                    onChange: ()=>onClick(item)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex flex-col py-2 pr-2 group-hover:bg-gray-100",
                                    children: customItemSelection ? customItemSelection(item) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-normal text-gray-900",
                                                children: item.text
                                            }),
                                            (item === null || item === void 0 ? void 0 : item.subText) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-sm text-gray-400",
                                                children: item.subText
                                            })
                                        ]
                                    })
                                })
                            ]
                        }, key);
                    })
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "px-2.5 text-sm text-gray-400",
                    children: "Pencarian tidak ditemukan"
                })
            })
        ]
    });
};
// Toggle Open
const listVariantToggle = {
    "no-background": "",
    default: "bg-slate-900 rounded-r-md"
};
const colorVariantToggle = {
    "no-background": "#6B7280",
    default: "white"
};
const ToggleOpen = ({ opened , onClick , variant ="default" , className  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("absolute bottom-0 right-0 top-0 flex h-[2.375rem] w-[2.375rem] cursor-pointer items-center justify-center ", listVariantToggle[variant], className),
        onClick: onClick,
        children: !opened ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_pi__WEBPACK_IMPORTED_MODULE_5__.PiCaretDownBold, {
            color: colorVariantToggle[variant]
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_pi__WEBPACK_IMPORTED_MODULE_5__.PiCaretUpBold, {
            color: colorVariantToggle[variant]
        })
    });
};



/***/ })

};
;