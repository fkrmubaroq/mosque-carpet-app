"use strict";
exports.id = 9981;
exports.ids = [9981];
exports.modules = {

/***/ 1353:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NO": () => (/* binding */ updateStatusValidation),
/* harmony export */   "Vs": () => (/* binding */ updateProductValidation),
/* harmony export */   "vz": () => (/* binding */ insertProductValidation)
/* harmony export */ });
/* harmony import */ var joi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8506);
/* harmony import */ var joi__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(joi__WEBPACK_IMPORTED_MODULE_0__);

const insertProductValidation = joi__WEBPACK_IMPORTED_MODULE_0___default().object({
    name: joi__WEBPACK_IMPORTED_MODULE_0___default().string().max(255).required(),
    description: joi__WEBPACK_IMPORTED_MODULE_0___default().string().optional().allow(""),
    price: joi__WEBPACK_IMPORTED_MODULE_0___default().number().optional().empty("").default(0),
    stock: joi__WEBPACK_IMPORTED_MODULE_0___default().number().optional().empty("").default(0),
    category_id: joi__WEBPACK_IMPORTED_MODULE_0___default().number().required(),
    image: joi__WEBPACK_IMPORTED_MODULE_0___default().object().optional(),
    active: joi__WEBPACK_IMPORTED_MODULE_0___default().string().max(1).optional()
});
const updateProductValidation = joi__WEBPACK_IMPORTED_MODULE_0___default().object({
    id: joi__WEBPACK_IMPORTED_MODULE_0___default().number().required(),
    name: joi__WEBPACK_IMPORTED_MODULE_0___default().string().max(255).optional(),
    description: joi__WEBPACK_IMPORTED_MODULE_0___default().string().allow("").optional(),
    price: joi__WEBPACK_IMPORTED_MODULE_0___default().number().optional().empty("").default(0),
    stock: joi__WEBPACK_IMPORTED_MODULE_0___default().number().optional().empty("").default(0),
    category_id: joi__WEBPACK_IMPORTED_MODULE_0___default().number().optional(),
    image: joi__WEBPACK_IMPORTED_MODULE_0___default().object().optional(),
    active: joi__WEBPACK_IMPORTED_MODULE_0___default().string().max(1).optional()
});
const updateStatusValidation = joi__WEBPACK_IMPORTED_MODULE_0___default().number().required();



/***/ }),

/***/ 9169:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ validation)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(895);


function validation(schema, data) {
    const validate = schema.validate(data, {
        abortEarly: false,
        allowUnknown: false
    });
    if (validate.error) {
        throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_1__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, {
            code: 1,
            message: validate.error.message
        });
    }
    return validate.value;
}


/***/ })

};
;