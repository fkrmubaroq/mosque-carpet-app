"use strict";
exports.id = 574;
exports.ids = [574];
exports.modules = {

/***/ 574:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Td": () => (/* binding */ Td),
/* harmony export */   "Th": () => (/* binding */ Th),
/* harmony export */   "Tr": () => (/* binding */ Tr),
/* harmony export */   "Z": () => (/* binding */ Table),
/* harmony export */   "h": () => (/* binding */ Thead)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);


function Table({ children  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "relative overflow-x-auto",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("table", {
            className: "w-full text-left text-sm text-gray-500 ",
            children: children
        })
    });
}
function Thead({ children  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
        className: "bg-gray-50 text-xs uppercase text-gray-700 ",
        children: children
    });
}
function Th({ children , className  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
        scope: "col",
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("px-6 py-3 h-[55px]", className),
        children: children
    });
}
function Tr({ children , className  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("h-[55px] border-b bg-white hover:bg-gray-50", className),
        children: children
    });
}
function Td({ children , className  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("px-6 py-4", className),
        children: children
    });
}


/***/ })

};
;