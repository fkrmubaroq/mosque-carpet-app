"use strict";
exports.id = 8472;
exports.ids = [8472];
exports.modules = {

/***/ 5803:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "x": () => (/* binding */ SelectionCategory)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_api_category__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9743);
/* harmony import */ var _lib_queryKeys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9067);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(873);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9752);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ui_form_Select__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2066);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_api_category__WEBPACK_IMPORTED_MODULE_1__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_4__]);
([_lib_api_category__WEBPACK_IMPORTED_MODULE_1__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function SelectionCategory({ value , onReset , required , placeholder , invalid , onClickOption ,  }) {
    const { 0: enabled , 1: setEnabled  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: selectionSearch , 1: setSelectionSearch  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
    const debounceSearch = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__/* .debounce */ .Ds)(setSelectionSearch);
    const { data: dataBuyers , isFetching  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_4__.useQuery)({
        retry: false,
        enabled: enabled,
        staleTime: 20000,
        queryKey: _lib_queryKeys__WEBPACK_IMPORTED_MODULE_2__/* .selectionQuery.category */ .Zm.category,
        queryFn: async ()=>{
            const params = {
                name: selectionSearch
            };
            const response = await (0,_lib_api_category__WEBPACK_IMPORTED_MODULE_1__/* .getCategory */ .n3)(params);
            if (response.status >= 299) throw new Error();
            const data = response.data.data;
            response.data;
            return (data === null || data === void 0 ? void 0 : data.map((item)=>({
                    id: item.id,
                    text: item.category_name
                }))) || [];
        }
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_form_Select__WEBPACK_IMPORTED_MODULE_6__/* .Selection */ .Y1, {
            onListOpened: ()=>setEnabled(true),
            required: required,
            placeholder: placeholder,
            invalid: invalid,
            options: dataBuyers || [],
            onFetchDataFromFilter: debounceSearch,
            onClickOption: onClickOption,
            value: value || "",
            onReset: onReset,
            isLoading: isFetching
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8472:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ModalForm)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_Spinner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3508);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1257);
/* harmony import */ var _components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3768);
/* harmony import */ var _components_ui_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2975);
/* harmony import */ var _components_ui_form_Textarea__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3008);
/* harmony import */ var _components_ui_form_UploadFile__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5815);
/* harmony import */ var _components_ui_form_input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3516);
/* harmony import */ var _components_ui_label__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4184);
/* harmony import */ var _components_ui_modal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7912);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _SelectionFeature__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5803);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_button__WEBPACK_IMPORTED_MODULE_2__, _components_ui_label__WEBPACK_IMPORTED_MODULE_8__, _SelectionFeature__WEBPACK_IMPORTED_MODULE_12__]);
([_components_ui_button__WEBPACK_IMPORTED_MODULE_2__, _components_ui_label__WEBPACK_IMPORTED_MODULE_8__, _SelectionFeature__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const titleType = {
    add: "Tambah",
    edit: "Ubah"
};
function ModalForm({ onHide , type ="add" , show , data , onSave , isLoading , onEdit ,  }) {
    const formRef = (0,react__WEBPACK_IMPORTED_MODULE_11__.useRef)(null);
    const { 0: prevImage , 1: setPrevImage  } = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)();
    const { 0: form , 1: setForm  } = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(data);
    const { 0: validated , 1: setValidated  } = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(false);
    const { 0: selectedCategory , 1: setSelectedCategory  } = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_11__.useEffect)(()=>{
        if (type === "edit") {
            if (form.image) {
                setPrevImage(form.image);
            }
            const categoryName = form === null || form === void 0 ? void 0 : form.category_name;
            if (!categoryName || !form.category_id) return;
            setSelectedCategory({
                id: form.category_id,
                text: categoryName
            });
        }
    }, [
        type
    ]);
    const onClickCategory = (selected)=>{
        setForm((form)=>({
                ...form,
                category_id: +selected.id
            }));
        setSelectedCategory(selected);
    };
    const onChange = (e)=>{
        setForm((form)=>({
                ...form,
                [e.target.name]: e.target.value
            }));
    };
    const onSubmitForm = (e)=>{
        var ref;
        e.preventDefault();
        const valid = (ref = formRef.current) === null || ref === void 0 ? void 0 : ref.checkValidity();
        setValidated(true);
        if (!valid) return;
        setValidated(false);
        type === "add" && onSave(form);
        type === "edit" && onEdit(form);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_modal__WEBPACK_IMPORTED_MODULE_9__/* .Modal */ .u_, {
        show: show,
        size: "w-[800px]",
        onHide: onHide,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_modal__WEBPACK_IMPORTED_MODULE_9__/* .ModalHeader */ .xB, {
                onHide: ()=>onHide && onHide(),
                children: [
                    titleType[type],
                    " Produk"
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_modal__WEBPACK_IMPORTED_MODULE_9__/* .ModalBody */ .fe, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_form__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    ref: formRef,
                    validated: validated,
                    onSubmit: onSubmitForm,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-4 flex items-center gap-x-7",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-[320px] shrink-0",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_label__WEBPACK_IMPORTED_MODULE_8__/* .Label */ ._, {
                                            children: "Gambar"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_UploadFile__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                            maxFileSizeMb: 1.5,
                                            onChange: (file, next)=>{
                                                next && next(file);
                                                setForm((form)=>({
                                                        ...form,
                                                        image: file[0]
                                                    }));
                                            },
                                            placeholder: "PNG, JPG, WEBP, GIF (Ukuran Maksimal 1.5Mb)",
                                            accept: [
                                                "image/jpeg",
                                                "image/jpg",
                                                "image/png",
                                                "image/webp",
                                                "image/gif", 
                                            ]
                                        }),
                                        type === "edit" && form.image && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex flex-col items-center gap-y-2 mt-3",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_label__WEBPACK_IMPORTED_MODULE_8__/* .Label */ ._, {
                                                    children: "Gambar sebelumnya"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                        src: `/api/files/products/${prevImage}`,
                                                        width: 110,
                                                        height: 110,
                                                        className: "rounded-md",
                                                        alt: ""
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex w-full flex-col gap-y-4",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_label__WEBPACK_IMPORTED_MODULE_8__/* .Label */ ._, {
                                                    children: "Nama Produk"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_7__/* .Input */ .I, {
                                                    required: true,
                                                    invalid: "Nama produk wajib diisi",
                                                    name: "name",
                                                    placeholder: "Nama",
                                                    value: form.name,
                                                    onChange: onChange
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_label__WEBPACK_IMPORTED_MODULE_8__/* .Label */ ._, {
                                                    children: "Kategori"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SelectionFeature__WEBPACK_IMPORTED_MODULE_12__/* .SelectionCategory */ .x, {
                                                    required: true,
                                                    invalid: "Kategori wajib diisi",
                                                    placeholder: "Pilih Kategori",
                                                    value: (selectedCategory === null || selectedCategory === void 0 ? void 0 : selectedCategory.id) ? selectedCategory === null || selectedCategory === void 0 ? void 0 : selectedCategory.text : "",
                                                    onClickOption: onClickCategory
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_label__WEBPACK_IMPORTED_MODULE_8__/* .Label */ ._, {
                                                    children: "Harga"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_7__/* .Input */ .I, {
                                                    name: "price",
                                                    type: "number",
                                                    placeholder: "Harga",
                                                    value: form.price || "",
                                                    onChange: onChange
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_label__WEBPACK_IMPORTED_MODULE_8__/* .Label */ ._, {
                                                    children: "Stok"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_7__/* .Input */ .I, {
                                                    name: "stock",
                                                    placeholder: "Stock",
                                                    value: form.stock || "",
                                                    onChange: onChange
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_label__WEBPACK_IMPORTED_MODULE_8__/* .Label */ ._, {
                                                    children: "Deskripsi"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_Textarea__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                    name: "description",
                                                    autoSize: true,
                                                    value: form.description,
                                                    onChange: onChange
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex justify-end gap-x-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .z, {
                                    variant: "ghost",
                                    size: "lg",
                                    onClick: ()=>onHide && onHide(),
                                    children: "Batal"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .z, {
                                    type: "submit",
                                    size: "lg",
                                    disabled: isLoading,
                                    children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_Spinner__WEBPACK_IMPORTED_MODULE_1__/* .SpinnerIcon */ .L, {
                                        width: "w-4",
                                        height: "h-4"
                                    }) : "Simpan"
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;