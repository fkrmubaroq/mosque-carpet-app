"use strict";
exports.id = 7912;
exports.ids = [7912];
exports.modules = {

/***/ 7912:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fe": () => (/* binding */ ModalBody),
/* harmony export */   "u_": () => (/* binding */ Modal),
/* harmony export */   "xB": () => (/* binding */ ModalHeader)
/* harmony export */ });
/* unused harmony export ModalFooter */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__);




const Portal = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "../components/ui/modal/index.jsx -> " + "@/components/ui/portal"
        ]
    },
    ssr: false
});
function Modal({ children , show , size ="md" , onHide , className , title , onMouseOver , onMouseOut , showClose =false , verticallyCentered =false  }) {
    const modalSize = {
        [size]: size,
        md: "max-w-[31.25rem]",
        lg: "max-w-[40.625rem]",
        xl: "max-w-[62rem]",
        xxl: "max-w-[85.375rem]"
    };
    if (!show) return null;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Portal, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("fixed top-0 z-[999999] h-full w-full overflow-y-auto bg-transparent px-2 font-jasans", {
                "flex justify-center items-center": verticallyCentered
            }),
            onMouseOver: (e)=>onMouseOver && onMouseOver(e),
            onMouseOut: (e)=>onMouseOut && onMouseOut(e),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "fixed inset-0 h-full w-full bg-black opacity-20",
                    onClick: ()=>onHide && onHide()
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("animate-scale relative mx-auto my-5 min-w-[20rem] rounded-lg bg-white", modalSize[size], className),
                    children: [
                        title && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ModalHeader, {
                            onHide: ()=>onHide && onHide(),
                            children: title
                        }),
                        showClose && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "absolute right-4 top-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CloseBtnModal, {
                                onHide: ()=>onHide && onHide()
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: children
                        })
                    ]
                })
            ]
        })
    });
}
// Modal Body
function ModalBody({ children , className  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("p-5", className),
        children: children
    });
}
// Modal Header
const variantHeader = {
    primary: "bg-primary text-white",
    transparent: ""
};
function ModalHeader({ variant ="primary" , className , children , onHide ,  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("flex items-center justify-between rounded-t-lg border-b p-4", className, variantHeader[variant]),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: "tracking-wide",
                children: children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CloseBtnModal, {
                onHide: onHide
            })
        ]
    });
}
// Close Btn
function CloseBtnModal({ onHide  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "cursor-pointer",
        onClick: onHide,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__.AiOutlineClose, {
            size: 15,
            color: "white"
        })
    });
}
// Modal Footer
function ModalFooter({ children , className  }) {
    return /*#__PURE__*/ _jsx("div", {
        className: cn("flex items-center space-x-2 rounded-b border-t border-gray-200 p-5", className),
        children: children
    });
}


/***/ })

};
;