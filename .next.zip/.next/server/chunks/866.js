"use strict";
exports.id = 866;
exports.ids = [866];
exports.modules = {

/***/ 866:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Jg": () => (/* binding */ slugString),
/* harmony export */   "QE": () => (/* binding */ incomingRequest),
/* harmony export */   "cn": () => (/* binding */ createFile),
/* harmony export */   "y3": () => (/* binding */ unlinkFile)
/* harmony export */ });
/* unused harmony exports debounce, convertObjToDataSelection, checkResolutionImage, formatNumberToPrice, createThumbnailVideo, handleDragZoneHover, sleep, formatBytes, copyToClipboard, generateID, fileIsExists, objectIntoFormData, mediaPath, setCursorPosition, strippedStrings, getCookieName, isClient, getCookie, setCookie, eraseCookie, getArticleTime, getWord, selectedFileName, downloadFileUrl */
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2472);



function debounce(func, timeout = 300) {
    let timer;
    return (...args)=>{
        clearTimeout(timer);
        timer = setTimeout(()=>{
            func.apply(this, args);
        }, timeout);
    };
}
function convertObjToDataSelection(obj, swap = false) {
    return Object.keys(obj).map((key)=>({
            id: swap ? obj[key] : key,
            text: swap ? key : obj[key]
        }));
}
function checkResolutionImage(file) {
    return new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (e)=>{
            var ref, ref1;
            if (!((ref = e.target) === null || ref === void 0 ? void 0 : ref.result)) reject();
            const image = new Image();
            image.src = (ref1 = e.target) === null || ref1 === void 0 ? void 0 : ref1.result;
            image.onload = ()=>{
                resolve({
                    width: image.width,
                    height: image.height
                });
            };
        };
    });
}
function formatNumberToPrice(priceInt, delimiters = ".") {
    if (typeof priceInt !== "number" && typeof priceInt !== "string") return priceInt;
    return priceInt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, delimiters);
}
const createThumbnailVideo = (file, cb)=>{
    const video = document.createElement("video");
    video.src = URL.createObjectURL(file);
    video.addEventListener("loadeddata", ()=>{
        var ref;
        const canvas = document.createElement("canvas"); // create canvas element
        if (!canvas) return;
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        (ref = canvas.getContext("2d")) === null || ref === void 0 ? void 0 : ref.drawImage(video, 0, 0, canvas.width, canvas.height); // draw video frame on canvas
        const thumbnailVideo = canvas.toDataURL("image/jpeg"); // convert canvas to jpeg image URL
        cb(thumbnailVideo);
        URL.revokeObjectURL(video.src); // release object URL
    });
};
const handleDragZoneHover = (e, hover)=>{
    const target = e.target;
    hover ? target.classList.add("!border-primary") : target.classList.remove("!border-primary");
    e.preventDefault();
};
function sleep(timeout) {
    return new Promise((resolve)=>setTimeout(resolve, timeout));
}
function formatBytes(bytes, decimals = 2) {
    if (!+bytes) return "0 Bytes";
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = [
        "Bytes",
        "KB",
        "MB",
        "GB",
        "TB",
        "PB",
        "EB",
        "ZB",
        "YB"
    ];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}
function copyToClipboard(text) {
    var ref;
    const elInput = document.createElement("input");
    elInput.id = "copy-clipboard";
    elInput.value = text;
    document.body.append(elInput);
    const copyText = document.getElementById(elInput.id);
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(copyText.value);
    (ref = document.getElementById(elInput.id)) === null || ref === void 0 ? void 0 : ref.remove();
    return copyText.value;
}
const generateID = (length)=>{
    let result = "";
    const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    for(var i = 0; i < length; i++){
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
};
async function incomingRequest(form, req) {
    return await new Promise((resolve, reject)=>{
        form.parse(req, function(err, fields, files) {
            if (err) reject({
                err
            });
            const bodyText = {};
            Object.keys(fields).forEach((key)=>{
                bodyText[key] = fields[key].toString();
            });
            const bodyFile = {};
            Object.keys(files).forEach((key)=>{
                bodyFile[key] = files[key][0];
            });
            resolve({
                ...bodyText,
                files: bodyFile
            });
        });
    });
}
async function fileIsExists(src) {
    return new Promise((resolve, reject)=>{
        fs.access(src, async (err)=>{
            if (err) {
                reject(err);
                return;
            }
            resolve(true);
        });
    });
}
async function unlinkFile(src) {
    return new Promise((resolve)=>{
        fs__WEBPACK_IMPORTED_MODULE_1___default().access(src, async (err)=>{
            if (err) {
                resolve(false);
                return;
            }
            await fs__WEBPACK_IMPORTED_MODULE_1___default().promises.unlink(src);
            resolve(true);
        });
    });
}
async function createFile(src, destination) {
    const contentData = await fs__WEBPACK_IMPORTED_MODULE_1___default().promises.readFile(src);
    await fs__WEBPACK_IMPORTED_MODULE_1___default().promises.writeFile(destination, contentData);
}
function objectIntoFormData(payload) {
    const form = new FormData();
    for(const key in payload){
        form.append(key, payload[key]);
    }
    return form;
}
function mediaPath(dir, fileName) {
    return `${DIR_ACCESS_FILE}/${dir}/${fileName}`;
}
function setCursorPosition(el, position) {
    const range = document.createRange();
    const sel = window.getSelection();
    range.setStart(el.childNodes[0], position);
    range.collapse(true);
    sel.removeAllRanges();
    sel.addRange(range);
    el.focus();
}
function strippedStrings(originalString) {
    return originalString.replace(/(<([^>]+)>)/gi, "");
}
function slugString(string) {
    return string.toLowerCase().replace(/ /g, "-").replace(/[^\w-]+/g, "");
    ;
}
function getDomain() {
    const env = "local";
    if (env === "local") return "localhost";
    if (env === "staging") return `dev.bursakarpetmasjid.com`;
    if (env === "production") return "bursakarpetmasjid.com";
}
function getCookieName(name) {
    const env = "local";
    return `${env}-${name}`;
}
const isClient = ()=>"undefined" !== "undefined";
function getCookie(name, serverRequest) {
    if (serverRequest) return (serverRequest === null || serverRequest === void 0 ? void 0 : serverRequest.cookies.get(getCookieName(name))) || null;
    const cookieName = `${getCookieName(name)}=`;
    const cookies = document.cookie.split(";");
    for(let i = 0; i < cookies.length; i++){
        let cookie = cookies[i];
        while(cookie.charAt(0) == " "){
            cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) == 0) {
            return cookie.substring(cookieName.length, cookie.length);
        }
    }
    return null;
}
function setCookie(name, value, expireDays) {
    const date = new Date();
    let expires = "";
    if (expireDays) {
        date.setTime(date.getTime() + expireDays * 24 * 60 * 60 * 1000);
        expires = `expires=${date.toUTCString()}`;
    }
    document.cookie = `${getCookieName(name)}=${value}; ${expires};path=/; domain=${getDomain()};`;
}
function eraseCookie(name) {
    document.cookie = `${getCookieName(name)}=; domain=${getDomain()}; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;`;
}
const getArticleTime = (date)=>{
    var ref;
    const formatDate = dayjs(date).format("YYYY-MM-DD");
    const year = (ref = formatDate.split("-")) === null || ref === void 0 ? void 0 : ref[0];
    const now = new Date();
    if (now.getFullYear() > +year) return dayjs(date).format("DD MMMM YYYY HH:mm");
    return dayjs().to(dayjs(date));
};
function getWord(writerName, totalWord, separator = " ") {
    const data = writerName.split(separator);
    return data.slice(0, totalWord).join(" ");
}
function selectedFileName(inputEl) {
    const split = inputEl.value.split(".");
    const endRangeFileName = (split)=>{
        let count = 0;
        for(let i = 0; i < split.length - 1; i++){
            count += split[i].length;
        }
        return count;
    };
    const end = endRangeFileName(split);
    inputEl.focus();
    inputEl.setSelectionRange(0, end);
}
function downloadFileUrl(url, fileName) {
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}


/***/ })

};
;