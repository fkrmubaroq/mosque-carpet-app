"use strict";
exports.id = 9764;
exports.ids = [9764];
exports.modules = {

/***/ 9764:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ro": () => (/* binding */ ShimmerTableRow),
/* harmony export */   "qm": () => (/* binding */ Shimmer),
/* harmony export */   "x1": () => (/* binding */ Line)
/* harmony export */ });
/* unused harmony export Circle */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(574);




function Shimmer({ children , className  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("flex animate-pulse", className),
        children: children
    });
}
function Circle({ className , width ="w-10" , height ="h-10" ,  }) {
    return /*#__PURE__*/ _jsx("div", {
        className: cn("rounded-full bg-slate-200", width, height, className)
    });
}
function Line({ width ="w-full" , height ="h-2"  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("h-2 rounded bg-slate-200", width, height)
    });
}
function ShimmerTableRow({ colspan =4  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_table__WEBPACK_IMPORTED_MODULE_3__.Tr, {
        children: Array(colspan).fill(1).map((item, key)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_table__WEBPACK_IMPORTED_MODULE_3__.Td, {
                className: "!border-none",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Shimmer, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Line, {})
                })
            }, key))
    });
}


/***/ })

};
;