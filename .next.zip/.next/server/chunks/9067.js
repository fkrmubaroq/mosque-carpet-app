"use strict";
exports.id = 9067;
exports.ids = [9067];
exports.modules = {

/***/ 9067:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K6": () => (/* binding */ collectionsQuery),
/* harmony export */   "W4": () => (/* binding */ adminCategoryQuery),
/* harmony export */   "Zm": () => (/* binding */ selectionQuery),
/* harmony export */   "a8": () => (/* binding */ adminArticleQuery),
/* harmony export */   "ag": () => (/* binding */ adminFileManagerQuery),
/* harmony export */   "i2": () => (/* binding */ landingPageQuery),
/* harmony export */   "jE": () => (/* binding */ productsQuery),
/* harmony export */   "t5": () => (/* binding */ adminProductQuery)
/* harmony export */ });
/* unused harmony export productQuery */
const productQuery = {
    category: [
        "product",
        "category"
    ]
};
const selectionQuery = {
    category: [
        "selection",
        "category"
    ]
};
const adminProductQuery = {
    getAll: (page, keyword)=>[
            "admin",
            "product",
            page,
            keyword
        ]
};
const adminCategoryQuery = {
    getAll: (page, keyword)=>[
            "admin",
            "category",
            page,
            keyword
        ]
};
const adminFileManagerQuery = {
    getFIleItems: (path)=>[
            "admin",
            "file-manager",
            path
        ]
};
const adminArticleQuery = {
    getAll: (page, keyword)=>[
            "admin",
            "article",
            page,
            keyword
        ],
    getDetail: (id)=>[
            "admin",
            "article",
            id
        ]
};
const landingPageQuery = {
    getCategories: [
        "lp",
        "category"
    ],
    getArticles: [
        "lp",
        "articles"
    ],
    getAllArticles: [
        "all",
        "articles"
    ]
};
const collectionsQuery = {
    getCategories: [
        "collections"
    ]
};
const productsQuery = {
    getProducts: [
        "products-category"
    ],
    detailProduct: (slug)=>[
            "products-detail",
            slug
        ],
    similarCategory: (slug)=>[
            "similar-category",
            slug
        ]
};


/***/ })

};
;