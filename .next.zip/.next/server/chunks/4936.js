"use strict";
exports.id = 4936;
exports.ids = [4936];
exports.modules = {

/***/ 4400:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ insertArticleValidation),
/* harmony export */   "z": () => (/* binding */ updateArticleValidation)
/* harmony export */ });
/* harmony import */ var joi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8506);
/* harmony import */ var joi__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(joi__WEBPACK_IMPORTED_MODULE_0__);

const insertArticleValidation = joi__WEBPACK_IMPORTED_MODULE_0___default().object({
    content: joi__WEBPACK_IMPORTED_MODULE_0___default().string().required(),
    thumbnail: joi__WEBPACK_IMPORTED_MODULE_0___default().object().required(),
    title: joi__WEBPACK_IMPORTED_MODULE_0___default().string().max(191).required(),
    writer: joi__WEBPACK_IMPORTED_MODULE_0___default().string().max(191).required()
});
const updateArticleValidation = joi__WEBPACK_IMPORTED_MODULE_0___default().object({
    content: joi__WEBPACK_IMPORTED_MODULE_0___default().string().optional(),
    thumbnail: joi__WEBPACK_IMPORTED_MODULE_0___default().object().optional(),
    title: joi__WEBPACK_IMPORTED_MODULE_0___default().string().max(191).optional(),
    writer: joi__WEBPACK_IMPORTED_MODULE_0___default().string().max(191).optional()
});



/***/ }),

/***/ 9169:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ validation)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(895);


function validation(schema, data) {
    const validate = schema.validate(data, {
        abortEarly: false,
        allowUnknown: false
    });
    if (validate.error) {
        throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_1__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, {
            code: 1,
            message: validate.error.message
        });
    }
    return validate.value;
}


/***/ })

};
;