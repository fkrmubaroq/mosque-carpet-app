exports.id = 9089;
exports.ids = [9089];
exports.modules = {

/***/ 7038:
/***/ ((module) => {

// Exports
module.exports = {
	"layout": "layout_layout__1Q_8m",
	"expanded": "layout_expanded__TKZCo",
	"sidebar": "layout_sidebar__IJgpu",
	"sidebar__menu": "layout_sidebar__menu__ucOJc",
	"sidebar__label": "layout_sidebar__label__vNx2g",
	"header": "layout_header__z5bTA",
	"content": "layout_content__x4Qy8"
};


/***/ }),

/***/ 9089:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ Layout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_api_section__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9135);
/* harmony import */ var _lib_hookStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6542);
/* harmony import */ var _lib_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9339);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(873);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9752);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8625);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_icons_ci__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_icons_lu__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8510);
/* harmony import */ var react_icons_lu__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_icons_lu__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_icons_pi__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(150);
/* harmony import */ var react_icons_pi__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_icons_pi__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5452);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_icons_rx__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var react_icons_tfi__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1740);
/* harmony import */ var react_icons_tfi__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_icons_tfi__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var react_icons_vsc__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(382);
/* harmony import */ var react_icons_vsc__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(react_icons_vsc__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var zustand_react_shallow__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(5237);
/* harmony import */ var _Meta__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(5766);
/* harmony import */ var _ui_Spinner__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(3508);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(1257);
/* harmony import */ var _ui_switch_toggle__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(1788);
/* harmony import */ var _layout_module_scss__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(7038);
/* harmony import */ var _layout_module_scss__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(_layout_module_scss__WEBPACK_IMPORTED_MODULE_26__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_api_section__WEBPACK_IMPORTED_MODULE_1__, _lib_hookStore__WEBPACK_IMPORTED_MODULE_2__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_5__, zustand_react_shallow__WEBPACK_IMPORTED_MODULE_21__, _ui_button__WEBPACK_IMPORTED_MODULE_24__]);
([_lib_api_section__WEBPACK_IMPORTED_MODULE_1__, _lib_hookStore__WEBPACK_IMPORTED_MODULE_2__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_5__, zustand_react_shallow__WEBPACK_IMPORTED_MODULE_21__, _ui_button__WEBPACK_IMPORTED_MODULE_24__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



























const sidebarMenus = [
    {
        label: "HOME",
        menus: [
            {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_11__.BiHomeAlt, {
                    size: 20
                }),
                menu: "Beranda",
                path: "/admin/dashboard"
            }, 
        ]
    },
    {
        label: "MASTER",
        menus: [
            {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ci__WEBPACK_IMPORTED_MODULE_12__.CiBoxes, {
                    size: 20
                }),
                menu: "Produk",
                path: "/admin/products"
            },
            {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ci__WEBPACK_IMPORTED_MODULE_12__.CiBoxList, {
                    size: 20
                }),
                menu: "Kategori Produk",
                path: "/admin/category"
            },
            {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_tfi__WEBPACK_IMPORTED_MODULE_19__.TfiPackage, {
                    size: 18
                }),
                menu: "Paket Bundle",
                path: "/admin/package-bundle"
            }, 
        ]
    },
    {
        label: "Lainnya",
        menus: [
            {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_rx__WEBPACK_IMPORTED_MODULE_18__.RxSection, {
                    size: 20
                }),
                menu: "Sections",
                path: "/admin/section"
            },
            {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_15__.MdOutlineArticle, {
                    size: 20
                }),
                menu: "Artikel",
                path: "/admin/articles"
            },
            {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_vsc__WEBPACK_IMPORTED_MODULE_20__.VscFolderLibrary, {
                    size: 20
                }),
                menu: "Media Manager",
                path: "/admin/file-manager"
            },
            {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_10__.AiOutlineSetting, {
                    size: 20
                }),
                menu: "Pengaturan",
                path: "/admin/settings"
            }, 
        ]
    }, 
];
function Layout({ children , customTitle , title , classNameTitle  }) {
    const [cookie, setCookie] = (0,_lib_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useCookie */ .By)("adm");
    const { 0: expand , 1: setExpand  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(true);
    const { 0: dropdown , 1: setDropdown  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const route = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const [showToast, showConfirmation, hideConfirmation] = (0,_lib_hookStore__WEBPACK_IMPORTED_MODULE_2__/* .useDialogStore */ .IA)((state)=>[
            state.showToast,
            state.showConfirmation,
            state.hideConfirmation
        ]);
    const [sectionsLp, viewIdSection, setViewIdSection] = (0,_lib_hookStore__WEBPACK_IMPORTED_MODULE_2__/* .useEditSection */ .eK)((0,zustand_react_shallow__WEBPACK_IMPORTED_MODULE_21__.useShallow)((state)=>[
            state.sectionsLp,
            state.viewIdSection,
            state.setViewIdSection
        ]));
    const isSectionPage = route.pathname === "/admin/section";
    const isSettingPage = route.pathname === "/admin/settings";
    const isCreateArticlePage = route.pathname === "/admin/articles/create";
    const isUpdateArticlePage = route.pathname.includes("/admin/articles/edit");
    const dropdownRef = (0,react__WEBPACK_IMPORTED_MODULE_9__.useRef)();
    (0,_lib_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useOnClickOutside */ .t$)(dropdownRef, ()=>{
        if (!dropdownRef.current) return;
        setDropdown(false);
    });
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        if (route.pathname === "/admin/section") {
            setExpand(false);
        }
    }, []);
    const { mutate: mutateUpdateSection , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_5__.useMutation)({
        mutationFn: _lib_api_section__WEBPACK_IMPORTED_MODULE_1__/* .updateSections */ .a,
        onSuccess: ()=>showToast("success-update-section"),
        onError: ()=>showToast("error-update-section")
    });
    const onPublish = ()=>{
        const sections = sectionsLp.map((section)=>({
                ...section,
                content: JSON.stringify(section.content)
            }));
        mutateUpdateSection({
            sections
        });
    };
    const onClickDropdown = (menu)=>{
        switch(menu.text){
            case "Keluar":
                showConfirmation("logout", {
                    onConfirm () {
                        (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .eraseCookie */ .Mz)("adm");
                        window.location.href = "/login";
                    }
                });
                break;
            case "Profil":
                next_router__WEBPACK_IMPORTED_MODULE_8___default().push("/admin/profile");
                break;
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Meta__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                title: title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_6___default()((_layout_module_scss__WEBPACK_IMPORTED_MODULE_26___default().layout), {
                    [(_layout_module_scss__WEBPACK_IMPORTED_MODULE_26___default().expanded)]: expand
                }),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()((_layout_module_scss__WEBPACK_IMPORTED_MODULE_26___default().header), {
                            "fixed bg-white z-[99999] right-0 shadow-sm": isSectionPage || isSettingPage || isCreateArticlePage || isUpdateArticlePage,
                            "left-[270px]": (isSettingPage || isSectionPage || isCreateArticlePage || isUpdateArticlePage) && expand,
                            "left-[75px]": (isSettingPage || isSectionPage || isCreateArticlePage || isUpdateArticlePage) && !expand
                        }),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center gap-x-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        onClick: ()=>setExpand((e)=>!e),
                                        className: "flex h-11 w-11 cursor-pointer items-center justify-center gap-x-3 hover:rounded-md hover:bg-primary/20",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_rx__WEBPACK_IMPORTED_MODULE_18__.RxHamburgerMenu, {
                                            size: 20
                                        })
                                    }),
                                    customTitle && customTitle,
                                    !customTitle && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("text-lg font-medium", classNameTitle),
                                        children: title
                                    })
                                ]
                            }),
                            isSectionPage && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-x-2",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_button__WEBPACK_IMPORTED_MODULE_24__/* .Button */ .z, {
                                        onClick: ()=>window.open(window.location.origin),
                                        variant: "ghost",
                                        className: "border border-gray-600 gap-x-2 flex items-center justify-center !rounded-full",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_13__.IoIosGlobe, {
                                                size: 20
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: "Website"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_24__/* .Button */ .z, {
                                        disabled: isLoading,
                                        className: "!rounded-full",
                                        size: "lg",
                                        onClick: ()=>onPublish(),
                                        children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_Spinner__WEBPACK_IMPORTED_MODULE_23__/* .SpinnerIcon */ .L, {
                                            width: "w-4",
                                            height: "h-4"
                                        }) : "Publish"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-x-5 items-center",
                                children: [
                                    isSectionPage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_switch_toggle__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
                                            text: "ID Section",
                                            checked: viewIdSection,
                                            onChange: (checked)=>setViewIdSection(checked)
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        ref: dropdownRef,
                                        onClick: ()=>setDropdown((o)=>!o),
                                        className: "cursor-pointer bg-white relative flex items-center gap-x-2 rounded-lg p-2 ",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_15__.MdOutlineAccountCircle, {
                                                size: 33,
                                                className: "opacity-50"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex flex-col gap-y-1 border-r pr-3 ",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text-sm font-semibold text-gray-500 ",
                                                        children: (cookie === null || cookie === void 0 ? void 0 : cookie.name) || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text-xs text-gray-600 ",
                                                        children: "Admin"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: " h-full ",
                                                children: dropdown ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_13__.IoIosArrowUp, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_13__.IoIosArrowDown, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DropdownMenu, {
                                                show: dropdown,
                                                onClick: onClickDropdown
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_layout_module_scss__WEBPACK_IMPORTED_MODULE_26___default().sidebar),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(" mt-5 flex items-center gap-x-4 overflow-hidden rounded-lg bg-primary/95", {
                                    "mx-5 mb-2 px-4 py-3": expand,
                                    "mx-3 justify-center pb-2 pt-3": !expand
                                }),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "shrink-0 overflow-hidden",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            src: "/img/logo.png",
                                            width: expand ? "35" : "25",
                                            height: expand ? "35" : "25",
                                            alt: ""
                                        })
                                    }),
                                    expand && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col overflow-hidden font-jasans",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "overflow-hidden font-medium tracking-widest text-white",
                                                children: "AL - HIJRA"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-xs text-gray-200",
                                                children: "Admin"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_layout_module_scss__WEBPACK_IMPORTED_MODULE_26___default().sidebar__menu),
                                children: sidebarMenus.map((sidebar, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()({
                                            "flex flex-col items-center justify-center": !expand
                                        }),
                                        children: [
                                            expand ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_layout_module_scss__WEBPACK_IMPORTED_MODULE_26___default().sidebar__label),
                                                children: sidebar.label
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_pi__WEBPACK_IMPORTED_MODULE_16__.PiDotsThreeLight, {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "mb-6 flex flex-col gap-y-1",
                                                children: sidebar.menus.map((menu, key)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MenuItem, {
                                                        data: menu,
                                                        expand: expand,
                                                        activeMenu: route.pathname
                                                    }, key))
                                            })
                                        ]
                                    }, key))
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_layout_module_scss__WEBPACK_IMPORTED_MODULE_26___default().content),
                        children: children
                    })
                ]
            })
        ]
    });
}
function MenuItem({ data , expand , activeMenu ,  }) {
    const isActiveMenu = activeMenu.includes(data.path);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("group flex h-11 cursor-pointer items-center gap-x-3 rounded-md hover:bg-primary/10 hover:text-primary", {
            "pl-3 pr-4": expand,
            "w-11 justify-center": !expand,
            "bg-primary/10 text-primary": isActiveMenu
        }),
        onClick: ()=>next_router__WEBPACK_IMPORTED_MODULE_8___default().push(data.path),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "shrink-0 w-8 h-8 justify-center items-center flex",
                children: data.icon
            }),
            expand && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("text-sm text-gray-600 group-hover:text-primary", {
                    "text-primary": isActiveMenu
                }),
                children: data.menu
            })
        ]
    });
}
const listMenu = [
    {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_lu__WEBPACK_IMPORTED_MODULE_14__.LuUser, {}),
        text: "Profil"
    },
    {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_17__.RiShutDownLine, {}),
        text: "Keluar"
    }
];
function DropdownMenu({ show , onClick  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("absolute transition-all -left-0 border  w-[160px] bg-white rounded-md", {
            "top-14 opacity-100 z-[999]": show,
            "top-8 opacity-0 -z-10": !show
        }),
        children: listMenu.map((menu, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                onClick: (e)=>{
                    e.stopPropagation();
                    onClick(menu);
                },
                className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("px-3 py-2 text-gray-500 group items-center flex gap-x-2.5 first:rounded-t-md last:rounded-b-md", {
                    "hover:bg-primary hover:text-white": show
                }),
                children: [
                    menu.icon,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-sm",
                        children: menu.text
                    })
                ]
            }, key))
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1788:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ToggleSwitch)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);


function ToggleSwitch({ className , text , checked , onChange ,  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("inline-flex cursor-pointer items-center", className),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        type: "checkbox",
                        className: "peer sr-only",
                        checked: checked,
                        onChange: ()=>onChange(!checked)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("h-6 w-11", "bg-gray-200 peer-focus:outline-none", "rounded-full after:content-[''] ", "after:absolute after:left-[2px] after:top-[2px] after:border after:border-gray-300 after:bg-white ", "after:h-5 after:w-5 after:rounded-full after:transition-all", {
                            "peer-checked:bg-primary peer-checked:after:translate-x-full peer-checked:after:border-white": checked
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("ml-3 text-sm", {
                    "text-gray-400": !checked
                }),
                children: text
            })
        ]
    });
}


/***/ }),

/***/ 9135:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ updateSections)
/* harmony export */ });
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9254);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_0__]);
___WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

function updateSections(payload, config) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .putMethod */ .yu)("sections", payload, {
        headers: {
            "Content-Type": "application/json"
        }
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;