"use strict";
exports.id = 1038;
exports.ids = [1038];
exports.modules = {

/***/ 3768:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ContainerInput)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);


const listDirection = {
    row: "flex flex-row gap-x-2 items-center",
    col: "flex flex-col gap-y-2"
};
function ContainerInput({ children , className , direction ="col"  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()(className, listDirection[direction]),
        children: children
    });
}


/***/ }),

/***/ 5815:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2470);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(873);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _card__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1739);








const UploadFile = ({ required , invalid , multiple , name , allowResolutionImage , onChange , maxFileSizeMb , accept , placeholder , className , onRemove ,  })=>{
    const fileRef = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const { 0: error , 1: setError  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
    const { 0: selectedFile , 1: setSelectedFile  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)();
    const resetValue = ()=>{
        if (!fileRef.current) return;
        fileRef.current.value = "";
        if (fileRef.current.nextElementSibling) {
            const wrapper = fileRef.current.nextElementSibling;
            wrapper.style.backgroundImage = "";
            wrapper.classList.remove("!border-solid");
            wrapper.classList.remove("!border-primary");
        }
    };
    const validationFile = (file)=>{
        if (maxFileSizeMb) {
            const sizeMB = file.size / (1024 * 1024);
            if (sizeMB > maxFileSizeMb) {
                setError(`File melebihi ukuran maksimum ${maxFileSizeMb} MB`);
                return false;
            }
        }
        if (accept && !accept.includes(file.type)) {
            setError(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    "Format file harus",
                    " ",
                    Array.isArray(accept) ? accept === null || accept === void 0 ? void 0 : accept.map((type, key)=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "mr-[1px]",
                            children: [
                                ".",
                                _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .MIME_TYPE */ .J3[type].toLocaleUpperCase(),
                                " "
                            ]
                        }, key);
                    }) : `Format file harus .${_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .MIME_TYPE */ .J3[file.type]}`
                ]
            }));
            return false;
        }
        setError("");
        return true;
    };
    const handleChange = async (e)=>{
        if (!fileRef.current) return;
        const files = "dataTransfer" in e ? e.dataTransfer.files : e.target.files;
        if (!(files === null || files === void 0 ? void 0 : files.length)) {
            resetValue();
            return;
        }
        if ("dataTransfer" in e) {
            fileRef.current.required = false;
        }
        for(let i = 0; i < files.length; i++){
            const valid = validationFile(files[i]);
            if (!valid) {
                setSelectedFile(undefined);
                resetValue();
                return;
            }
            // check resolution image if any
            if ((allowResolutionImage === null || allowResolutionImage === void 0 ? void 0 : allowResolutionImage.length) && _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .MIME_TYPE_IMAGE */ .Gn[files[i].type]) {
                const { width , height  } = await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__/* .checkResolutionImage */ .zv)(files[i]);
                if (!allowResolutionImage.includes(`${width}x${height}`)) {
                    resetValue();
                    setError(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            "Resolusi gambar harus",
                            " ",
                            allowResolutionImage.map((item, key)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "mr-1 font-semibold",
                                    children: item
                                }, key))
                        ]
                    }));
                    return;
                }
            }
        }
        onChange && onChange(files, (files)=>{
            setSelectedFile(files);
        });
    };
    const handleClick = (e)=>{
        e.stopPropagation();
        fileRef.current && fileRef.current.click();
    };
    const onDrag = (e)=>{
        e.preventDefault();
        if (!e.dataTransfer.files.length) return;
        handleChange(e);
        const target = e.target;
        target.classList.remove("!border-primary");
    };
    const handleRemove = (e)=>{
        e.stopPropagation();
        resetValue();
        onRemove && onRemove();
        if (required && fileRef.current) {
            fileRef.current.required = true;
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                accept: accept === null || accept === void 0 ? void 0 : accept.toString(),
                required: required,
                type: "file",
                name: name,
                className: "upload-file hidden",
                ref: fileRef,
                onChange: handleChange,
                multiple: multiple
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("wrapper-upload-file upload-file-drop-zone relative overflow-auto", className, {
                    "flex-col flex items-center justify-center": !selectedFile
                }),
                onClick: handleClick,
                onDrop: onDrag,
                onDragOver: (e)=>(0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__/* .handleDragZoneHover */ .xy)(e, true),
                onDragLeave: (e)=>(0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__/* .handleDragZoneHover */ .xy)(e, false),
                children: selectedFile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("grid gap-3", {
                        "grid-cols-3": selectedFile.length > 1,
                        "grid-cols-2": selectedFile.length === 2,
                        "grid-cols-1": selectedFile.length === 1
                    }),
                    children: Array.from(selectedFile).map((file, key)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PreviewFile, {
                            file: file
                        }, key))
                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col items-center justify-center pb-6 pt-5",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__.AiOutlineCloudUpload, {
                            size: 30,
                            color: "#6b7280"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col items-center justify-center text-center",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "mb-2 text-sm text-gray-400",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-semibold",
                                            children: "Klik untuk upload"
                                        }),
                                        " atau drop file disini"
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-xs text-gray-400",
                                    children: placeholder
                                })
                            ]
                        })
                    ]
                })
            }),
            error && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "ml-[2px] mt-1 text-xs text-red-500",
                children: error
            }),
            invalid && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "invalid-feedback",
                children: invalid
            })
        ]
    });
};
function PreviewFile({ file  }) {
    const getSrcFile = (file)=>URL.createObjectURL(file);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .MIME_TYPE_IMAGE */ .Gn[file.type] && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_card__WEBPACK_IMPORTED_MODULE_7__/* .Card */ .Zb, {
            className: "rounded-none",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_card__WEBPACK_IMPORTED_MODULE_7__/* .CardContent */ .aY, {
                className: "flex flex-col justify-center gap-y-2 !pb-4 !pt-3 !px-3 ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                        src: getSrcFile(file),
                        width: "100",
                        height: "100",
                        alt: "",
                        className: "object-cover"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-sm font-semibold text-gray-600 line-clamp-2",
                        children: file.name
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-sm text-gray-400",
                        children: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatBytes */ .td)(file.size)
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UploadFile);


/***/ })

};
;