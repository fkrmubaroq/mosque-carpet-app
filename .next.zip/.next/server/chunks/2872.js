"use strict";
exports.id = 2872;
exports.ids = [2872];
exports.modules = {

/***/ 3993:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ItemBox)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function ItemBox({ icon , text , onClick  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex items-center gap-x-1 p-2 cursor-pointer hover:rounded-r-md ",
        onClick: ()=>onClick(),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "shrink-0",
                children: icon
            }),
            text && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "text-xs",
                children: text
            })
        ]
    });
}


/***/ }),

/***/ 5209:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ModalToolboxFooter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1257);
/* harmony import */ var _components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3768);
/* harmony import */ var _components_ui_form_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3516);
/* harmony import */ var _components_ui_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7912);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(49);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__, _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__]);
([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__, _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function ModalToolboxFooter({ title , data , onHide , show , onUpdateContent  }) {
    const { 0: form , 1: setForm  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(data);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_modal__WEBPACK_IMPORTED_MODULE_4__/* .Modal */ .u_, {
        verticallyCentered: true,
        className: "w-[450px]",
        show: show,
        onHide: ()=>onHide && onHide(),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_modal__WEBPACK_IMPORTED_MODULE_4__/* .ModalHeader */ .xB, {
                onHide: ()=>onHide && onHide(),
                children: title || ""
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_modal__WEBPACK_IMPORTED_MODULE_4__/* .ModalBody */ .fe, {
                className: "flex flex-col gap-y-4",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__.Label, {
                                className: "text-sm font-medium",
                                children: "Text"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_3__/* .Input */ .I, {
                                placeholder: "Masukkan teks",
                                name: "text",
                                value: (form === null || form === void 0 ? void 0 : form.text) || "",
                                onChange: (e)=>setForm((form)=>({
                                            ...form,
                                            [e.target.name]: e.target.value
                                        }))
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__.Label, {
                                className: "text-sm font-medium",
                                children: "Link (optional)"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_3__/* .Input */ .I, {
                                value: (form === null || form === void 0 ? void 0 : form.link) || "",
                                placeholder: "Masukkan link",
                                name: "link",
                                onChange: (e)=>setForm((form)=>({
                                            ...form,
                                            [e.target.name]: e.target.value
                                        }))
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_1__/* .Button */ .z, {
                        className: "w-full mt-3",
                        onClick: ()=>{
                            onUpdateContent(form);
                        },
                        children: "Simpan"
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 680:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ModalToolboxImage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1257);
/* harmony import */ var _components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3768);
/* harmony import */ var _components_ui_form_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3516);
/* harmony import */ var _components_ui_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7912);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(49);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__, _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__]);
([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__, _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function ModalToolboxImage({ name , value , onHide , show , onUpdateContent  }) {
    const { 0: currentValue , 1: setCurrentValue  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(value);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_modal__WEBPACK_IMPORTED_MODULE_4__/* .Modal */ .u_, {
        verticallyCentered: true,
        className: "w-[450px]",
        show: show,
        onHide: ()=>onHide && onHide(),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_modal__WEBPACK_IMPORTED_MODULE_4__/* .ModalHeader */ .xB, {
                onHide: ()=>onHide && onHide(),
                children: "Ganti Gambar"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_modal__WEBPACK_IMPORTED_MODULE_4__/* .ModalBody */ .fe, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__.Label, {
                                children: "Link Gambar"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_3__/* .Input */ .I, {
                                value: currentValue,
                                placeholder: "Masukkan link gambar",
                                onChange: (e)=>setCurrentValue(e.target.value)
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "text-gray-500 text-xs",
                        children: [
                            "Upload Gambar anda ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-primary font-semibold cursor-pointer hover:underline",
                                onClick: ()=>window.open("/admin/file-manager"),
                                children: "disini"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_1__/* .Button */ .z, {
                        className: "w-full mt-3",
                        onClick: ()=>{
                            onUpdateContent(name, currentValue);
                        },
                        children: "Simpan"
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4408:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ToolboxFooter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_lu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8510);
/* harmony import */ var react_icons_lu__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_lu__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ItemBox__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3993);
/* harmony import */ var _ModalToolboxFooter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5209);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ModalToolboxFooter__WEBPACK_IMPORTED_MODULE_5__]);
_ModalToolboxFooter__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const initModal = Object.freeze({
    show: false
});
function ToolboxFooter({ index , data , name , className , onUpdateContent  }) {
    const { 0: modal , 1: setModal  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(initModal);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            modal.show && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalToolboxFooter__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                title: "Ganti Kontak footer",
                data: modal === null || modal === void 0 ? void 0 : modal.data,
                show: modal.show,
                onHide: ()=>setModal(initModal),
                verticallyCentered: true,
                className: "w-[450px]",
                onUpdateContent: (form)=>{
                    onUpdateContent(form);
                    setModal(initModal);
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("absolute -right-7 top-0 z-20", className),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "bg-primary hover:bg-primary-hover shadow-lg group rounded-r-md flex gap-x-2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ItemBox__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_lu__WEBPACK_IMPORTED_MODULE_3__.LuPencil, {
                            color: "white",
                            size: 17
                        }),
                        text: "",
                        onClick: ()=>{
                            if (name === "address") {
                                setModal({
                                    show: true,
                                    data: {
                                        ...data[name][index]
                                    }
                                });
                                return;
                            }
                            setModal({
                                show: true,
                                data: {
                                    ...data[name]
                                }
                            });
                        }
                    })
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7240:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ToolboxImage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8625);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_ci__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ItemBox__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3993);
/* harmony import */ var _ModalToolboxImage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(680);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ModalToolboxImage__WEBPACK_IMPORTED_MODULE_5__]);
_ModalToolboxImage__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const initModal = Object.freeze({
    show: false,
    type: ""
});
const positionToolbox = {
    centered: "top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2",
    bottomRight: "-bottom-0 -right-0"
};
function ToolboxImage({ text ="Ganti" , noText , position ="centered" , name , value , className , onUpdateContent  }) {
    const { 0: modal , 1: setModal  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(initModal);
    const onClickUpdateImage = ()=>{
        setModal({
            type: "update-image",
            show: true
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalToolboxImage__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                name: name,
                show: modal.show,
                onHide: ()=>setModal(initModal),
                onUpdateContent: (name, value)=>{
                    setModal(initModal);
                    onUpdateContent(name, value);
                },
                value: value
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("absolute  z-[999] p-2", positionToolbox[position], className),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "bg-primary text-white hover:bg-primary-hover shadow-lg rounded-md flex gap-x-2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ItemBox__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ci__WEBPACK_IMPORTED_MODULE_3__.CiImageOn, {
                            size: 17
                        }),
                        text: noText ? "" : text,
                        onClick: onClickUpdateImage
                    })
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 458:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2470);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6563);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_contenteditable__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _Fragment_Toolbox_ToolboxFooter__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4408);
/* harmony import */ var _Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7240);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Fragment_Toolbox_ToolboxFooter__WEBPACK_IMPORTED_MODULE_11__, _Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_12__]);
([_Fragment_Toolbox_ToolboxFooter__WEBPACK_IMPORTED_MODULE_11__, _Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













function FooterMemo({ setting , edit , section , onUpdateContent  }) {
    const content = (section === null || section === void 0 ? void 0 : section.content) || {};
    const onUpdate = (name, value)=>{
        onUpdateContent({
            ...section,
            content: {
                ...section.content,
                [name]: value
            }
        });
    };
    const onUpdateContact = (name, value, index)=>{
        if (name === "address" && index >= 0) {
            const cloneAddress = structuredClone(section.content.contact.address);
            cloneAddress.splice(index, 1, {
                ...cloneAddress[index],
                ...value
            });
            onUpdateContent({
                ...section,
                content: {
                    ...section.content,
                    contact: {
                        ...section.content.contact,
                        address: cloneAddress
                    }
                }
            });
            return;
        }
        onUpdateContent({
            ...section,
            content: {
                ...section.content,
                contact: {
                    ...section.content.contact,
                    [name]: value
                }
            }
        });
    };
    const onUpdateSocialMedia = (name, value)=>{
        onUpdateContent({
            ...section,
            content: {
                ...section.content,
                social_media: {
                    ...section.content.social_media,
                    [name]: value
                }
            }
        });
    };
    const onAddItemContact = (name)=>{
        onUpdateContent({
            ...section,
            content: {
                ...section.content,
                contact: {
                    ...section.content.contact,
                    [name]: [
                        ...section.content.contact[name],
                        {
                            link: "",
                            text: ""
                        }
                    ]
                }
            }
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
        className: "relative flex gap-x-4 bg-black pt-20 pb-28 md:px-5",
        id: "section_footer",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex lg:flex-row flex-col lg:gap-y-0 gap-y-8 justify-between w-full", _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .CONTAINER_LP */ .oc),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterLogo, {
                    edit: edit,
                    onUpdateContent: onUpdate,
                    data: content
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterContactItem, {
                    setting: setting,
                    edit: edit,
                    data: content.contact,
                    onUpdateContent: onUpdateContact,
                    onAddItem: onAddItemContact
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterSocialMedia, {
                    edit: edit,
                    onUpdateContent: onUpdateSocialMedia,
                    data: content.social_media
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterCopyright, {})
            ]
        })
    });
}
function FooterLogo({ edit , onUpdateContent , data  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col lg:items-center lg:justify-center",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("relative", {
                    "section-mode-edit group": edit
                }),
                children: [
                    edit && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        value: data === null || data === void 0 ? void 0 : data.logo,
                        name: "logo",
                        onUpdateContent: onUpdateContent,
                        className: "group-hover:block hidden"
                    }),
                    (data === null || data === void 0 ? void 0 : data.logo) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                        src: data === null || data === void 0 ? void 0 : data.logo,
                        width: "80",
                        height: "80",
                        alt: ""
                    })
                ]
            }),
            edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default()), {
                html: data.logo_text,
                tagName: "span",
                className: "text-lg tracking-widest text-white mt-3 section-mode-edit",
                onChange: (e)=>onUpdateContent("logo_text", e.currentTarget.textContent)
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "text-lg tracking-widest text-white mt-3",
                children: data.logo_text
            }),
            edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default()), {
                html: data.tagline,
                tagName: "span",
                className: "text-gray-50 text-sm section-mode-edit",
                onChange: (e)=>onUpdateContent("tagline", e.currentTarget.textContent)
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "text-gray-50 text-sm",
                children: data.tagline
            })
        ]
    });
}
function FooterContactItem({ setting , onAddItem , data , edit , onUpdateContent  }) {
    var ref, ref1, ref2;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col gap-y-3 text-white",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterTitleItem, {
                title: "Contact"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col gap-y-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterContentItem, {
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__.AiOutlineWhatsApp, {}),
                        text: (data === null || data === void 0 ? void 0 : (ref = data.phone_wa) === null || ref === void 0 ? void 0 : ref.text) || "",
                        data: data,
                        edit: edit,
                        name: "phone_wa",
                        onUpdateContent: (value)=>onUpdateContent("phone_wa", value)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterContentItem, {
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__.AiOutlineMail, {}),
                        text: (data === null || data === void 0 ? void 0 : (ref1 = data.email) === null || ref1 === void 0 ? void 0 : ref1.text) || "",
                        data: data,
                        edit: edit,
                        name: "email",
                        onUpdateContent: (value)=>onUpdateContent("email", value)
                    }),
                    (ref2 = data.address) === null || ref2 === void 0 ? void 0 : ref2.map((item, key)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterContentItem, {
                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_10__.HiOutlineLocationMarker, {}),
                            text: item.text || "",
                            data: data,
                            edit: edit,
                            index: key,
                            name: "address",
                            onUpdateContent: (value)=>onUpdateContent("address", value, key)
                        }, key)),
                    edit && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        onClick: ()=>onAddItem("address"),
                        className: "flex bg-primary rounded-md hover:bg-primary-hover gap-x-1 cursor-pointer mt-2 p-2 justify-center items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_9__.FiPlus, {
                                color: "white",
                                size: 17
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-sm",
                                children: "Tambah Alamat"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
function FooterTitleItem({ title  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "text-2xl lg:text-3xl font-cinzel ",
        children: title
    });
}
function FooterContentItem({ index , name , data , icon , text , edit , onUpdateContent , onAddAddress  }) {
    const contentRef = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex gap-x-2 items-center group cursor-pointer",
        ref: contentRef,
        children: [
            icon,
            edit ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default()), {
                        html: text,
                        onChange: (e)=>onUpdateContent({
                                ...data[name],
                                text: e.currentTarget.textContent
                            }),
                        className: "section-mode-edit peer"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Fragment_Toolbox_ToolboxFooter__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        name: name,
                        index: index,
                        data: data,
                        className: "group-hover:block hidden peer-focus:block",
                        onUpdateContent: onUpdateContent
                    })
                ]
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex w-full",
                onClick: ()=>{
                    var ref;
                    return ((ref = data[name]) === null || ref === void 0 ? void 0 : ref.link) && window.open(data[name].link);
                },
                children: text
            })
        ]
    });
}
function FooterSocialMedia({ data , edit , onUpdateContent  }) {
    var ref, ref1, ref2;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col gap-y-3 text-white",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterTitleItem, {
                title: "Social Media"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col gap-y-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterContentItem, {
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__.AiOutlineInstagram, {}),
                        text: data === null || data === void 0 ? void 0 : (ref = data.instagram) === null || ref === void 0 ? void 0 : ref.text,
                        data: data,
                        edit: edit,
                        name: "instagram",
                        onUpdateContent: (value)=>onUpdateContent("instagram", value)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterContentItem, {
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_8__.BsFacebook, {}),
                        text: data === null || data === void 0 ? void 0 : (ref1 = data.facebook) === null || ref1 === void 0 ? void 0 : ref1.text,
                        data: data,
                        edit: edit,
                        name: "facebook",
                        onUpdateContent: (value)=>onUpdateContent("facebook", value)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterContentItem, {
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_7__.BiLogoTiktok, {}),
                        text: data === null || data === void 0 ? void 0 : (ref2 = data.tiktok) === null || ref2 === void 0 ? void 0 : ref2.text,
                        data: data,
                        edit: edit,
                        name: "tiktok",
                        onUpdateContent: (value)=>onUpdateContent("tiktok", value)
                    })
                ]
            })
        ]
    });
}
function FooterCopyright() {
    const currentYear = new Date().getFullYear();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "absolute text-center bottom-0 left-0 right-0 h-11 border-t-[0.1px] border-gray-600",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(_lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .CONTAINER_LP */ .oc, "flex h-full items-center justify-center text-white text-sm"),
            children: [
                "Copyright \xa9 ",
                currentYear,
                " | All Rights Reserved"
            ]
        })
    });
}
const SectionFooter = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_4__.memo)(FooterMemo);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionFooter);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3768:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ContainerInput)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);


const listDirection = {
    row: "flex flex-row gap-x-2 items-center",
    col: "flex flex-col gap-y-2"
};
function ContainerInput({ children , className , direction ="col"  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()(className, listDirection[direction]),
        children: children
    });
}


/***/ }),

/***/ 9641:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ prismaClient)
/* harmony export */ });
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);

const prismaClient = new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient({
    errorFormat: "pretty",
    log: [
        "info",
        "query",
        "warn",
        "error"
    ]
});


/***/ })

};
;