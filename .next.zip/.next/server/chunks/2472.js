"use strict";
exports.id = 2472;
exports.ids = [2472];
exports.modules = {

/***/ 2472:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PI": () => (/* binding */ DIR_FILE_THUMBNAIL),
/* harmony export */   "Pi": () => (/* binding */ EXPIRED_DAYS),
/* harmony export */   "TO": () => (/* binding */ DIR_FILE_UPLOAD),
/* harmony export */   "ew": () => (/* binding */ OFFSET),
/* harmony export */   "k": () => (/* binding */ DIR_FILE_CATEGORY),
/* harmony export */   "lh": () => (/* binding */ DIR_FILE_PRODUCTS)
/* harmony export */ });
/* unused harmony exports MIME_TYPE_VIDEO, MIME_TYPE_IMAGE, MIME_TYPE, BASE_DIR, DIR_ACCESS_FILE, placeholderImage, INIT_SECTIONS, CONTAINER_LP, MARGIN_EACH_SECTION */
const MIME_TYPE_VIDEO = {
    "video/mp4": "mp4",
    "video/webm": "webm",
    "video/ogg": "ogg",
    "video/quicktime": "mov"
};
const MIME_TYPE_IMAGE = {
    "image/gif": "gif",
    "image/jpeg": "jpeg",
    "image/jpg": "jpg",
    "image/png": "png",
    "image/svg+xml": "svg",
    "image/tiff": "tiff",
    "image/webp": "webp"
};
const MIME_TYPE = {
    ...MIME_TYPE_IMAGE,
    ...MIME_TYPE_VIDEO
};
const OFFSET = 20;
const EXPIRED_DAYS = 60 * 60 * 24 * 30; // 1 days
const BASE_DIR = "./files";
const DIR_FILE_UPLOAD = `${BASE_DIR}/upload`;
const DIR_FILE_PRODUCTS = `${BASE_DIR}/products`;
const DIR_FILE_CATEGORY = `${BASE_DIR}/categories`;
const DIR_FILE_THUMBNAIL = `${BASE_DIR}/articles-thumbnail`;
const DIR_ACCESS_FILE = (/* unused pure expression or super */ null && (`/api/files`));
const placeholderImage = (/* unused pure expression or super */ null && (`/img/placeholder.webp`));
const INIT_SECTIONS = [
    {
        "section_name": "section_hero",
        "content": {
            "logo": "http://localhost:3000/api/files/Sections/logo.png",
            "logo_text": "Al-Hijra",
            "tagline": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
            "sub_tagline": {
                "title": "Luxury at its finest",
                "text": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500sd"
            },
            "menus": [
                {
                    "menu": "",
                    "link": "",
                    "text": "About Us"
                },
                {
                    "menu": "",
                    "link": "",
                    "text": "Collections"
                },
                {
                    "menu": "",
                    "link": "",
                    "text": "Contact Us"
                },
                {
                    "menu": "",
                    "link": "",
                    "text": "Our Products"
                }
            ],
            "banner": "http://localhost:3000/api/files/Sections/banner.webp",
            "button_secondary": "View More",
            "button_primary": "Collection"
        },
        "position": 1
    },
    {
        "section_name": "section_about_us",
        "content": {
            "heading": "About Us",
            "title": "Lorem Ipsum",
            "text": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
            "image": "http://localhost:3000/api/files/Sections/category-4.jpg"
        },
        "position": 2
    },
    {
        "section_name": "section_vision_mision",
        "content": {
            "heading": "",
            "title": "",
            "vision": {
                "title": "Our Vision",
                "text": "To be a leading ‘One Stop Luxury Haven’ where we constantly enhance our products and services."
            },
            "mision": {
                "title": "Our Vision",
                "text": "Create value for our customers by offering relentless exceptional quality furnishings &amp; services."
            }
        },
        "position": 3
    },
    {
        "section_name": "section_why_choose_us",
        "content": {
            "heading": "Our Value",
            "title": "Why Choose US",
            "text": [
                "Create value for our customers by offering relentless exceptional quality furnishings",
                "Our designers are trained to help the customers realize their vision of their dream home."
            ],
            "button_primary": "OUR SERVICE"
        },
        "position": 4
    },
    {
        "section_name": "section_contact_us",
        "content": {
            "title": "Finding Finer Solution For Your Home?",
            "text": "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
            "button_primary": "Contact Now"
        },
        "position": 5
    },
    {
        "section_name": "section_footer",
        "content": {
            "logo_text": "AL-HIJRA",
            "tagline": "Ibadah Semakin nyaman",
            "contact": {
                "address": [
                    {
                        "link": "https://map",
                        "text": "Jln Saluyu Indah X No.9H"
                    }
                ],
                "phone_wa": {
                    "link": "https://map",
                    "text": "08886351120"
                },
                "email": {
                    "link": "https://map",
                    "text": "alhijracarpet@mail.com"
                }
            },
            "social_media": {
                "instagram": {
                    "link": "https://map",
                    "text": "Instagram"
                },
                "facebook": {
                    "link": "https://map",
                    "text": "Facebook"
                },
                "tiktok": {
                    "link": "https://map",
                    "text": "Tiktok"
                }
            },
            "logo": "http://localhost:3000/api/files/Sections/logo.png"
        },
        "position": 6
    },
    {
        "section_name": "section_articles",
        "content": {},
        "position": 7
    },
    {
        "section_name": "section_categories",
        "content": {},
        "position": 8
    }, 
];
const CONTAINER_LP = "padding-container xl:w-[1280px]";
const MARGIN_EACH_SECTION = "lg:mb-[100px] mb-16";


/***/ })

};
;