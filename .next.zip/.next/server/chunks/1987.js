"use strict";
exports.id = 1987;
exports.ids = [1987];
exports.modules = {

/***/ 2440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DT": () => (/* binding */ createFolderValidation),
/* harmony export */   "jF": () => (/* binding */ updateFolderNameValidation),
/* harmony export */   "kZ": () => (/* binding */ updateFileNameValidation)
/* harmony export */ });
/* harmony import */ var joi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8506);
/* harmony import */ var joi__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(joi__WEBPACK_IMPORTED_MODULE_0__);

const createFolderValidation = joi__WEBPACK_IMPORTED_MODULE_0___default().object({
    name: joi__WEBPACK_IMPORTED_MODULE_0___default().string().max(255).required().pattern(/^[a-zA-Z0-9\-\_\!\@\#\$\%\^\&\*\(\)\s]+$/).messages({
        "string.pattern.base": "Nama folder tidak valid",
        "string.max": "Nama folder terlalu panjang"
    }),
    path: joi__WEBPACK_IMPORTED_MODULE_0___default().string().max(255).required()
});
const updateFolderNameValidation = joi__WEBPACK_IMPORTED_MODULE_0___default().object({
    name: joi__WEBPACK_IMPORTED_MODULE_0___default().string().max(255).required().pattern(/^[a-zA-Z0-9\-\_\!\@\#\$\%\^\&\*\(\)\s]+$/).messages({
        "string.pattern.base": "Nama folder tidak valid",
        "string.max": "Nama folder terlalu panjang"
    }).required()
});
const updateFileNameValidation = joi__WEBPACK_IMPORTED_MODULE_0___default().object({
    name: joi__WEBPACK_IMPORTED_MODULE_0___default().string().max(255).required().messages({
        "string.pattern.base": "Nama file tidak valid",
        "string.max": "Nama file terlalu panjang"
    }).required()
});



/***/ }),

/***/ 9169:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ validation)
/* harmony export */ });
/* harmony import */ var _errors_response_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(711);
/* harmony import */ var _lib_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(895);


function validation(schema, data) {
    const validate = schema.validate(data, {
        abortEarly: false,
        allowUnknown: false
    });
    if (validate.error) {
        throw new _errors_response_error__WEBPACK_IMPORTED_MODULE_0__/* .ResponseError */ .VL(_lib_enum__WEBPACK_IMPORTED_MODULE_1__/* .STATUS_MESSAGE_ENUM.BadRequest */ .E.BadRequest, {
            code: 1,
            message: validate.error.message
        });
    }
    return validate.value;
}


/***/ })

};
;