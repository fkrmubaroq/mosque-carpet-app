"use strict";
exports.id = 9339;
exports.ids = [9339];
exports.modules = {

/***/ 9339:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "By": () => (/* binding */ useCookie),
/* harmony export */   "XA": () => (/* binding */ useMobile),
/* harmony export */   "t$": () => (/* binding */ useOnClickOutside)
/* harmony export */ });
/* unused harmony export useToggle */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(873);


function useOnClickOutside(ref, handler) {
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const listener = (event)=>{
            // Do nothing if clicking ref's element or descendent elements
            if (!ref.current || ref.current.contains(event.target)) return;
            handler();
        };
        document.addEventListener("mousedown", listener);
        document.addEventListener("touchstart", listener);
        return ()=>{
            document.removeEventListener("mousedown", listener);
            document.removeEventListener("touchstart", listener);
        };
    }, [
        ref,
        handler
    ]);
}
function useMobile() {
    const { 0: mobileMd , 1: setMobileMdWidth  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const { 0: mobileSm , 1: setMobileSm  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const mobile = {
        mobileMd,
        mobileSm
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const checkScreenWidth = ()=>{
            const width = window.innerWidth;
            const mobileMdWidth = width <= 968;
            const mobileSmWidth = width <= 640;
            if (mobileSmWidth) {
                setMobileSm(true);
                setMobileMdWidth(false);
                return;
            }
            setMobileSm(false);
            setMobileMdWidth(mobileMdWidth);
        };
        const debounceCheckScreenWidth = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .debounce */ .Ds)(checkScreenWidth);
        debounceCheckScreenWidth();
        window.addEventListener("resize", debounceCheckScreenWidth);
        return ()=>window.removeEventListener("resize", debounceCheckScreenWidth);
    }, [
        mobile
    ]);
    return {
        mobileMd,
        mobileSm
    };
}
function useToggle(initialState = false) {
    const { 0: state , 1: setState  } = useState(initialState);
    const toggle = useCallback(()=>setState((state)=>!state), []);
    return [
        state,
        toggle
    ];
}
function useCookie(key) {
    const { 0: data , 1: setData  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const cookie = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .getCookie */ .ej)(key);
        setData(JSON.parse(cookie) || null);
    }, [
        key
    ]);
    const setCookieValue = (value)=>{
        setData(value);
        (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .setCookie */ .d8)(key, JSON.stringify(value));
    };
    return [
        data,
        setCookieValue
    ];
}


/***/ })

};
;