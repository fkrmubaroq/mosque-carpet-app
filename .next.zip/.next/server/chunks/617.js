"use strict";
exports.id = 617;
exports.ids = [617];
exports.modules = {

/***/ 7033:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ToolboxHero)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_lu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8510);
/* harmony import */ var react_icons_lu__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_lu__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ItemBox__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3993);
/* harmony import */ var _ModalToolboxFooter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5209);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ModalToolboxFooter__WEBPACK_IMPORTED_MODULE_5__]);
_ModalToolboxFooter__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const initModal = Object.freeze({
    show: false
});
function ToolboxHero({ className , data , onUpdateContent  }) {
    const { 0: modal , 1: setModal  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(initModal);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            modal.show && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalToolboxFooter__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                title: "Ganti Menu link",
                data: modal === null || modal === void 0 ? void 0 : modal.data,
                show: modal.show,
                onHide: ()=>setModal(initModal),
                verticallyCentered: true,
                className: "w-[450px]",
                onUpdateContent: (form)=>{
                    onUpdateContent(form);
                    setModal(initModal);
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("absolute -right-8 top-0 z-20", className),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "bg-primary h-9 hover:bg-primary-hover shadow-lg group rounded-r-md flex gap-x-2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ItemBox__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_lu__WEBPACK_IMPORTED_MODULE_3__.LuPencil, {
                            color: "white",
                            size: 17
                        }),
                        text: "",
                        onClick: ()=>{
                            setModal({
                                show: true,
                                data
                            });
                        }
                    })
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 617:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2470);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6563);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_contenteditable__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5452);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_rx__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _features_sections_Fragment_Toolbox_ToolboxHero__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7033);
/* harmony import */ var _features_sections_Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7240);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_features_sections_Fragment_Toolbox_ToolboxHero__WEBPACK_IMPORTED_MODULE_10__, _features_sections_Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_11__]);
([_features_sections_Fragment_Toolbox_ToolboxHero__WEBPACK_IMPORTED_MODULE_10__, _features_sections_Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const Portal = next_dynamic__WEBPACK_IMPORTED_MODULE_3___default()(null, {
    loadableGenerated: {
        modules: [
            "../components/layout/Header.jsx -> " + "@/components/ui/portal"
        ]
    },
    ssr: false
});
function Header({ noTransparent , hiddenMenu , content , edit , mobile , menus , onUpdateContent , onUpdateLogo  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("absolute left-0 right-0 z-50 px-3 lg:px-0 ", {
            "bg-white shadow-md": noTransparent,
            "text-white": !noTransparent,
            "flex items-center h-16 !fixed": hiddenMenu
        }),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex items-center justify-between", _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .CONTAINER_LP */ .oc, {
                "mt-4": !noTransparent,
                "!mx-0": hiddenMenu
            }),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex items-center justify-center gap-x-3 cursor-pointer"),
                    onClick: ()=>next_router__WEBPACK_IMPORTED_MODULE_5___default().push("/"),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex ", {
                                "group section-mode-edit": edit
                            }),
                            children: [
                                edit && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_features_sections_Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                    noText: true,
                                    value: content === null || content === void 0 ? void 0 : content.logo,
                                    name: "logo",
                                    onUpdateContent: onUpdateLogo,
                                    className: "group-hover:block hidden"
                                }),
                                (content === null || content === void 0 ? void 0 : content.logo) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    src: noTransparent ? "/img/logo-black_180x180.png" : content.logo,
                                    width: "36",
                                    height: "36",
                                    alt: ""
                                })
                            ]
                        }),
                        edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_7___default()), {
                            className: "text-lg text-white section-mode-edit",
                            tagName: "span",
                            html: (content === null || content === void 0 ? void 0 : content.logo_text) || "-",
                            onChange: (e)=>onUpdateLogo("logo_text", e.target.value)
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: (content === null || content === void 0 ? void 0 : content.logo_text) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("text-lg"),
                                children: content.logo_text
                            })
                        })
                    ]
                }),
                mobile.mobileMd || mobile.mobileSm ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MobileNavigationHeader, {
                    edit: edit,
                    menus: menus,
                    content: content
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavigationHeader, {
                    hiddenMenu: hiddenMenu,
                    noTransparent: noTransparent,
                    edit: edit,
                    menus: menus,
                    onUpdateContent: onUpdateContent
                })
            ]
        })
    });
}
function NavigationHeader({ hiddenMenu , noTransparent , onUpdateContent , edit =false , menus  }) {
    if (hiddenMenu) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex h-16 list-none items-center justify-center gap-x-5 text-lg font-light tracking-wide ", {
            "text-white": !noTransparent
        }),
        children: menus.map((item, key)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("cursor-pointer h-10 flex items-center px-2"),
                onClick: (e)=>{
                    if (item.link && !edit) {
                        next_router__WEBPACK_IMPORTED_MODULE_5___default().push(item.link);
                    }
                },
                children: edit ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "relative group",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_7___default()), {
                            className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("section-mode-edit", {
                                "w-5": !item.text
                            }),
                            html: item.text,
                            onChange: (e)=>{
                                onUpdateContent({
                                    index: key,
                                    value: e.target.value
                                });
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_features_sections_Fragment_Toolbox_ToolboxHero__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            data: item,
                            className: "group-hover:block hidden peer-focus:block",
                            onUpdateContent: (data)=>onUpdateContent({
                                    index: key,
                                    value: data
                                })
                        })
                    ]
                }) : item.text
            }, key))
    });
}
function MobileNavigationHeader({ menus , content  }) {
    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-11 w-11 flex justify-center items-center cursor-pointer",
                onClick: ()=>setIsOpen(true),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_rx__WEBPACK_IMPORTED_MODULE_9__.RxHamburgerMenu, {
                    color: "white",
                    size: 30
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Portal, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("inset-0 bg-black fixed z-30 opacity-40", {
                            "hidden": !isOpen
                        }),
                        onClick: ()=>setIsOpen(false)
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("absolute left-0 right-0 bg-white p-5 transition-all duration-300 z-50", {
                            "-top-[1000px]": !isOpen,
                            "top-0": isOpen
                        }),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "absolute right-6 top-5 cursor-pointer flex h-8 w-8 justify-center text-lg text-black",
                                onClick: ()=>setIsOpen(false),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_8__.AiOutlineClose, {
                                    size: 25
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col items-center justify-center gap-y-5",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col items-center gap-y-1",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                src: "/img/logo-black.png",
                                                width: "50",
                                                height: "50",
                                                alt: ""
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-lg font-semibold tracking-wide text-black",
                                                children: content === null || content === void 0 ? void 0 : content.logo_text
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mb-6 flex flex-col gap-y-8",
                                        children: menus.map((item, key)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "flex justify-center",
                                                onClick: ()=>{
                                                    if (item.link) {
                                                        next_router__WEBPACK_IMPORTED_MODULE_5___default().push(item.link);
                                                        setIsOpen(false);
                                                    }
                                                },
                                                children: item.text
                                            }, key))
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;