"use strict";
exports.id = 4991;
exports.ids = [4991];
exports.modules = {

/***/ 4991:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Vr": () => (/* binding */ getArticleById),
/* harmony export */   "Xc": () => (/* binding */ updateArticle),
/* harmony export */   "fq": () => (/* binding */ getArticle),
/* harmony export */   "jX": () => (/* binding */ deleteArticle),
/* harmony export */   "tu": () => (/* binding */ createArticle),
/* harmony export */   "vX": () => (/* binding */ getArticleBySlug)
/* harmony export */ });
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9254);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(873);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_0__]);
___WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function getArticle(params) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)("article", {
        params
    });
}
function createArticle(payload) {
    const formPayload = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .objectIntoFormData */ .rW)(payload);
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .postMethod */ .lx)("article", formPayload);
}
function updateArticle(id, payload) {
    const formPayload = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .objectIntoFormData */ .rW)(payload);
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .putMethod */ .yu)(`article/${id}`, formPayload);
}
function getArticleById(id) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)(`article/${id}`);
}
function getArticleBySlug(slug) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)(`article/slug/${slug}`);
}
function deleteArticle(id) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .deleteMethod */ .SR)(`article/${id}`);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;