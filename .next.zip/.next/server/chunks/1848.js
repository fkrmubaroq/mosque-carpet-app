"use strict";
exports.id = 1848;
exports.ids = [1848];
exports.modules = {

/***/ 2390:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ModalContactLink)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1257);
/* harmony import */ var _components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3768);
/* harmony import */ var _components_ui_form_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3516);
/* harmony import */ var _components_ui_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7912);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(49);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__, _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__]);
([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__, _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function ModalContactLink({ show , onHide , data , onUpdateContent  }) {
    const { 0: currentValue , 1: setCurrentValue  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(data);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_modal__WEBPACK_IMPORTED_MODULE_4__/* .Modal */ .u_, {
        verticallyCentered: true,
        className: "w-[450px]",
        onHide: onHide,
        show: show,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_modal__WEBPACK_IMPORTED_MODULE_4__/* .ModalHeader */ .xB, {
                onHide: onHide,
                children: "Ganti Link Kontak"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_modal__WEBPACK_IMPORTED_MODULE_4__/* .ModalBody */ .fe, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container_ContainerInput__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_5__.Label, {
                                children: "Link Kontak"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_3__/* .Input */ .I, {
                                value: currentValue,
                                placeholder: "Masukkan Contact Lonk",
                                onChange: (e)=>setCurrentValue(e.target.value)
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_1__/* .Button */ .z, {
                        className: "w-full mt-3",
                        onClick: ()=>{
                            onUpdateContent("contact_link", currentValue);
                        },
                        children: "Simpan"
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5613:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SectionTitle)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6563);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_contenteditable__WEBPACK_IMPORTED_MODULE_2__);



function SectionTitle({ context , title , classNameContext , onUpdateContent , edit  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col gap-y-4",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_2___default()), {
                    html: context,
                    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("inline border-b border-b-green-600 font-cinzel tracking-wide", "section-mode-edit", classNameContext),
                    onChange: (e)=>onUpdateContent("heading", e.currentTarget.textContent)
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("inline border-b border-b-green-600 font-cinzel tracking-wide", classNameContext),
                    children: context
                })
            }),
            edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_2___default()), {
                html: title,
                className: "mb-3 font-cinzel text-3xl font-medium section-mode-edit",
                onChange: (e)=>onUpdateContent("title", e.currentTarget.textContent)
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mb-3 font-cinzel text-3xl font-medium",
                children: title
            })
        ]
    });
}


/***/ }),

/***/ 9432:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2470);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6563);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_contenteditable__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Fragment_SectionTitle__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5613);
/* harmony import */ var _Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7240);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_7__]);
_Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








function SectionAboutUsMemo({ section , edit , onUpdateContent  }) {
    const content = (section === null || section === void 0 ? void 0 : section.content) || {};
    const onUpdate = (name, value)=>{
        onUpdateContent({
            ...section,
            content: {
                ...section.content,
                [name]: value
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        id: "section_about_us",
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("mb-16 flex flex-col items-center gap-x-3 pt-20 lg:flex-row", _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .MARGIN_EACH_SECTION */ .aH),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "lg:pr-40",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Fragment_SectionTitle__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        context: (content === null || content === void 0 ? void 0 : content.heading) || "",
                        title: (content === null || content === void 0 ? void 0 : content.title) || "",
                        onUpdateContent: onUpdate,
                        edit: edit
                    }),
                    edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default()), {
                        html: content === null || content === void 0 ? void 0 : content.text,
                        className: "mb-5 font-poppins text-lg tracking-wide text-gray-500 lg:mb-0 section-mode-edit",
                        onChange: (e)=>onUpdate("text", e.currentTarget.textContent)
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mb-5 font-poppins text-lg tracking-wide text-gray-500 lg:mb-0",
                        children: (content === null || content === void 0 ? void 0 : content.text) || ""
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative shrink-0 flex justify-center w-full lg:w-[500px] group ",
                children: [
                    edit && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        value: content.image,
                        name: "image",
                        onUpdateContent: onUpdate,
                        className: "group-hover:block hidden"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()({
                            "section-mode-edit p-1": edit
                        }),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            className: "rounded-lg",
                            src: (content === null || content === void 0 ? void 0 : content.image) || _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .placeholderImage */ .jM,
                            width: "450",
                            height: "300",
                            alt: ""
                        })
                    })
                ]
            })
        ]
    });
}
const SectionAboutUs = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_4__.memo)(SectionAboutUsMemo);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionAboutUs);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1872:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SectionArticles)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1257);
/* harmony import */ var _lib_api_articles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4991);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2470);
/* harmony import */ var _lib_queryKeys__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9067);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(873);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9752);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var swiper_modules__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2184);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3015);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__, _lib_api_articles__WEBPACK_IMPORTED_MODULE_2__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_6__, swiper_modules__WEBPACK_IMPORTED_MODULE_13__, swiper_react__WEBPACK_IMPORTED_MODULE_14__]);
([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__, _lib_api_articles__WEBPACK_IMPORTED_MODULE_2__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_6__, swiper_modules__WEBPACK_IMPORTED_MODULE_13__, swiper_react__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const newsItems = [
    {
        image: "/img/news/news-1.webp",
        title: "A New Destination for kitchen & cabinet, Jakarta",
        createdAt: "2023-10-11",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"
    },
    {
        image: "/img/news/news-2.webp",
        title: "The Opening of MODULO",
        createdAt: "2023-10-12",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"
    },
    {
        image: "/img/news/news-3.webp",
        title: "Soft Launching Masjid Al-Jabar",
        createdAt: "2023-10-12",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"
    }, 
];
function SectionArticles({ mobile , edit , section  }) {
    const getSlidePerPreviewByScreen = ()=>{
        if (mobile === null || mobile === void 0 ? void 0 : mobile.mobileSm) return 1;
        if (mobile === null || mobile === void 0 ? void 0 : mobile.mobileMd) return 2;
        return 3;
    };
    const { data: articles  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_6__.useQuery)({
        queryKey: _lib_queryKeys__WEBPACK_IMPORTED_MODULE_4__/* .landingPageQuery.getArticles */ .i2.getArticles,
        queryFn: async ()=>{
            const params = {};
            const response = await (0,_lib_api_articles__WEBPACK_IMPORTED_MODULE_2__/* .getArticle */ .fq)(params);
            return response.data.data || [];
        }
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: classnames__WEBPACK_IMPORTED_MODULE_7___default()(_lib_constant__WEBPACK_IMPORTED_MODULE_3__/* .MARGIN_EACH_SECTION */ .aH),
        id: "section_articles",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "inline border-b text-lg border-b-green-600 font-cinzel tracking-wide",
                        children: "Artikel"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mb-3 font-cinzel text-3xl font-medium",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_1__/* .Button */ .z, {
                            className: "flex items-center justify-center gap-x-2 rounded-none !p-6",
                            onClick: ()=>!edit && next_router__WEBPACK_IMPORTED_MODULE_11___default().push("/berita"),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "mt-0.5",
                                    children: "VIEW MORE"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_12__.AiFillCaretRight, {})
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex gap-x-8",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_14__.Swiper, {
                    slidesPerView: getSlidePerPreviewByScreen(),
                    spaceBetween: 20,
                    navigation: true,
                    loop: true,
                    modules: [
                        swiper_modules__WEBPACK_IMPORTED_MODULE_13__.Navigation
                    ],
                    className: "swipper-category",
                    children: articles === null || articles === void 0 ? void 0 : articles.map((item, key)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_14__.SwiperSlide, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CardNewItem, {
                                data: item,
                                edit: edit
                            })
                        }, key))
                })
            })
        ]
    });
}
function CardNewItem({ data , edit  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "group shadow-md flex flex-col gap-y-3 transition-all duration-500 hover:scale-105 ease-in-out hover:bg-primary",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "shrink-0 relative h-[300px]",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_9___default()), {
                    src: (data === null || data === void 0 ? void 0 : data.thumbnail) ? (0,_lib_utils__WEBPACK_IMPORTED_MODULE_5__/* .mediaPath */ .hf)("articles-thumbnail", data.thumbnail) : _lib_constant__WEBPACK_IMPORTED_MODULE_3__/* .placeholderImage */ .jM,
                    layout: "fill",
                    className: "object-cover"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col gap-y-2 px-4 pb-8",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_10___default()), {
                        href: `${edit ? "#" : `/${(0,_lib_utils__WEBPACK_IMPORTED_MODULE_5__/* .slugString */ .Jg)(data === null || data === void 0 ? void 0 : data.title)}`}`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            className: "mt-2 cursor-pointer line-clamp-2 text-xl font-medium hover:underline tracking-wider text-gray-700 group-hover:text-white",
                            children: data.title
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-sm tracking-wide text-gray-400 group-hover:text-white",
                        children: dayjs__WEBPACK_IMPORTED_MODULE_8___default()(new Date(data.created_at)).format("MMMM DD, YYYY HH:mm WIB")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "tracking-wide text-justify line-clamp-3 text-slate-600 group-hover:text-white",
                        children: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_5__/* .strippedStrings */ .nz)(data.content || "")
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9827:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SectionContactUs)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1257);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2470);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6563);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_contenteditable__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Fragment_ModalContactLink__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2390);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__, _Fragment_ModalContactLink__WEBPACK_IMPORTED_MODULE_7__]);
([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__, _Fragment_ModalContactLink__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const initModal = Object.freeze({
    show: false
});
function SectionContactUs({ setting , mobile =false , edit , section , onUpdateContent  }) {
    const content = (section === null || section === void 0 ? void 0 : section.content) || {};
    const { 0: modal , 1: setModal  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(initModal);
    const onUpdate = (name, value)=>{
        onUpdateContent({
            ...section,
            content: {
                ...section.content,
                [name]: value
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            edit && modal.show && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Fragment_ModalContactLink__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                data: modal.data,
                show: modal.show,
                onHide: ()=>setModal(initModal),
                onUpdateContent: (name, value)=>{
                    onUpdate(name, value);
                    setModal(initModal);
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("h-[440px]", _lib_constant__WEBPACK_IMPORTED_MODULE_2__/* .MARGIN_EACH_SECTION */ .aH),
                id: "section_contact_us",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "absolute left-0 h-[440px] w-full bg-bottom object-cover",
                    style: {
                        backgroundImage: `url('/img/img-contact-us.webp')`,
                        backgroundRepeat: "no-repeat",
                        backgroundSize: `100% ${mobile ? "100%" : ""}`
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "absolute inset-0 z-0",
                            style: {
                                backgroundImage: `linear-gradient(${(mobile === null || mobile === void 0 ? void 0 : mobile.mobileMd) ? "60deg" : "260deg"}, #000000 0%, #00000000 100%)`
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("relative z-10 flex h-full items-center justify-end", _lib_constant__WEBPACK_IMPORTED_MODULE_2__/* .CONTAINER_LP */ .oc),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "px-4 lg:px-0",
                                children: [
                                    edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        className: "mb-4 font-cinzel text-2xl leading-normal text-white lg:max-w-[700px] lg:text-5xl section-mode-edit",
                                        html: content === null || content === void 0 ? void 0 : content.title,
                                        onChange: (e)=>onUpdate("title", e.currentTarget.textContent)
                                    }) : (content === null || content === void 0 ? void 0 : content.title) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mb-4 font-cinzel text-2xl leading-normal text-white lg:max-w-[700px] lg:text-5xl",
                                        children: content.title
                                    }),
                                    edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        tagName: "span",
                                        className: "text-lg tracking-wider text-white section-mode-edit",
                                        html: content === null || content === void 0 ? void 0 : content.text,
                                        onChange: (e)=>onUpdate("text", e.currentTarget.textContent)
                                    }) : (content === null || content === void 0 ? void 0 : content.text) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-lg tracking-wider text-white",
                                        children: content === null || content === void 0 ? void 0 : content.text
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mt-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_1__/* .Button */ .z, {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("flex font-cinzel text-lg items-center justify-center gap-x-2 !rounded-none !p-6 text-white"),
                                            onClick: ()=>{
                                                if (!edit && (setting === null || setting === void 0 ? void 0 : setting.no_wa)) {
                                                    window.open(`https://wa.me/${setting.no_wa}`);
                                                    return;
                                                }
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__.AiOutlineWhatsApp, {
                                                    size: mobile.mobileMd ? 18 : 20
                                                }),
                                                edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                    className: "section-mode-edit",
                                                    html: content === null || content === void 0 ? void 0 : content.button_primary,
                                                    tagName: "span",
                                                    onChange: (e)=>{
                                                        const value = e.currentTarget.textContent;
                                                        onUpdateContent({
                                                            ...section,
                                                            content: {
                                                                ...section.content,
                                                                button_primary: value
                                                            }
                                                        });
                                                    }
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: (content === null || content === void 0 ? void 0 : content.button_primary) || ""
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5817:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SectionHero)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_layout_Header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(617);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1257);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2470);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6563);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_contenteditable__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7240);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout_Header__WEBPACK_IMPORTED_MODULE_1__, _components_ui_button__WEBPACK_IMPORTED_MODULE_2__, _Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_6__]);
([_components_layout_Header__WEBPACK_IMPORTED_MODULE_1__, _components_ui_button__WEBPACK_IMPORTED_MODULE_2__, _Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function HeroCard({ title , text , footer , edit , onUpdateContent  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "rounded-lg px-12 py-10 text-white lg:w-[500px] sm:w-[400px] w-full",
        style: {
            background: "rgba(0,0,0,0.7)"
        },
        children: [
            edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default()), {
                tagName: "h1",
                className: "mb-4 text-xl lg:text-3xl font-cinzel text-primary section-mode-edit outline-none",
                html: title,
                onChange: (e)=>onUpdateContent("title", e.currentTarget.textContent)
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mb-4 text-xl lg:text-3xl font-cinzel text-primary",
                children: title
            }),
            edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default()), {
                tagName: "div",
                className: "font-poppins text-sm lg:text-md font-light tracking-wide section-mode-edit outline-none",
                html: text,
                onChange: (e)=>onUpdateContent("text", e.currentTarget.textContent)
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "font-poppins text-sm lg:text-md font-light tracking-wide",
                children: text
            }),
            footer
        ]
    });
}
function SectionHero({ edit , mobile =false , section , onUpdateContent  }) {
    var ref, ref1;
    const content = (section === null || section === void 0 ? void 0 : section.content) || {};
    const onUpdateMenu = ({ index , value  })=>{
        const dataMenu = structuredClone(content.menus);
        let data = {
            ...dataMenu[index],
            text: value
        };
        if (typeof value === "object" && !Array.isArray(value)) {
            data = value;
        }
        dataMenu.splice(index, 1, data);
        onUpdateContent({
            ...section,
            content: {
                ...section.content,
                menus: dataMenu
            }
        });
    };
    const onUpdateImage = (name, value)=>onUpdateContent({
            ...section,
            content: {
                ...section.content,
                [name]: value
            }
        });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "h-[600px] w-full lg:mb-20 lg:h-[700px]",
        id: "section_hero",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_Header__WEBPACK_IMPORTED_MODULE_1__/* .Header */ .h, {
                edit: edit,
                mobile: mobile,
                content: content,
                menus: (content === null || content === void 0 ? void 0 : content.menus) || [],
                onUpdateContent: onUpdateMenu,
                onUpdateLogo: onUpdateImage
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("absolute h-[600px] group w-full bg-black bg-center object-cover lg:h-[700px]"),
                style: {
                    backgroundImage: `url('${content === null || content === void 0 ? void 0 : content.banner}')`,
                    backgroundRepeat: "no-repeat",
                    backgroundSize: `100% ${(mobile === null || mobile === void 0 ? void 0 : mobile.mobileSm) ? "100%" : ""}`
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("pt-28 lg:pt-48 relative", _lib_constant__WEBPACK_IMPORTED_MODULE_3__/* .CONTAINER_LP */ .oc),
                    children: [
                        edit && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Fragment_Toolbox_ToolboxImage__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            value: content === null || content === void 0 ? void 0 : content.banner,
                            name: "banner",
                            position: "bottomRight",
                            onUpdateContent: onUpdateImage,
                            text: "Ganti Banner",
                            className: "-bottom-20 !-right-3 cursor-pointer w-[130px]"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "absolute inset-0",
                            style: {
                                backgroundImage: "linear-gradient(180deg, #000000 0%, #00000000 50%)"
                            }
                        }),
                        edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default()), {
                            html: (content === null || content === void 0 ? void 0 : content.tagline) || "",
                            tagName: "h1",
                            className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("lg:mb-24 lg:w-full lg:max-w-[750px] lg:px-0 lg:text-2xl", "text-xl font-light tracking-wider text-white", "relative mx-auto mb-6 max-w-[450px] px-3 text-center font-poppins ", "section-mode-edit"),
                            onChange: (e)=>{
                                const value = e.currentTarget.textContent;
                                onUpdateContent({
                                    ...section,
                                    content: {
                                        ...section.content,
                                        tagline: value
                                    }
                                });
                            }
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("lg:mb-24 lg:w-full lg:max-w-[750px] lg:px-0 lg:text-2xl", "text-xl font-light tracking-wider text-white", "relative mx-auto mb-6 max-w-[450px] px-3 text-center font-poppins "),
                            children: (content === null || content === void 0 ? void 0 : content.tagline) || ""
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "relative mx-4 flex gap-x-5",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HeroCard, {
                                edit: edit,
                                onUpdateContent: (name, value)=>{
                                    onUpdateContent({
                                        ...section,
                                        content: {
                                            ...section.content,
                                            sub_tagline: {
                                                ...section.content.sub_tagline,
                                                [name]: value
                                            }
                                        }
                                    });
                                },
                                title: (content === null || content === void 0 ? void 0 : (ref = content.sub_tagline) === null || ref === void 0 ? void 0 : ref.title) || "",
                                text: (content === null || content === void 0 ? void 0 : (ref1 = content.sub_tagline) === null || ref1 === void 0 ? void 0 : ref1.text) || "",
                                footer: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "mt-5 flex flex-col gap-x-4 gap-y-4 lg:flex-row lg:gap-y-0",
                                    children: [
                                        edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            html: content === null || content === void 0 ? void 0 : content.button_primary,
                                            tagName: "div",
                                            className: "!rounded-none !px-8 section-mode-edit !py-3 font-cinzel bg-primary",
                                            onChange: (e)=>{
                                                const value = e.currentTarget.textContent;
                                                onUpdateContent({
                                                    ...section,
                                                    content: {
                                                        ...section.content,
                                                        button_primary: value
                                                    }
                                                });
                                            }
                                        }) : (content === null || content === void 0 ? void 0 : content.button_primary) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .z, {
                                            className: "!rounded-none !px-10 !py-6 font-cinzel",
                                            children: (content === null || content === void 0 ? void 0 : content.button_primary) || ""
                                        }),
                                        edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            html: content === null || content === void 0 ? void 0 : content.button_secondary,
                                            tagName: "div",
                                            className: "!rounded-none !px-8 !py-3 border border-white section-mode-edit font-cinzel",
                                            onChange: (e)=>{
                                                const value = e.currentTarget.textContent;
                                                onUpdateContent({
                                                    ...section,
                                                    content: {
                                                        ...section.content,
                                                        button_secondary: value
                                                    }
                                                });
                                            }
                                        }) : (content === null || content === void 0 ? void 0 : content.button_secondary) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .z, {
                                            variant: "ghost",
                                            className: "!rounded-none border border-white hover:!text-black !px-10 !py-6 font-cinzel",
                                            children: (content === null || content === void 0 ? void 0 : content.button_secondary) || ""
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7781:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SectionMapAddress)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_form_Textarea__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3008);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2470);
/* harmony import */ var html_react_parser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2905);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6563);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_contenteditable__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([html_react_parser__WEBPACK_IMPORTED_MODULE_3__]);
html_react_parser__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function SectionMapAddress({ edit , section , onUpdateContent  }) {
    const content = (section === null || section === void 0 ? void 0 : section.content) || {};
    const onUpdate = (name, value)=>{
        onUpdateContent({
            ...section,
            content: {
                ...section.content,
                [name]: value
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: _lib_constant__WEBPACK_IMPORTED_MODULE_2__/* .MARGIN_EACH_SECTION */ .aH,
        id: "section_map_address",
        children: [
            edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_4___default()), {
                html: (content === null || content === void 0 ? void 0 : content.heading) || "",
                tagName: "div",
                className: "inline-flex mx-auto border-b text-lg border-b-green-600 font-cinzel tracking-wide section-mode-edit",
                onChange: (e)=>{
                    const value = e.currentTarget.textContent;
                    onUpdate("heading", value);
                }
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "inline-flex mx-auto border-b text-lg border-b-green-600 font-cinzel tracking-wide",
                children: (content === null || content === void 0 ? void 0 : content.heading) || ""
            }),
            edit && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_Textarea__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                autoSize: true,
                className: "mt-3",
                placeholder: "Embed Alamat",
                value: (content === null || content === void 0 ? void 0 : content.embed_map) || "",
                name: "embed_map",
                onChange: (e)=>onUpdate("embed_map", e.target.value)
            }),
            (content === null || content === void 0 ? void 0 : content.embed_map) && content.embed_map.includes("<iframe") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-5 flex justify-center",
                children: (0,html_react_parser__WEBPACK_IMPORTED_MODULE_3__["default"])(content.embed_map)
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2143:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SectionOurProduct)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1257);
/* harmony import */ var _lib_api_category__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9743);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2470);
/* harmony import */ var _lib_queryKeys__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9067);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(873);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9752);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var swiper_modules__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2184);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3015);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__, _lib_api_category__WEBPACK_IMPORTED_MODULE_2__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_6__, swiper_modules__WEBPACK_IMPORTED_MODULE_10__, swiper_react__WEBPACK_IMPORTED_MODULE_11__]);
([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__, _lib_api_category__WEBPACK_IMPORTED_MODULE_2__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_6__, swiper_modules__WEBPACK_IMPORTED_MODULE_10__, swiper_react__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














function SectionOurProduct({ edit , mobile  }) {
    var ref;
    const getSlidePerPreviewByScreen = ()=>{
        if (mobile === null || mobile === void 0 ? void 0 : mobile.mobileSm) return 1;
        if (mobile === null || mobile === void 0 ? void 0 : mobile.mobileMd) return 2;
        return 4;
    };
    const { data: categories  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_6__.useQuery)({
        queryKey: _lib_queryKeys__WEBPACK_IMPORTED_MODULE_4__/* .landingPageQuery.getCategories */ .i2.getCategories,
        queryFn: async ()=>{
            const params = {};
            const response = await (0,_lib_api_category__WEBPACK_IMPORTED_MODULE_2__/* .getCategory */ .n3)(params);
            if (response.status !== 200) throw new Error();
            return response.data || [];
        }
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: _lib_constant__WEBPACK_IMPORTED_MODULE_3__/* .MARGIN_EACH_SECTION */ .aH,
        id: "section_categories",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "inline border-b text-lg border-b-green-600 font-cinzel tracking-wide",
                        children: "Our Products"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mb-3 font-cinzel text-3xl font-medium",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_1__/* .Button */ .z, {
                            className: "flex items-center justify-center gap-x-2 rounded-none !p-6",
                            onClick: ()=>!edit && next_router__WEBPACK_IMPORTED_MODULE_8___default().push("/collections"),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "mt-0.5",
                                    children: "VIEW MORE"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_9__.AiFillCaretRight, {})
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_11__.Swiper, {
                slidesPerView: getSlidePerPreviewByScreen(),
                spaceBetween: 20,
                navigation: true,
                loop: true,
                modules: [
                    swiper_modules__WEBPACK_IMPORTED_MODULE_10__.Navigation
                ],
                className: "swipper-category",
                children: categories === null || categories === void 0 ? void 0 : (ref = categories.data) === null || ref === void 0 ? void 0 : ref.map((item, key)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_11__.SwiperSlide, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PreviewData, {
                            data: item,
                            edit: edit
                        })
                    }, key))
            })
        ]
    });
}
function PreviewData({ data , edit  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        onClick: ()=>{
            if (edit) return;
            const slug = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_5__/* .slugString */ .Jg)(data.category_name);
            next_router__WEBPACK_IMPORTED_MODULE_8___default().push(`/collections/${slug}`);
        },
        className: "group w-full mb-2 flex cursor-pointer flex-col shadow transition-all duration-500 ease-in-out hover:scale-105 hover:bg-primary",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "shrink-0 relative h-[200px]",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                    src: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_5__/* .mediaPath */ .hf)("categories", data.image),
                    alt: "",
                    layout: "fill",
                    className: "object-cover"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "pb-5 z-[] pt-4 text-center font-poppins tracking-wider text-slate-700 group-hover:bg-primary group-hover:text-white",
                children: data.category_name
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5385:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2470);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6563);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_contenteditable__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_6__);







function SectionVisionMisionMemo({ section , edit , onUpdateContent , sectionName  }) {
    var ref, ref1, ref2, ref3;
    const content = (section === null || section === void 0 ? void 0 : section.content) || {};
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        id: "section_vision_mision",
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex flex-col gap-x-12 lg:flex-row", _lib_constant__WEBPACK_IMPORTED_MODULE_1__/* .MARGIN_EACH_SECTION */ .aH),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CardContent, {
                edit: edit,
                className: "w-full bg-secondary text-white",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__.AiOutlineAim, {
                    color: "white",
                    size: 50
                }),
                title: (content === null || content === void 0 ? void 0 : (ref = content.vision) === null || ref === void 0 ? void 0 : ref.title) || "",
                description: content === null || content === void 0 ? void 0 : (ref1 = content.vision) === null || ref1 === void 0 ? void 0 : ref1.text,
                onUpdateContent: (name, value)=>onUpdateContent({
                        ...section,
                        content: {
                            ...section.content,
                            vision: {
                                ...section.content.vision,
                                [name]: value
                            }
                        }
                    })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CardContent, {
                textGray: true,
                edit: edit,
                className: "w-full",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_6__.FiTrendingUp, {
                    size: 50,
                    color: "#eab308"
                }),
                title: (content === null || content === void 0 ? void 0 : (ref2 = content.mision) === null || ref2 === void 0 ? void 0 : ref2.title) || "",
                onUpdateContent: (name, value)=>onUpdateContent({
                        ...section,
                        content: {
                            ...section.content,
                            mision: {
                                ...section.content.mision,
                                [name]: value
                            }
                        }
                    }),
                description: content === null || content === void 0 ? void 0 : (ref3 = content.mision) === null || ref3 === void 0 ? void 0 : ref3.text
            })
        ]
    });
}
function CardContent({ textGray , className , icon , title , description , edit , onUpdateContent  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex flex-col gap-y-2 py-7 px-8", className),
        children: [
            icon && icon,
            edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_4___default()), {
                html: title,
                className: "text-2xl font-cinzel section-mode-edit",
                onChange: (e)=>onUpdateContent("title", e.currentTarget.textContent)
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "text-2xl font-cinzel",
                children: title
            }),
            edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_4___default()), {
                html: description,
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("font-poppins tracking-wide opacity-90 leading-7  section-mode-edit", {
                    "text-gray-600": textGray
                }),
                onChange: (e)=>onUpdateContent("text", e.currentTarget.textContent)
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("font-poppins tracking-wide opacity-90 leading-7", {
                    "text-gray-600": textGray
                }),
                children: description
            })
        ]
    });
}
const SectionVisionMision = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_3__.memo)(SectionVisionMisionMemo);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionVisionMision);


/***/ }),

/***/ 9780:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1257);
/* harmony import */ var _lib_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2470);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6563);
/* harmony import */ var react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_contenteditable__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_fa6__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8514);
/* harmony import */ var react_icons_fa6__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa6__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _Fragment_SectionTitle__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5613);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_button__WEBPACK_IMPORTED_MODULE_1__]);
_components_ui_button__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const icons = [
    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa6__WEBPACK_IMPORTED_MODULE_7__.FaRegLightbulb, {
        size: 50,
        color: "#15803d"
    }),
    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_8__.FiThumbsUp, {
        size: 50,
        color: "#15803d"
    })
];
function SectionWhyChooseUsMemo({ section , edit , onUpdateContent , sectionName  }) {
    var ref;
    const content = (section === null || section === void 0 ? void 0 : section.content) || {};
    const onUpdateItem = (index, value)=>{
        const text = structuredClone(section.content.text);
        text.splice(index, 1, value);
        onUpdateContent({
            ...section,
            content: {
                ...section.content,
                text: text
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-1 w-full border-t border-dashed"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                id: "section_why_choose_us",
                className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("flex items-center gap-x-3 pt-20", _lib_constant__WEBPACK_IMPORTED_MODULE_2__/* .MARGIN_EACH_SECTION */ .aH),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Fragment_SectionTitle__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            edit: edit,
                            onUpdateContent: (name, value)=>onUpdateContent({
                                    ...section,
                                    content: {
                                        ...section.content,
                                        [name]: value
                                    }
                                }),
                            classNameContext: "border-b-primary",
                            context: (content === null || content === void 0 ? void 0 : content.heading) || "",
                            title: (content === null || content === void 0 ? void 0 : content.title) || ""
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col items-center gap-x-10 lg:flex-row lg:gap-y-0 gap-y-5 ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex flex-col items-center lg:gap-x-24 lg:flex-row lg:gap-y-0 gap-y-7",
                                    children: content === null || content === void 0 ? void 0 : (ref = content.text) === null || ref === void 0 ? void 0 : ref.map((item, key)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ItemChooseUs, {
                                            edit: edit,
                                            onUpdateContent: (value)=>onUpdateItem(key, value),
                                            className: "w-full",
                                            icon: icons[key],
                                            description: item
                                        }, key))
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex w-2/3 justify-center",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_1__/* .Button */ .z, {
                                        className: "flex items-center justify-center gap-x-2 !rounded-none !p-6",
                                        children: [
                                            edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                className: "section-mode-edit",
                                                html: content === null || content === void 0 ? void 0 : content.button_primary,
                                                tagName: "span",
                                                onChange: (e)=>{
                                                    const value = e.currentTarget.textContent;
                                                    onUpdateContent({
                                                        ...section,
                                                        content: {
                                                            ...section.content,
                                                            button_primary: value
                                                        }
                                                    });
                                                }
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: (content === null || content === void 0 ? void 0 : content.button_primary) || ""
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__.AiFillCaretRight, {})
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}
function ItemChooseUs({ icon , description , className , edit , onUpdateContent  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("flex items-center gap-x-7", className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "shrink-0 max-w-[425px]",
                children: icon
            }),
            edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_contenteditable__WEBPACK_IMPORTED_MODULE_5___default()), {
                className: "font-normal tracking-wide text-gray-700 section-mode-edit",
                tagName: "span",
                html: description,
                onChange: (e)=>onUpdateContent(e.currentTarget.textContent)
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "font-normal tracking-wide text-gray-700",
                children: description
            })
        ]
    });
}
const SectionWhyChooseUs = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_4__.memo)(SectionWhyChooseUsMemo);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionWhyChooseUs);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9743:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BD": () => (/* binding */ insertCategory),
/* harmony export */   "fj": () => (/* binding */ getCategoryBySlug),
/* harmony export */   "n3": () => (/* binding */ getCategory),
/* harmony export */   "uu": () => (/* binding */ deleteCategory),
/* harmony export */   "yr": () => (/* binding */ updateCategory)
/* harmony export */ });
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9254);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(873);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_0__]);
___WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function getCategory(params) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)("category", {
        params
    });
}
function insertCategory(payload) {
    const formPayload = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .objectIntoFormData */ .rW)(payload);
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .postMethod */ .lx)("category", formPayload);
}
function updateCategory(payload) {
    const formPayload = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .objectIntoFormData */ .rW)(payload);
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .putMethod */ .yu)("category", formPayload);
}
function deleteCategory(id) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .deleteMethod */ .SR)(`category/${id}`);
}
function getCategoryBySlug(slug) {
    return (0,___WEBPACK_IMPORTED_MODULE_0__/* .getMethod */ .lO)(`category/slug/${slug}`);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;