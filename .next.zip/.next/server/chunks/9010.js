"use strict";
exports.id = 9010;
exports.ids = [9010];
exports.modules = {

/***/ 9254:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K7": () => (/* binding */ patchMethod),
/* harmony export */   "SR": () => (/* binding */ deleteMethod),
/* harmony export */   "lO": () => (/* binding */ getMethod),
/* harmony export */   "lx": () => (/* binding */ postMethod),
/* harmony export */   "yu": () => (/* binding */ putMethod)
/* harmony export */ });
/* unused harmony export instance */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const baseURL = "http://localhost:3000/api";
const instance = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    withCredentials: true,
    baseURL,
    headers: {
        "Content-Type": "application/x-www-form-urlencoded"
    }
});
function getMethod(endpoint, config) {
    return instance.get(endpoint, config);
}
function postMethod(endpoint, payload, config) {
    return instance.post(endpoint, payload, config);
}
function putMethod(endpoint, payload, config) {
    return instance.put(endpoint, payload, config);
}
function patchMethod(endpoint, payload, config) {
    return instance.patch(endpoint, payload, config);
}
function deleteMethod(endpoint, config) {
    return instance.delete(endpoint, config);
}


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2470:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ce": () => (/* binding */ DIR_ACCESS_FILE),
/* harmony export */   "Gn": () => (/* binding */ MIME_TYPE_IMAGE),
/* harmony export */   "J3": () => (/* binding */ MIME_TYPE),
/* harmony export */   "aH": () => (/* binding */ MARGIN_EACH_SECTION),
/* harmony export */   "d6": () => (/* binding */ INIT_SECTIONS),
/* harmony export */   "ew": () => (/* binding */ OFFSET),
/* harmony export */   "jM": () => (/* binding */ placeholderImage),
/* harmony export */   "oc": () => (/* binding */ CONTAINER_LP)
/* harmony export */ });
/* unused harmony exports MIME_TYPE_VIDEO, EXPIRED_DAYS, BASE_DIR, DIR_FILE_UPLOAD, DIR_FILE_PRODUCTS, DIR_FILE_CATEGORY, DIR_FILE_THUMBNAIL */
const MIME_TYPE_VIDEO = {
    "video/mp4": "mp4",
    "video/webm": "webm",
    "video/ogg": "ogg",
    "video/quicktime": "mov"
};
const MIME_TYPE_IMAGE = {
    "image/gif": "gif",
    "image/jpeg": "jpeg",
    "image/jpg": "jpg",
    "image/png": "png",
    "image/svg+xml": "svg",
    "image/tiff": "tiff",
    "image/webp": "webp"
};
const MIME_TYPE = {
    ...MIME_TYPE_IMAGE,
    ...MIME_TYPE_VIDEO
};
const OFFSET = 20;
const EXPIRED_DAYS = (/* unused pure expression or super */ null && (60 * 60 * 24 * 30)); // 1 days
const BASE_DIR = "./files";
const DIR_FILE_UPLOAD = `${BASE_DIR}/upload`;
const DIR_FILE_PRODUCTS = `${BASE_DIR}/products`;
const DIR_FILE_CATEGORY = `${BASE_DIR}/categories`;
const DIR_FILE_THUMBNAIL = `${BASE_DIR}/articles-thumbnail`;
const DIR_ACCESS_FILE = `/api/files`;
const placeholderImage = `/img/placeholder.webp`;
const INIT_SECTIONS = [
    {
        "section_name": "section_hero",
        "content": {
            "logo": "http://localhost:3000/api/files/Sections/logo.png",
            "logo_text": "Al-Hijra",
            "tagline": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
            "sub_tagline": {
                "title": "Luxury at its finest",
                "text": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500sd"
            },
            "menus": [
                {
                    "menu": "",
                    "link": "",
                    "text": "About Us"
                },
                {
                    "menu": "",
                    "link": "",
                    "text": "Collections"
                },
                {
                    "menu": "",
                    "link": "",
                    "text": "Contact Us"
                },
                {
                    "menu": "",
                    "link": "",
                    "text": "Our Products"
                }
            ],
            "banner": "http://localhost:3000/api/files/Sections/banner.webp",
            "button_secondary": "View More",
            "button_primary": "Collection"
        },
        "position": 1
    },
    {
        "section_name": "section_about_us",
        "content": {
            "heading": "About Us",
            "title": "Lorem Ipsum",
            "text": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
            "image": "http://localhost:3000/api/files/Sections/category-4.jpg"
        },
        "position": 2
    },
    {
        "section_name": "section_vision_mision",
        "content": {
            "heading": "",
            "title": "",
            "vision": {
                "title": "Our Vision",
                "text": "To be a leading ‘One Stop Luxury Haven’ where we constantly enhance our products and services."
            },
            "mision": {
                "title": "Our Vision",
                "text": "Create value for our customers by offering relentless exceptional quality furnishings &amp; services."
            }
        },
        "position": 3
    },
    {
        "section_name": "section_why_choose_us",
        "content": {
            "heading": "Our Value",
            "title": "Why Choose US",
            "text": [
                "Create value for our customers by offering relentless exceptional quality furnishings",
                "Our designers are trained to help the customers realize their vision of their dream home."
            ],
            "button_primary": "OUR SERVICE"
        },
        "position": 4
    },
    {
        "section_name": "section_contact_us",
        "content": {
            "title": "Finding Finer Solution For Your Home?",
            "text": "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
            "button_primary": "Contact Now"
        },
        "position": 5
    },
    {
        "section_name": "section_footer",
        "content": {
            "logo_text": "AL-HIJRA",
            "tagline": "Ibadah Semakin nyaman",
            "contact": {
                "address": [
                    {
                        "link": "https://map",
                        "text": "Jln Saluyu Indah X No.9H"
                    }
                ],
                "phone_wa": {
                    "link": "https://map",
                    "text": "08886351120"
                },
                "email": {
                    "link": "https://map",
                    "text": "alhijracarpet@mail.com"
                }
            },
            "social_media": {
                "instagram": {
                    "link": "https://map",
                    "text": "Instagram"
                },
                "facebook": {
                    "link": "https://map",
                    "text": "Facebook"
                },
                "tiktok": {
                    "link": "https://map",
                    "text": "Tiktok"
                }
            },
            "logo": "http://localhost:3000/api/files/Sections/logo.png"
        },
        "position": 6
    },
    {
        "section_name": "section_articles",
        "content": {},
        "position": 7
    },
    {
        "section_name": "section_categories",
        "content": {},
        "position": 8
    }, 
];
const CONTAINER_LP = "padding-container xl:w-[1280px]";
const MARGIN_EACH_SECTION = "lg:mb-[100px] mb-16";


/***/ }),

/***/ 873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ds": () => (/* binding */ debounce),
/* harmony export */   "Iv": () => (/* binding */ getArticleTime),
/* harmony export */   "Jg": () => (/* binding */ slugString),
/* harmony export */   "Mz": () => (/* binding */ eraseCookie),
/* harmony export */   "d8": () => (/* binding */ setCookie),
/* harmony export */   "ej": () => (/* binding */ getCookie),
/* harmony export */   "gQ": () => (/* binding */ selectedFileName),
/* harmony export */   "hf": () => (/* binding */ mediaPath),
/* harmony export */   "ji": () => (/* binding */ downloadFileUrl),
/* harmony export */   "nz": () => (/* binding */ strippedStrings),
/* harmony export */   "oz": () => (/* binding */ getWord),
/* harmony export */   "rW": () => (/* binding */ objectIntoFormData),
/* harmony export */   "td": () => (/* binding */ formatBytes),
/* harmony export */   "uN": () => (/* binding */ convertObjToDataSelection),
/* harmony export */   "vQ": () => (/* binding */ copyToClipboard),
/* harmony export */   "xt": () => (/* binding */ formatNumberToPrice),
/* harmony export */   "xy": () => (/* binding */ handleDragZoneHover),
/* harmony export */   "zv": () => (/* binding */ checkResolutionImage)
/* harmony export */ });
/* unused harmony exports createThumbnailVideo, sleep, generateID, incomingRequest, fileIsExists, unlinkFile, createFile, setCursorPosition, getCookieName, isClient */
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2470);



function debounce(func, timeout = 300) {
    let timer;
    return (...args)=>{
        clearTimeout(timer);
        timer = setTimeout(()=>{
            func.apply(this, args);
        }, timeout);
    };
}
function convertObjToDataSelection(obj, swap = false) {
    return Object.keys(obj).map((key)=>({
            id: swap ? obj[key] : key,
            text: swap ? key : obj[key]
        }));
}
function checkResolutionImage(file) {
    return new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (e)=>{
            var ref, ref1;
            if (!((ref = e.target) === null || ref === void 0 ? void 0 : ref.result)) reject();
            const image = new Image();
            image.src = (ref1 = e.target) === null || ref1 === void 0 ? void 0 : ref1.result;
            image.onload = ()=>{
                resolve({
                    width: image.width,
                    height: image.height
                });
            };
        };
    });
}
function formatNumberToPrice(priceInt, delimiters = ".") {
    if (typeof priceInt !== "number" && typeof priceInt !== "string") return priceInt;
    return priceInt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, delimiters);
}
const createThumbnailVideo = (file, cb)=>{
    const video = document.createElement("video");
    video.src = URL.createObjectURL(file);
    video.addEventListener("loadeddata", ()=>{
        var ref;
        const canvas = document.createElement("canvas"); // create canvas element
        if (!canvas) return;
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        (ref = canvas.getContext("2d")) === null || ref === void 0 ? void 0 : ref.drawImage(video, 0, 0, canvas.width, canvas.height); // draw video frame on canvas
        const thumbnailVideo = canvas.toDataURL("image/jpeg"); // convert canvas to jpeg image URL
        cb(thumbnailVideo);
        URL.revokeObjectURL(video.src); // release object URL
    });
};
const handleDragZoneHover = (e, hover)=>{
    const target = e.target;
    hover ? target.classList.add("!border-primary") : target.classList.remove("!border-primary");
    e.preventDefault();
};
function sleep(timeout) {
    return new Promise((resolve)=>setTimeout(resolve, timeout));
}
function formatBytes(bytes, decimals = 2) {
    if (!+bytes) return "0 Bytes";
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = [
        "Bytes",
        "KB",
        "MB",
        "GB",
        "TB",
        "PB",
        "EB",
        "ZB",
        "YB"
    ];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}
function copyToClipboard(text) {
    var ref;
    const elInput = document.createElement("input");
    elInput.id = "copy-clipboard";
    elInput.value = text;
    document.body.append(elInput);
    const copyText = document.getElementById(elInput.id);
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(copyText.value);
    (ref = document.getElementById(elInput.id)) === null || ref === void 0 ? void 0 : ref.remove();
    return copyText.value;
}
const generateID = (length)=>{
    let result = "";
    const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    for(var i = 0; i < length; i++){
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
};
async function incomingRequest(form, req) {
    return await new Promise((resolve, reject)=>{
        form.parse(req, function(err, fields, files) {
            if (err) reject({
                err
            });
            const bodyText = {};
            Object.keys(fields).forEach((key)=>{
                bodyText[key] = fields[key].toString();
            });
            const bodyFile = {};
            Object.keys(files).forEach((key)=>{
                bodyFile[key] = files[key][0];
            });
            resolve({
                ...bodyText,
                files: bodyFile
            });
        });
    });
}
async function fileIsExists(src) {
    return new Promise((resolve, reject)=>{
        fs.access(src, async (err)=>{
            if (err) {
                reject(err);
                return;
            }
            resolve(true);
        });
    });
}
async function unlinkFile(src) {
    return new Promise((resolve)=>{
        fs.access(src, async (err)=>{
            if (err) {
                resolve(false);
                return;
            }
            await fs.promises.unlink(src);
            resolve(true);
        });
    });
}
async function createFile(src, destination) {
    const contentData = await fs.promises.readFile(src);
    await fs.promises.writeFile(destination, contentData);
}
function objectIntoFormData(payload) {
    const form = new FormData();
    for(const key in payload){
        form.append(key, payload[key]);
    }
    return form;
}
function mediaPath(dir, fileName) {
    return `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .DIR_ACCESS_FILE */ .Ce}/${dir}/${fileName}`;
}
function setCursorPosition(el, position) {
    const range = document.createRange();
    const sel = window.getSelection();
    range.setStart(el.childNodes[0], position);
    range.collapse(true);
    sel.removeAllRanges();
    sel.addRange(range);
    el.focus();
}
function strippedStrings(originalString) {
    return originalString.replace(/(<([^>]+)>)/gi, "");
}
function slugString(string) {
    return string.toLowerCase().replace(/ /g, "-").replace(/[^\w-]+/g, "");
    ;
}
function getDomain() {
    const env = "local";
    if (env === "local") return "localhost";
    if (env === "staging") return `dev.bursakarpetmasjid.com`;
    if (env === "production") return "bursakarpetmasjid.com";
}
function getCookieName(name) {
    const env = "local";
    return `${env}-${name}`;
}
const isClient = ()=>"undefined" !== "undefined";
function getCookie(name, serverRequest) {
    if (serverRequest) return (serverRequest === null || serverRequest === void 0 ? void 0 : serverRequest.cookies.get(getCookieName(name))) || null;
    const cookieName = `${getCookieName(name)}=`;
    const cookies = document.cookie.split(";");
    for(let i = 0; i < cookies.length; i++){
        let cookie = cookies[i];
        while(cookie.charAt(0) == " "){
            cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) == 0) {
            return cookie.substring(cookieName.length, cookie.length);
        }
    }
    return null;
}
function setCookie(name, value, expireDays) {
    const date = new Date();
    let expires = "";
    if (expireDays) {
        date.setTime(date.getTime() + expireDays * 24 * 60 * 60 * 1000);
        expires = `expires=${date.toUTCString()}`;
    }
    document.cookie = `${getCookieName(name)}=${value}; ${expires};path=/; domain=${getDomain()};`;
}
function eraseCookie(name) {
    document.cookie = `${getCookieName(name)}=; domain=${getDomain()}; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;`;
}
const getArticleTime = (date)=>{
    var ref;
    const formatDate = dayjs__WEBPACK_IMPORTED_MODULE_0___default()(date).format("YYYY-MM-DD");
    const year = (ref = formatDate.split("-")) === null || ref === void 0 ? void 0 : ref[0];
    const now = new Date();
    if (now.getFullYear() > +year) return dayjs__WEBPACK_IMPORTED_MODULE_0___default()(date).format("DD MMMM YYYY HH:mm");
    return dayjs__WEBPACK_IMPORTED_MODULE_0___default()().to(dayjs__WEBPACK_IMPORTED_MODULE_0___default()(date));
};
function getWord(writerName, totalWord, separator = " ") {
    const data = writerName.split(separator);
    return data.slice(0, totalWord).join(" ");
}
function selectedFileName(inputEl) {
    const split = inputEl.value.split(".");
    const endRangeFileName = (split)=>{
        let count = 0;
        for(let i = 0; i < split.length - 1; i++){
            count += split[i].length;
        }
        return count;
    };
    const end = endRangeFileName(split);
    inputEl.focus();
    inputEl.setSelectionRange(0, end);
}
function downloadFileUrl(url, fileName) {
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}


/***/ })

};
;